import { copyFile, lstat, mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const build = path.join(root, 'build');
const stage = path.join(build, 'stage');
const files = [
  'index.html', 'style.css', 'app.js', 'features.js', 'experience.js', 'config.xml', 'icon.png', 'LICENSE',
  'vendor/hls.min.js', 'vendor/hls.LICENSE', 'vendor/APACHE-2.0.txt',
  'media/orbit-review.mp4', 'media/LICENSE'
];

async function rejectSymlink(target) {
  try {
    const info = await lstat(target);
    if (info.isSymbolicLink()) throw new Error('Sembolik bağlantı kullanılamaz: ' + target);
    return info;
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

// Validate the complete allowlist before replacing the generated stage subtree.
await rejectSymlink(build);
await rejectSymlink(stage);
await rejectSymlink(path.join(root, 'vendor'));
await rejectSymlink(path.join(root, 'media'));
for (const file of files) {
  const info = await rejectSymlink(path.join(root, file));
  if (!info || !info.isFile()) throw new Error('Gerekli dosya eksik veya geçersiz: ' + file);
}

await mkdir(build, { recursive: true });
await rm(stage, { recursive: true, force: true });
await mkdir(path.join(stage, 'vendor'), { recursive: true });
await mkdir(path.join(stage, 'media'), { recursive: true });
for (const file of files) await copyFile(path.join(root, file), path.join(stage, file));
console.log('TV paketleme dosyaları hazır: ' + stage);
console.log('Sonraki komut: tizen build-web -- build/stage');
