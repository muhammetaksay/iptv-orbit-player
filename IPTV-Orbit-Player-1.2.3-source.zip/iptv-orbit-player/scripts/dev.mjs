import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const port = Number(process.env.AKIS_PORT || 4173);
const files = new Set(['index.html', 'style.css', 'app.js', 'features.js', 'experience.js', 'icon.png', 'vendor/hls.min.js', 'media/orbit-review.mp4', 'media/LICENSE']);
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.mp4': 'video/mp4' };
const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, 'http://127.0.0.1');
  if (url.pathname === '/$WEBAPIS/webapis/webapis.js') {
    response.writeHead(200, { 'Content-Type': types['.js'] });
    response.end('/* PC preview: Samsung injects the actual platform API on TV. */'); return;
  }
  const file = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
  if (!['GET', 'HEAD'].includes(request.method) || !files.has(file)) { response.writeHead(404); response.end('Not found'); return; }
  try {
    const headers = { 'Content-Type': types[path.extname(file)] || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' };
    if (file === 'media/orbit-review.mp4') {
      const location = path.join(root, file), { size } = await stat(location);
      let start = 0, end = size - 1, status = 200;
      headers['Accept-Ranges'] = 'bytes';
      if (request.headers.range) {
        const match = /^bytes=(\d*)-(\d*)$/.exec(request.headers.range);
        if (match && (match[1] || match[2])) {
          start = match[1] ? Number(match[1]) : Math.max(0, size - Number(match[2]));
          end = match[1] && match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
        } else start = size;
        if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= size || end < start) {
          response.writeHead(416, { ...headers, 'Content-Range': 'bytes */' + size }); response.end(); return;
        }
        status = 206; headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + size;
      }
      headers['Content-Length'] = end - start + 1; response.writeHead(status, headers);
      if (request.method === 'HEAD') response.end();
      else createReadStream(location, { start, end }).on('error', () => response.destroy()).pipe(response);
      return;
    }
    const body = await readFile(path.join(root, file));
    response.writeHead(200, { ...headers, 'Content-Length': body.length });
    response.end(request.method === 'HEAD' ? undefined : body);
  } catch { response.writeHead(500); response.end('File unavailable'); }
});
server.listen(port, '127.0.0.1', () => console.log('IPTV Orbit Player local preview: http://127.0.0.1:' + server.address().port));
