import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const files = [
  ['index.html', 'html'], ['style.css', 'css'], ['app.js', 'javascript'], ['config.xml', 'xml'],
  ['features.js', 'javascript'], ['experience.js', 'javascript'], ['media/LICENSE', 'text']
];
let output = '# IPTV Orbit Player — eksiksiz kaynak kodları\n\nİstenen dört ana dosyanın ve iki yardımcı modülün kısaltılmamış dökümü: index.html, style.css, app.js, config.xml, features.js ve experience.js. HLS.js ve lisansları `vendor/` içinde ayrıca teslim edilir. İsteğe bağlı hesapsız demoda kullanılan özgün 120 saniyelik MP4 ve MIT lisansı `media/` içinde bulunur; ikili video bu metin dökümüne gömülmez. Kurulum için README.md dosyasını izleyin.\n';
for (const [name, language] of files) {
  output += '\n## ' + name + '\n\n```' + language + '\n' + await readFile(new URL(name, root), 'utf8') + '\n```\n';
}
await writeFile(new URL('SOURCE-CODE.md', root), output);
console.log('SOURCE-CODE.md: ' + files.length + ' dosya eksiksiz dışa aktarıldı.');
