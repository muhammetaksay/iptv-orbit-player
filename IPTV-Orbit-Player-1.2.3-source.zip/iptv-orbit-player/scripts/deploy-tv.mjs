import { spawnSync } from 'node:child_process';
import { accessSync, constants, readFileSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { isIP } from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const help = `Kullanım: npm run deploy:tv -- --ip TV_IPV4 [--package IMZALI_DOSYA.wgt]

Mevcut imzalı paketi SDB push → vd_appinstall ile yükler ve başlatır.
Paket varsayılanı: build/AkisTV.wgt. config.xml ile eşleşmesi gerekir.
TV'deki görünen ad değişse de yükleme adı uygulama kimliğinden alınır.
AKIS_SDB ortam değişkeniyle SDB çalıştırılabilir dosyasını seçebilirsiniz.
Sertifika oluşturmaz, imzalamaz, tz install veya uninstall çağırmaz.
--help / -h: bu yardımı gösterir; TV'ye bağlanmaz.
`;

function fail(message) { throw new Error(message); }

function options(argv) {
  const result = { package: path.join(root, 'build', 'AkisTV.wgt') };
  for (let i = 0; i < argv.length; i++) {
    const argument = argv[i];
    if (argument !== '--ip' && argument !== '--package') fail('Bilinmeyen seçenek: ' + argument);
    if (!argv[i + 1] || argv[i + 1].startsWith('--')) fail(argument + ' için değer gerekli.');
    const key = argument.slice(2);
    if (key === 'ip' && result.ip) fail('--ip yalnız bir kez verilebilir.');
    result[key] = argv[++i];
  }
  if (!result.ip || isIP(result.ip) !== 4) fail('--ip ile geçerli bir TV IPv4 adresi verin.');
  result.package = path.resolve(result.package);
  return result;
}

function executable(file) {
  try { accessSync(file, constants.X_OK); return statSync(file).isFile(); }
  catch { return false; }
}

function resolveSdb() {
  if (process.env.AKIS_SDB) {
    const override = path.resolve(process.env.AKIS_SDB);
    if (!executable(override)) fail('AKIS_SDB çalıştırılabilir bir dosyayı göstermiyor.');
    return override;
  }
  const filename = process.platform === 'win32' ? 'sdb.exe' : 'sdb';
  const candidates = [];
  try {
    const sdk = readFileSync(path.join(homedir(), '.tizen.sdk.path.config'), 'utf8').trim();
    if (sdk && path.isAbsolute(sdk)) candidates.push(path.join(sdk, 'tools', filename));
  } catch { /* SDK yapılandırması yoksa standart dizin ve PATH kullanılır. */ }
  candidates.push(path.join(homedir(), 'tizen-sdk', 'tools', filename));
  for (const directory of (process.env.PATH || '').split(path.delimiter)) {
    if (directory && path.isAbsolute(directory)) candidates.push(path.join(directory, filename));
  }
  const found = candidates.find(executable);
  if (!found) fail('SDB bulunamadı. AKIS_SDB değişkenine tam çalıştırılabilir dosya yolunu yazın.');
  return found;
}

function run(command, args, label, timeout = 15000, maxBuffer = 2 * 1024 * 1024) {
  const result = spawnSync(command, args, {
    encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'],
    timeout, maxBuffer, windowsHide: true, shell: false
  });
  if (result.error || result.signal || result.status !== 0) {
    const reason = result.error?.code === 'ETIMEDOUT' || result.signal
      ? 'zaman sınırında tamamlanmadı; cihazdaki sonuç belirsiz'
      : 'başarısız oldu';
    fail(label + ' ' + reason + '. İşlem durduruldu; otomatik kaldırma veya tekrar deneme yapılmadı.');
  }
  return (result.stdout + '\n' + result.stderr).replace(/\r/g, '');
}

function rejectFailure(output, label) {
  if (/uninstall|failed|failure|\berror\b/i.test(output)) {
    fail(label + ' çıktısında hata veya kaldırma bildirimi var. İşlem durduruldu.');
  }
}

function oneMatch(value, expression, label) {
  const matches = [...value.matchAll(expression)];
  if (matches.length !== 1) fail('config.xml içinde tek bir ' + label + ' bulunmalı.');
  return matches[0];
}

function attribute(tag, name) {
  const match = oneMatch(tag, new RegExp('(?:^|\\s)' + name + '\\s*=\\s*(["\'])(.*?)\\1', 'g'), name);
  return match[2];
}

function inspectPackage(packageFile) {
  if (path.extname(packageFile) !== '.wgt' || !statSync(packageFile).isFile()) {
    fail('İmzalı .wgt dosyası bulunamadı. Önce mevcut sertifikanızla paketleyin.');
  }
  const entries = run('unzip', ['-Z1', packageFile], 'Paket listesi', 10000).trim().split('\n');
  for (const required of ['config.xml', 'author-signature.xml', 'signature1.xml']) {
    if (entries.filter(entry => entry === required).length !== 1) fail('Pakette tek bir ' + required + ' bulunmalı.');
  }
  if (entries.some(entry => entry.startsWith('/') || entry.split('/').includes('..'))) {
    fail('Pakette geçersiz dosya yolu bulundu.');
  }
  const packed = run('unzip', ['-p', packageFile, 'config.xml'], 'Paket manifestosu', 10000, 256 * 1024);
  const source = readFileSync(path.join(root, 'config.xml'), 'utf8');
  const normalized = value => value.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').trim();
  if (normalized(packed) !== normalized(source)) fail('İmzalı paketin config.xml dosyası proje ile eşleşmiyor. Yeniden imzalayın.');
  if (/<!DOCTYPE/i.test(packed)) fail('Manifestte DOCTYPE desteklenmiyor.');
  const xml = packed.replace(/<!--[\s\S]*?-->/g, '');
  const application = oneMatch(xml, /<tizen:application\b([^>]*)\/?>/g, 'tizen:application')[1];
  const widget = oneMatch(xml, /<widget\b([^>]*)>/g, 'widget')[1];
  const name = oneMatch(xml, /<name(?:\s[^>]*)?>([^<]+)<\/name>/g, 'name')[1].trim();
  const id = attribute(application, 'id');
  const packageId = attribute(application, 'package');
  const version = attribute(widget, 'version');
  if (!/^[A-Za-z0-9._-]+$/.test(id) || !/^[A-Za-z0-9]{10}$/.test(packageId) || !id.startsWith(packageId + '.')) {
    fail('Manifestteki uygulama/paket kimliği geçersiz.');
  }
  if (!name || name.length > 200 || /[\u0000-\u001f\u007f]/.test(name)) fail('Manifestteki görünen uygulama adı geçersiz.');
  // Keep the internal TV install path stable when the public display name changes.
  const installAlias = id.slice(packageId.length + 1);
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/.test(installAlias)) fail('Dahili TV yükleme kimliği geçersiz.');
  if (!/^\d+\.\d+\.\d+$/.test(version)) fail('Manifest sürümü x.y.z biçiminde olmalı.');
  return { id, packageId, name, installAlias, version };
}

function deploy(settings) {
  const manifest = inspectPackage(settings.package);
  const sdb = resolveSdb();
  const serial = settings.ip + ':26101';
  const device = args => ['-s', serial, ...args];
  console.log('İmza dosyaları ve manifest eşleşmesi denetlendi: ' + manifest.name + ' ' + manifest.version);
  console.log('Hedef TV: ' + serial);

  const connection = run(sdb, ['connect', serial], 'TV bağlantısı');
  rejectFailure(connection, 'TV bağlantısı');
  var connected = connection.toLowerCase();
  if (!connected.includes('connected to ' + serial) && !connected.includes(serial + ' is already connected')) fail('TV bağlantısı doğrulanamadı.');
  const devices = run(sdb, ['devices'], 'Cihaz listesi');
  const online = devices.split('\n').some(line => {
    const columns = line.trim().split(/\s+/);
    return columns[0] === serial && columns[1] === 'device';
  });
  if (!online) fail('Seçilen TV çevrimiçi device durumunda değil.');

  const capability = run(sdb, device(['capability']), 'TV yetenekleri');
  rejectFailure(capability, 'TV yetenekleri');
  const directories = [...capability.matchAll(/^sdk_toolpath:\s*([^\n]+)$/gm)];
  if (directories.length !== 1) fail('TV sdk_toolpath bildirmedi; yükleme yapılmadı.');
  const directory = directories[0][1].trim();
  if (!/^\/[A-Za-z0-9._/-]+$/.test(directory) || directory.split('/').includes('..')) {
    fail('TV sdk_toolpath geçerli bir mutlak dizin değil.');
  }
  const remote = directory.replace(/\/+$/, '') + '/' + manifest.installAlias + '.wgt';

  const stopped = run(sdb, device(['shell', '0', 'was_kill', manifest.id]), 'Uygulamayı durdurma');
  rejectFailure(stopped, 'Uygulamayı durdurma');
  const pushed = run(sdb, device(['push', settings.package, remote]), 'Paket gönderimi', 60000);
  rejectFailure(pushed, 'Paket gönderimi');
  if (!/\b[1-9]\d*\s+file(?:\(s\)|s)?\s+pushed\b/i.test(pushed)) {
    fail('Paket gönderiminin başarı bildirimi alınamadı; yükleme yapılmadı.');
  }
  console.log('Paket gönderildi. Doğrudan Samsung TV yüklemesi başlıyor.');
  const installed = run(sdb, device(['shell', '0', 'vd_appinstall', manifest.installAlias, remote]), 'TV yüklemesi', 60000);
  rejectFailure(installed, 'TV yüklemesi');
  const completion = installed.match(/app_id\[([^\]]+)\]\s+install completed\b/i);
  if (!completion || ![manifest.id, manifest.installAlias, manifest.packageId].includes(completion[1])) {
    fail('Bu uygulama için install completed yanıtı alınamadı; başlatma yapılmadı.');
  }
  console.log('TV kurulumu doğrulandı.');
  const launched = run(sdb, device(['shell', '0', 'was_execute', manifest.id]), 'Uygulamayı başlatma');
  rejectFailure(launched, 'Uygulamayı başlatma');
  const launch = launched.match(/app_id\[([^\]]+)\]\s+(launched|resumed)\b/i);
  if (!launch || launch[1] !== manifest.id) fail('Kurulum tamamlandı; uygulamanın başlatıldığı doğrulanamadı.');
  console.log('Uygulama başlatıldı. TV ekranında kayıtlı hesabı ve yayın biçimini kontrol edin.');
}

try {
  const argv = process.argv.slice(2);
  if (argv.includes('--help') || argv.includes('-h')) console.log(help);
  else deploy(options(argv));
} catch (error) {
  console.error('Yükleme durduruldu: ' + error.message);
  process.exitCode = 1;
}
