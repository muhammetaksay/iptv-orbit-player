import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';
import { webcrypto } from 'node:crypto';

const index = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const source = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
const featureSource = readFileSync(new URL('../features.js', import.meta.url), 'utf8');
const experienceSource = readFileSync(new URL('../experience.js', import.meta.url), 'utf8');
const marker = '/* AKIŞ TV — MIT. This controller is bundled after TVPlayer in app.js. */';
assert.ok(source.includes(marker));
const controller = source.slice(source.indexOf(marker));
const STORE = 'akis.credentials.v1';
const DEFER = Symbol('defer');
const account = { user_info: { auth: 1, status: 'Active', exp_date: '2000000000' } };
const credentials = { server: 'https://provider.invalid', username: 'a+b &ç', password: 'p/&?#+' };
const defaultCategories = [{ category_id: '11', category_name: 'Haber' }, { category_id: '22', category_name: 'Kültür' }];
const liveRows = (count, prefix = 'Kanal') => Array.from({ length: count }, (_, i) => ({ stream_id: i + 1, name: `${prefix} ${i + 1}`, category_id: '11' }));

function fixture({ saved, route, storage = {} } = {}) {
  const dom = new JSDOM(index, { url: 'http://localhost:4173/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  const { document } = window;
  Object.defineProperty(window.crypto, 'subtle', { value: webcrypto.subtle });
  window.TextDecoder = TextDecoder; window.TextEncoder = TextEncoder;
  const requests = [];
  const timers = new Map();
  const players = [];
  let clock = 0;
  let id = 0;
  window.setTimeout = (fn, delay = 0) => { const key = ++id; timers.set(key, { fn, at: clock + Number(delay), interval: 0 }); return key; };
  window.clearTimeout = (key) => timers.delete(key);
  window.setInterval = (fn, delay) => { const key = ++id; timers.set(key, { fn, at: clock + delay, interval: delay }); return key; };
  window.clearInterval = window.clearTimeout;
  window.requestAnimationFrame = (fn) => window.setTimeout(() => fn(clock), 16);
  window.cancelAnimationFrame = window.clearTimeout;
  window.HTMLElement.prototype.getBoundingClientRect = function () {
    const field = ['server-url', 'username', 'password', 'login-button'].indexOf(this.id);
    const index = Number(this.dataset.index || 0);
    const left = this.dataset.zone === 'category' ? 80 : this.dataset.zone === 'stream' ? 500 : field >= 0 ? 1100 : this.id === 'home-button' ? 1400 : 50;
    const top = field >= 0 ? 300 + field * 90 : this.dataset.zone ? 270 + index * 82 : 60;
    return { left, top, right: left + 300, bottom: top + 60, width: 300, height: 60, x: left, y: top, toJSON() {} };
  };
  ['category-list', 'stream-list'].forEach((name) => Object.defineProperty(document.getElementById(name), 'clientHeight', { value: 600 }));
  class Player {
    constructor(options) { this.options = options; this.plays = []; this.seeks = []; this.stops = 0; this.playing = false; this.paused = false; this.position = 0; this.duration = 7200; players.push(this); }
    stop() { this.stops += 1; this.playing = false; this.paused = false; this.options.onStatus('stopped', ''); }
    play(request) { this.plays.push(request); this.position = 0; this.live = request.live; this.playing = true; this.options.onEngine('HTML5'); this.options.onStatus('playing', ''); this.options.onPlaying(); }
    setFullscreen(value) { this.fullscreen = value; }
    refreshRect() {}
    togglePause() { this.paused = !this.paused; }
    seekBy() {}
    seekTo(seconds) { if (!this.playing || this.live) return false; this.seeks.push(seconds); this.position = seconds; return true; }
    getPlaybackInfo() { return { currentTime: this.position, duration: this.live ? 0 : this.duration, playing: this.playing, paused: this.paused, live: this.live, seeking: false, canSeek: this.playing && !this.live, seekable: [] }; }
    getAudioTracks() { return [{ index: 0, label: 'Türkçe', language: 'tr', selected: true }, { index: 1, label: 'English', language: 'en', selected: false }]; }
    getSubtitleTracks() { return [{ index: 2, label: 'Türkçe altyazı', language: 'tr', selected: false }]; }
    selectAudioTrack(index) { this.audio = index; return true; }
    selectSubtitleTrack(index) { this.subtitle = index; return true; }
    setAspectRatio(value) { this.aspect = value; return true; }
    destroy() { this.stop(); }
  }
  window.TVPlayer = Player;
  class XHR {
    open(method, url) { this.method = method; this.url = url; }
    abort() { this.aborted = true; if (this.onabort) this.onabort(); }
    respond(data, status = 200) { this.status = status; this.responseText = JSON.stringify(data); if (this.onload) this.onload(); }
    send() {
      requests.push(this);
      const parsed = new URL(this.url);
      const action = parsed.searchParams.get('action') || '';
      let data = route ? route(action, parsed, this) : undefined;
      if (data === undefined) {
        if (!action) data = account;
        else if (action.endsWith('_categories')) data = defaultCategories;
        else if (action === 'get_live_streams') data = liveRows(3);
        else if (action === 'get_vod_streams') data = [{ stream_id: 71, name: 'Film', container_extension: 'mp4' }];
        else if (action === 'get_series') data = [{ series_id: 81, name: 'Dizi' }];
        else if (action === 'get_series_info') data = { episodes: { '1': [{ id: '901', title: 'Başlangıç', episode_num: 1, container_extension: 'mkv' }, { id: '902', title: 'Devam', episode_num: 2, container_extension: 'mp4' }] } };
        else if (action === 'get_short_epg' || action === 'get_simple_data_table') data = { epg_listings: [] };
      }
      if (data !== DEFER) queueMicrotask(() => this.respond(data));
    }
  }
  window.XMLHttpRequest = XHR;
  if (saved) window.localStorage.setItem(STORE, JSON.stringify(saved));
  Object.entries(storage).forEach(([key, value]) => window.localStorage.setItem(key, value));
  window.eval(featureSource); window.eval(experienceSource); window.eval(controller);

  function tick(milliseconds) {
    const target = clock + milliseconds;
    let loops = 0;
    while (true) {
      const next = [...timers.entries()].filter(([, task]) => task.at <= target).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
      if (!next) break;
      assert.ok(++loops < 10000, 'controller timer scheduling must remain bounded');
      clock = next[1].at;
      timers.delete(next[0]);
      next[1].fn();
      if (next[1].interval) timers.set(next[0], { ...next[1], at: clock + next[1].interval });
    }
    clock = target;
  }
  async function flush() {
    // API continuations and chunked normalization each enqueue further microtasks/timers.
    for (let n = 0; n < 24; n += 1) { await Promise.resolve(); tick(0); }
  }
  const $ = (name) => document.getElementById(name);
  function key(value, keyCode, repeat = false) { document.activeElement.dispatchEvent(new window.KeyboardEvent('keydown', { key: value, keyCode: keyCode || 0, repeat, bubbles: true, cancelable: true })); }
  async function login(values = credentials) {
    $('server-url').value = values.server; $('username').value = values.username; $('password').value = values.password;
    $('login-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    await flush();
  }
  async function mode(name) { document.querySelector(`[data-mode="${name}"]`).click(); await flush(); }
  function stream(index = 0) { return document.querySelector(`#stream-window [data-index="${index}"]`); }
  function category(index = 0) { return document.querySelector(`#category-window [data-index="${index}"]`); }
  async function advance(milliseconds) { tick(milliseconds); await flush(); }
  return { dom, window, document, $, key, flush, login, mode, stream, category, requests, player: players[0], advance, close() { dom.window.close(); } };
}

test('Enter opens a readonly TV input and IME Done saves it and advances focus', (t) => {
  const f = fixture(); t.after(() => f.close());
  assert.equal(f.document.activeElement.id, 'server-url');
  assert.equal(f.$('server-url').readOnly, true);
  f.key('Enter', 13);
  assert.equal(f.$('server-url').readOnly, false);
  assert.equal(f.$('server-url').classList.contains('is-editing'), true);
  f.$('server-url').value = 'https://provider.invalid';
  f.key('Done', 65376);
  assert.equal(f.$('server-url').readOnly, true);
  assert.equal(f.document.activeElement.id, 'username');
  f.key('Enter', 13);
  f.key('Back', 10009);
  assert.equal(f.$('username').readOnly, true);
  assert.equal(f.document.activeElement.id, 'username');
});

test('valid login encodes credentials, normalizes player_api.php, persists them and auto logs in', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login({ ...credentials, server: 'https://provider.invalid/player_api.php/' });
  assert.equal(f.$('home-screen').hidden, false);
  assert.equal(f.$('login-screen').hidden, true);
  assert.ok(f.requests[0].url.includes('username=a%2Bb%20%26%C3%A7'));
  assert.ok(f.requests[0].url.includes('password=p%2F%26%3F%23%2B'));
  assert.deepEqual(JSON.parse(f.window.localStorage.getItem(STORE)), credentials);
  const auto = fixture({ saved: credentials }); t.after(() => auto.close());
  await auto.flush();
  assert.equal(auto.$('home-screen').hidden, false);
  assert.equal(auto.requests.length, 1);
  assert.equal(new URL(auto.requests[0].url).searchParams.get('password'), credentials.password);
});

test('rejected authentication keeps login visible and never persists invalid credentials', async (t) => {
  const f = fixture({ route(action) { if (!action) return { user_info: { auth: 0, status: 'Disabled' } }; } }); t.after(() => f.close());
  await f.login();
  assert.equal(f.$('login-screen').hidden, false);
  assert.equal(f.$('home-screen').hidden, true);
  assert.equal(f.window.localStorage.getItem(STORE), null);
  assert.match(f.$('login-message').textContent, /Giriş reddedildi/);
  assert.equal(f.$('login-button').disabled, false);
});

test('5000 real API channels retain a small DOM and remote navigation reaches the next item', async (t) => {
  const f = fixture({ route(action) { if (action === 'get_live_streams') return liveRows(5000); } }); t.after(() => f.close());
  await f.login(); await f.mode('live');
  assert.match(f.$('browser-subtitle').textContent, /5\.000 içerik/);
  assert.ok(f.document.querySelectorAll('#stream-window button').length < 30);
  assert.equal(f.$('stream-spacer').style.height, `${5000 * 82}px`);
  f.category(0).focus(); f.key('ArrowRight', 39);
  assert.equal(f.document.activeElement.dataset.index, '0');
  f.key('ArrowDown', 40);
  assert.equal(f.document.activeElement.dataset.index, '1');
  assert.equal(f.$('detail-title').textContent, 'Kanal 2');
});

test('a stale category response cannot replace the newly selected category', async (t) => {
  const pending = [];
  const f = fixture({ route(action, parsed, xhr) {
    if (action === 'get_live_streams') { pending.push({ category: parsed.searchParams.get('category_id'), xhr }); return DEFER; }
  } }); t.after(() => f.close());
  await f.login(); await f.mode('live');
  assert.equal(pending[0].category, '11');
  f.category(1).click(); await f.flush();
  assert.equal(pending[0].xhr.aborted, true);
  assert.equal(pending[1].category, '22');
  pending[1].xhr.respond(liveRows(1, 'Yeni')); await f.flush();
  assert.equal(f.stream(0).textContent.includes('Yeni 1'), true);
  pending[0].xhr.respond(liveRows(2, 'Eski')); await f.flush();
  assert.equal(f.stream(0).textContent.includes('Yeni 1'), true);
  assert.match(f.$('browser-subtitle').textContent, /Kültür · 1 içerik/);
});

test('series load episodes, play the series URL path, and Return restores the series list', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('series');
  f.stream(0).focus(); f.key('Enter', 13); await f.flush();
  const info = f.requests.find((xhr) => new URL(xhr.url).searchParams.get('action') === 'get_series_info');
  assert.equal(new URL(info.url).searchParams.get('series_id'), '81');
  assert.match(f.$('browser-subtitle').textContent, /Bölümler · 2 içerik/);
  assert.match(f.stream(0).textContent, /Başlangıç/);
  f.key('Enter', 13);
  assert.equal(f.player.plays.length, 1);
  assert.equal(f.player.plays[0].url, `${credentials.server}/series/a%2Bb%20%26%C3%A7/p%2F%26%3F%23%2B/901.mkv`);
  assert.equal(f.player.fullscreen, true);
  f.key('Back', 10009);
  assert.equal(f.player.fullscreen, false);
  f.key('Back', 10009);
  assert.equal(f.$('browser-screen').hidden, false);
  assert.equal(f.stream(0).textContent.includes('Dizi'), true);
  assert.equal(f.document.activeElement.dataset.index, '0');
});

test('Home cancels a pending preview so no hidden playback starts later', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.stream(0).focus();
  f.$('home-button').click();
  await f.advance(1000);
  assert.equal(f.$('home-screen').hidden, false);
  assert.equal(f.player.plays.length, 0);
  assert.equal(f.player.playing, false);
});

test('fullscreen channel changes preserve selection through virtual list rerender', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.stream(0).focus(); f.key('Enter', 13);
  assert.match(f.player.plays.at(-1).url, /\/1\.m3u8$/);
  f.key('ArrowUp', 38); await f.advance(220);
  assert.match(f.player.plays.at(-1).url, /\/2\.m3u8$/);
  assert.equal(f.$('detail-title').textContent, 'Kanal 2');
  assert.equal(f.document.querySelector('#stream-window .is-selected').dataset.index, '1');
  f.key('ArrowUp', 38); await f.advance(220);
  assert.match(f.player.plays.at(-1).url, /\/3\.m3u8$/);
  f.key('ArrowDown', 40); await f.advance(220);
  assert.match(f.player.plays.at(-1).url, /\/2\.m3u8$/);
  f.key('Back', 10009);
  assert.equal(f.player.fullscreen, false);
  assert.equal(f.document.activeElement.dataset.index, '1');
  assert.equal(f.$('detail-title').textContent, 'Kanal 2');
});

test('settings reset removes stored credentials and returns to a clean login screen', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login();
  f.$('settings-button').click();
  assert.equal(f.$('dialog').hidden, false);
  assert.equal(f.document.activeElement.id, 'dialog-cancel');
  f.$('dialog-confirm').click();
  assert.equal(f.window.localStorage.getItem(STORE), null);
  assert.equal(f.$('login-screen').hidden, false);
  assert.equal(f.$('server-url').value, '');
  assert.equal(f.$('username').value, '');
  assert.equal(f.$('password').value, '');
  assert.equal(f.document.activeElement.id, 'server-url');
  assert.match(f.$('login-message').textContent, /silindi/);
});

test('a delayed series response cannot steal focus from the settings confirmation dialog', async (t) => {
  let pending;
  const f = fixture({ route(action, parsed, xhr) {
    if (action === 'get_series_info') { pending = xhr; return DEFER; }
  } }); t.after(() => f.close());
  await f.login(); await f.mode('series');
  f.stream(0).focus(); f.key('Enter', 13); await f.flush();
  assert.ok(pending, 'series detail request must still be in flight');
  f.$('settings-button').click();
  assert.equal(f.document.activeElement.id, 'dialog-cancel');
  pending.respond({ episodes: { '1': [{ id: '903', episode_num: 1, title: 'Geç gelen bölüm', container_extension: 'mp4' }] } });
  await f.flush();
  assert.match(f.$('browser-subtitle').textContent, /Bölümler · 1 içerik/);
  assert.match(f.stream(0).textContent, /Geç gelen bölüm/);
  assert.equal(f.$('dialog').hidden, false);
  assert.equal(f.document.activeElement.id, 'dialog-cancel', 'background list completion must preserve modal focus');
});

test('Enter restarts the same fullscreen stream after the TV app returns from suspension', async (t) => {
  const f = fixture(); t.after(() => f.close());
  let hidden = false;
  Object.defineProperty(f.document, 'hidden', { configurable: true, get: () => hidden });
  await f.login(); await f.mode('live');
  f.stream(0).focus(); f.key('Enter', 13);
  const original = f.player.plays[0].url;
  assert.equal(f.player.playing, true);
  assert.equal(f.player.fullscreen, true);
  hidden = true;
  f.document.dispatchEvent(new f.window.Event('visibilitychange'));
  assert.equal(f.player.playing, false, 'suspension must release the decoder');
  hidden = false;
  f.document.dispatchEvent(new f.window.Event('visibilitychange'));
  assert.equal(f.player.plays.length, 1, 'resume waits for a remote control gesture');
  f.key('Enter', 13);
  assert.equal(f.player.plays.length, 2);
  assert.equal(f.player.plays[1].url, original);
  assert.equal(f.player.playing, true);
  assert.equal(f.player.fullscreen, true);
});

test('a search with no results releases active preview playback and clears the list', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.stream(0).focus(); await f.advance(450);
  assert.equal(f.player.playing, true);
  assert.equal(f.player.fullscreen, false);
  const stops = f.player.stops;
  f.$('search-input').value = 'eşleşmeyen benzersiz arama';
  f.$('search-input').dispatchEvent(new f.window.Event('input', { bubbles: true }));
  await f.advance(180);
  assert.ok(f.player.stops > stops);
  assert.equal(f.player.playing, false);
  assert.equal(f.document.querySelectorAll('#stream-window button').length, 0);
  assert.match(f.$('browser-subtitle').textContent, /0 içerik/);
  assert.equal(f.$('watch-button').disabled, true);
});

test('VOD arrows preview an accelerated target and Enter commits once; Back cancels a preview', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('vod');
  f.stream(0).click();
  assert.equal(f.$('seek-controls').hidden, false);
  f.key('ArrowRight', 39);
  assert.equal(f.player.seeks.length, 0, 'scrubbing must not restart a decoder for every key repeat');
  assert.equal(f.$('seek-position').textContent, '00:00:10');
  for (let i = 0; i < 7; i++) f.key('ArrowRight', 39, true);
  assert.equal(f.$('seek-position').textContent, '00:03:00');
  f.key('Enter', 13);
  assert.deepEqual(f.player.seeks, [180]);
  f.key('Enter', 13, true);
  assert.equal(f.player.paused, false, 'holding OK after a seek must not toggle pause repeatedly');
  f.key('ArrowLeft', 37);
  f.key('Back', 10009);
  assert.equal(f.player.fullscreen, true, 'first Back cancels selection without leaving fullscreen');
  assert.equal(f.$('seek-position').textContent, '00:03:00');
  f.key('Back', 10009);
  assert.equal(f.player.fullscreen, false);
});

test('timestamp dialog accepts remote numeric input, rejects invalid or out-of-range times, and jumps precisely', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('vod'); f.stream(0).click();
  f.key('ArrowDown', 40); f.key('Enter', 13);
  assert.equal(f.$('seek-time-field').hidden, false);
  assert.equal(f.document.activeElement.id, 'seek-time-input');
  f.key('Enter', 13); assert.equal(f.$('seek-time-input').readOnly, false);
  f.$('seek-time-input').value = '02:50:00';
  f.key('Done', 65376); assert.equal(f.document.activeElement.id, 'dialog-confirm');
  f.key('Enter', 13);
  assert.equal(f.$('dialog').hidden, false);
  assert.equal(f.player.seeks.length, 0);
  assert.match(f.$('seek-time-error').textContent, /videonun süresinden kısa/);
  f.$('seek-time-input').value = '012345';
  f.$('dialog-confirm').click();
  assert.deepEqual(f.player.seeks, [5025]);
  assert.equal(f.$('dialog').hidden, true);
  assert.equal(f.player.fullscreen, true);
  f.$('seek-time-button').focus(); f.key('Enter', 13);
  f.$('seek-time-input').value = '12:70:00'; f.$('dialog-confirm').click();
  assert.equal(f.$('dialog').hidden, false);
  assert.deepEqual(f.player.seeks, [5025]);
});

test('only account and format persist after video selection, seeking, and returning Home; legacy history is removed', async (t) => {
  const f = fixture({ storage: { 'akis.history': '[71]', 'akis.resume': '700', 'akis.format': 'ts', 'unrelated.setting': 'keep' } }); t.after(() => f.close());
  assert.equal(f.window.localStorage.getItem('akis.history'), null);
  assert.equal(f.window.localStorage.getItem('akis.resume'), null);
  assert.equal(f.window.localStorage.getItem('unrelated.setting'), 'keep');
  await f.login(); await f.mode('vod'); f.stream(0).click();
  f.key('ArrowRight', 39); f.key('Enter', 13); f.key('Back', 10009); f.$('home-button').click();
  assert.deepEqual(Object.keys(f.window.localStorage).sort(), [STORE, 'akis.format', 'unrelated.setting'].sort());
  assert.equal(f.window.sessionStorage.length, 0);
  await f.mode('vod'); f.stream(0).click();
  assert.equal(f.player.position, 0, 'reopening a title must always begin at zero');
  assert.equal(f.player.plays.at(-1).startAt, undefined);
});

test('virtual scrolling and playing reuse overlapping rows instead of rebuilding the visible list', async (t) => {
  const f = fixture({ route(action) { if (action === 'get_live_streams') return liveRows(5000); } }); t.after(() => f.close());
  await f.login(); await f.mode('live');
  const first = f.stream(0), overlap = f.stream(5);
  first.click();
  assert.equal(f.stream(0), first, 'playback-state styling must keep the same row node');
  f.key('Back', 10009);
  f.$('stream-list').scrollTop = 5 * 82;
  f.$('stream-list').dispatchEvent(new f.window.Event('scroll'));
  await f.advance(16);
  assert.equal(f.stream(5), overlap, 'the overlapping row must survive a scroll-window change');
  assert.ok(f.document.querySelectorAll('.stream-row').length < 30);
  const requests = f.requests.length;
  f.category(0).click(); await f.flush();
  assert.equal(f.requests.length, requests, 'reselecting the current category is a no-op');
});
