import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { readFileSync, statSync } from 'node:fs';
import { once } from 'node:events';
import { fileURLToPath } from 'node:url';

const root = new URL('../', import.meta.url);
const media = new URL('media/orbit-review.mp4', root);

test('bundled MIT reviewer media is allowlisted and the local preview serves seekable byte ranges', async (t) => {
  const size = statSync(media).size;
  assert.ok(size > 100000);
  assert.match(readFileSync(new URL('media/LICENSE', root), 'utf8'), /MIT License/);
  const staging = readFileSync(new URL('scripts/stage.mjs', root), 'utf8');
  assert.ok(staging.includes("'media/orbit-review.mp4'"));
  assert.ok(staging.includes("'media/LICENSE'"));
  const child = spawn(process.execPath, ['scripts/dev.mjs'], { cwd: fileURLToPath(root), env: { ...process.env, AKIS_PORT: '0' }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (child.exitCode === null) { child.kill(); await once(child, 'exit'); } });
  const address = await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('preview server did not start')), 5000);
    child.on('error', reject);
    child.stdout.on('data', (chunk) => {
      const match = chunk.toString().match(/http:\/\/127\.0\.0\.1:\d+/);
      if (match) { clearTimeout(timeout); resolve(match[0]); }
    });
    child.once('exit', (code) => { clearTimeout(timeout); if (code) reject(new Error('preview server failed: ' + code)); });
  });
  const ranged = await fetch(address + '/media/orbit-review.mp4', { headers: { Range: 'bytes=0-31' } });
  assert.equal(ranged.status, 206);
  assert.equal(ranged.headers.get('content-type'), 'video/mp4');
  assert.equal(ranged.headers.get('content-range'), `bytes 0-31/${size}`);
  assert.equal(ranged.headers.get('accept-ranges'), 'bytes');
  assert.deepEqual(Buffer.from(await ranged.arrayBuffer()), readFileSync(media).subarray(0, 32));
  const head = await fetch(address + '/media/orbit-review.mp4', { method: 'HEAD' });
  assert.equal(head.status, 200);
  assert.equal(Number(head.headers.get('content-length')), size);
  assert.equal((await head.arrayBuffer()).byteLength, 0);
  const invalid = await fetch(address + '/media/orbit-review.mp4', { headers: { Range: `bytes=${size}-` } });
  assert.equal(invalid.status, 416);
  assert.equal(invalid.headers.get('content-range'), `bytes */${size}`);
  const license = await fetch(address + '/media/LICENSE');
  assert.match(await license.text(), /MIT License/);
  const privateFile = await fetch(address + '/release/store/review-media/catalog.json');
  assert.equal(privateFile.status, 404, 'preview allowlist must not expose unrelated release files');
});
