# Yerel test medyası

Bu klasördeki 20 saniyelik sabit renkli video ve 440 Hz sinüs sesi, bu proje için FFmpeg ile üretilmiştir. Yayıncı içeriği içermez. MP4 ve HLS dosyaları yalnız yerel oynatma testine hizmet eder; sonlu test dosyası gerçek canlı yayın değildir. Uygulamanın MIT lisansı altında dağıtılır. Test sırasında ses seviyesini uygun düzeyde tutun.

Üretim komutları (FFmpeg kuruluysa, boş bir klasörde):

```sh
ffmpeg -f lavfi -i 'color=c=0x123743:s=960x540:r=24' -f lavfi -i 'sine=frequency=440:sample_rate=48000' -t 20 -c:v libx264 -preset veryfast -pix_fmt yuv420p -g 96 -sc_threshold 0 -c:a aac -b:a 64k -f hls -hls_time 4 -hls_playlist_type vod -hls_segment_filename sample%02d.ts sample.m3u8
ffmpeg -i sample.m3u8 -c copy -movflags +faststart sample.mp4
```

Teslim edilen dosyaları kullanmak için FFmpeg kurulması gerekmez. `node tests/fixture-server.mjs` yalnız 127.0.0.1 üzerinde çalışır. Bu adres TV'nin kendisine işaret edeceği için gerçek TV yayın testi yerine geçmez.
