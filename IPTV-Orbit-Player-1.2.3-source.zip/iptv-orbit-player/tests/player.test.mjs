import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

// Run the delivered engine in isolation, without introducing production test hooks.
const appSource = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
const marker = '/* AKIŞ TV — MIT. This controller is bundled after TVPlayer in app.js. */';
assert.ok(appSource.includes(marker), 'app.js must contain the bundled controller marker');
const engineSource = appSource.slice(0, appSource.indexOf(marker));

function fixture({ hardware = true, hls = false, nativeHls = true, nativeTS = false, deferSeek = false } = {}) {
  const calls = [];
  const errors = [];
  const statuses = [];
  const engines = [];
  const subtitles = [], sources = [];
  const prepares = [];
  const seeks = [];
  const listeners = [];
  const hlsInstances = [];
  const tasks = new Map();
  let nextTask = 0;
  let clock = 100000;
  let avState = 'NONE';
  let ended = 0;
  let playing = 0;
  let selectedAudio = 0;

  function advance(milliseconds) {
    const target = clock + milliseconds;
    let iterations = 0;
    while (true) {
      const next = [...tasks.entries()].filter(([, task]) => task.at <= target)
        .sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
      if (!next) break;
      assert.ok(++iterations < 1000, 'timer loop must remain bounded');
      clock = next[1].at;
      tasks.delete(next[0]);
      next[1].fn();
    }
    clock = target;
  }

  const events = new Map();
  const video = {
    controls: true, hidden: false, style: {}, paused: true, ended: false,
    currentTime: 0, duration: 600, src: '',
    setAttribute() {},
    removeAttribute(name) { if (name === 'src') this.src = ''; },
    load() { calls.push(['video.load']); },
    pause() {
      calls.push(['video.pause']);
      const changed = !this.paused;
      this.paused = true;
      if (changed) this.emit('pause');
    },
    play() {
      calls.push(['video.play']);
      this.paused = false;
      this.emit('playing');
      return Promise.resolve();
    },
    canPlayType(type) {
      if (/mpegurl/i.test(type)) return nativeHls ? 'probably' : '';
      if (type === 'video/mp2t') return nativeTS ? 'maybe' : '';
      return '';
    },
    addEventListener(name, handler) {
      if (!events.has(name)) events.set(name, new Set());
      events.get(name).add(handler);
    },
    removeEventListener(name, handler) { events.get(name)?.delete(handler); },
    emit(name) { [...(events.get(name) || [])].forEach((handler) => handler()); }
  };
  const av = {
    open(url) { calls.push(['av.open', url]); avState = 'IDLE'; },
    close() { calls.push(['av.close']); avState = 'NONE'; },
    stop() { calls.push(['av.stop']); avState = 'IDLE'; },
    getState() { return avState; },
    setListener(value) { listeners.push(value); },
    setDisplayRect(...rect) { calls.push(['av.rect', ...rect]); },
    setDisplayMethod(method) { calls.push(['av.displayMethod', method]); },
    prepareAsync(success, failure) { prepares.push({ success, failure }); avState = 'READY'; },
    play() { calls.push(['av.play']); avState = 'PLAYING'; },
    pause() { calls.push(['av.pause']); avState = 'PAUSED'; },
    getDuration() { return 600000; },
    getCurrentTime() { return 10000; },
    getTotalTrackInfo() { return [{ type: 'AUDIO', index: 0, extra_info: '{"language":"<b>Türkçe</b>"}' }, { type: 'AUDIO', index: 1, extra_info: '{"language":"en"}' }, { type: 'TEXT', index: 4, extra_info: '{"track_lang":"tr"}' }]; },
    getCurrentStreamInfo() { return [{ type: 'AUDIO', index: selectedAudio }]; },
    setSelectTrack(type, index) { calls.push(['av.track', type, index]); if (type === 'AUDIO') selectedAudio = index; },
    setSilentSubtitle(value) { calls.push(['av.silentSubtitle', value]); },
    seekTo(position, success, failure) {
      calls.push(['av.seek', position]); seeks.push({ position, success, failure });
      if (!deferSeek && success) success();
    }
  };
  class FakeHls {
    static Events = { MEDIA_ATTACHED: 'attached', MANIFEST_PARSED: 'manifest', ERROR: 'error' };
    static ErrorTypes = { NETWORK_ERROR: 'network', MEDIA_ERROR: 'media' };
    static isSupported() { return true; }
    constructor(config) {
      this.config = config;
      this.handlers = new Map();
      this.loads = [];
      this.networkRecoveries = 0;
      this.mediaRecoveries = 0;
      this.destroyed = false;
      hlsInstances.push(this);
    }
    on(name, handler) { this.handlers.set(name, handler); }
    emit(name, data) { this.handlers.get(name)?.(name, data); }
    attachMedia() { this.emit(FakeHls.Events.MEDIA_ATTACHED); }
    loadSource(url) { this.loads.push(url); }
    startLoad() { this.networkRecoveries += 1; }
    recoverMediaError() { this.mediaRecoveries += 1; }
    destroy() { this.destroyed = true; }
  }
  const object = { hidden: true, style: {} };
  const shell = {
    dataset: {},
    getBoundingClientRect() { return { left: 640, top: 100, width: 480, height: 270 }; }
  };
  const document = {
    hidden: false,
    documentElement: { clientWidth: 1280, clientHeight: 720 },
    getElementById(id) { return id === 'av-player' ? object : null; }
  };
  const window = {
    innerWidth: 1280, innerHeight: 720,
    webapis: hardware ? { avplay: av } : undefined,
    Hls: hls ? FakeHls : undefined,
    setTimeout(fn, delay) { const id = ++nextTask; tasks.set(id, { fn, at: clock + delay }); return id; },
    clearTimeout(id) { tasks.delete(id); }
  };
  const context = vm.createContext({ window, document, URL, Date: { now: () => clock } });
  vm.runInContext(engineSource, context, { filename: 'app.js:TVPlayer' });
  const player = new window.TVPlayer({
    video, shell,
    onError(message) { errors.push(message); },
    onStatus(status, message) { statuses.push({ status, message }); },
    onEngine(engine) { engines.push(engine); },
    onSourceChanged(source) { sources.push(source); },
    onSubtitle(text) { subtitles.push(text); },
    onEnded() { ended += 1; },
    onPlaying() { playing += 1; }
  });
  return {
    player, calls, errors, statuses, engines, subtitles, sources, prepares, seeks, av, listeners, video, object,
    hlsInstances, tasks, events, document, advance,
    get ended() { return ended; }, get playing() { return playing; }
  };
}

const live = (id = 1) => ({ url: `https://example.invalid/live/user/secret/${id}.m3u8`, live: true, title: 'Test' });
const vod = () => ({ url: 'https://example.invalid/movie/user/secret/1.mp4', live: false, title: 'Film' });
const count = (f, method) => f.calls.filter(([name]) => name === method).length;

test('a rapid channel switch invalidates pending AVPlay preparation and all old listeners', () => {
  const f = fixture();
  f.player.play(live(1));
  const old = f.listeners[0];
  f.player.play(live(2));
  assert.equal(count(f, 'av.close'), 1, 'old decoder must close before the next open');
  const before = f.calls.length;
  f.prepares[0].success();
  f.prepares[0].failure();
  old.onerror();
  old.onstreamcompleted();
  old.oncurrentplaytime(4000);
  assert.equal(f.calls.length, before, 'old callbacks must never mutate the new decoder');
  assert.equal(f.ended, 0);
  assert.equal(f.playing, 0);
  assert.equal(f.errors.length, 0);
  f.prepares[1].success();
  assert.equal(count(f, 'av.play'), 1);
  assert.equal(f.player.playing, true);
  assert.equal(f.player.engine, 'AVPlay');
  f.player.stop();
});

test('an AVPlay preparation failure falls back once and detaches its callbacks', () => {
  const f = fixture();
  f.player.play(live());
  f.prepares[0].failure();
  assert.equal(count(f, 'av.close'), 1, 'failed decoder closes immediately');
  f.advance(100);
  assert.deepEqual(f.engines, ['AVPlay', 'HTML5']);
  assert.equal(count(f, 'av.close'), 1);
  assert.equal(f.player.playing, true);
  const before = f.calls.length;
  f.prepares[0].success();
  f.listeners[0].onerror();
  assert.equal(f.calls.length, before);
  f.video.emit('error');
  assert.equal(f.errors.length, 1);
  assert.equal(count(f, 'av.open'), 1, 'browser failure must not start another AVPlay attempt');
  assert.equal(f.player.playing, false);
  assert.ok(!f.errors[0].includes('secret'), 'error text must not leak credentials');
  assert.equal(f.tasks.size, 0);
});

test('HLS uses capped buffers and permits only two fatal network recoveries', () => {
  const f = fixture({ hardware: false, hls: true });
  f.player.play(live());
  const h = f.hlsInstances[0];
  assert.equal(f.player.engine, 'HLS.js');
  assert.equal(h.config.maxBufferLength, 20);
  assert.equal(h.config.maxMaxBufferLength, 30);
  assert.equal(h.config.backBufferLength, 10);
  assert.equal(h.config.enableWorker, true);
  assert.equal(h.config.lowLatencyMode, false);
  assert.deepEqual(h.loads, [live().url]);
  h.emit('error', { fatal: true, type: 'network' });
  f.advance(1000);
  h.emit('error', { fatal: true, type: 'network' });
  f.advance(2000);
  assert.equal(h.networkRecoveries, 2);
  h.emit('error', { fatal: true, type: 'network' });
  assert.equal(h.destroyed, true);
  assert.equal(f.errors.length, 1);
  assert.equal(f.tasks.size, 0);
  h.emit('error', { fatal: true, type: 'network' });
  f.advance(10000);
  assert.equal(h.networkRecoveries, 2, 'late fatal events cannot restart a destroyed HLS instance');
});

test('HLS permits one fatal media recovery and tears down after the next failure', () => {
  const f = fixture({ hardware: false, hls: true });
  f.player.play(live());
  const h = f.hlsInstances[0];
  h.emit('error', { fatal: false, type: 'media' });
  assert.equal(h.mediaRecoveries, 0);
  h.emit('error', { fatal: true, type: 'media' });
  assert.equal(h.mediaRecoveries, 1);
  h.emit('error', { fatal: true, type: 'media' });
  assert.equal(h.destroyed, true);
  assert.equal(f.errors.length, 1);
  assert.equal(f.player.playing, false);
});

test('stop removes HLS, video listeners, scheduled retries, and late events', () => {
  const f = fixture({ hardware: false, hls: true });
  f.player.play(live());
  const h = f.hlsInstances[0];
  h.emit('manifest');
  h.emit('error', { fatal: true, type: 'network' });
  assert.ok(f.tasks.size > 0);
  assert.ok([...f.events.values()].some((set) => set.size > 0));
  f.player.stop();
  assert.equal(h.destroyed, true);
  assert.equal(f.player.playing, false);
  assert.equal(f.player.paused, false);
  assert.equal(f.video.src, '');
  assert.equal(f.tasks.size, 0);
  assert.ok([...f.events.values()].every((set) => set.size === 0));
  const before = f.calls.length;
  h.emit('manifest');
  h.emit('error', { fatal: true, type: 'network' });
  f.video.emit('ended');
  f.advance(30000);
  assert.equal(f.calls.length, before);
  assert.equal(f.ended, 0);
});

test('AVPlay pause/resume and seek obey state and preserve live seeking restrictions', () => {
  const f = fixture();
  f.player.play(vod());
  assert.equal(f.player.togglePause(), false, 'pending preparation cannot pause');
  assert.equal(f.player.seekBy(10), false);
  f.prepares[0].success();
  assert.equal(f.player.togglePause(), true);
  assert.equal(f.player.paused, true);
  assert.equal(count(f, 'av.pause'), 1);
  assert.equal(f.player.seekBy(-30), true);
  assert.deepEqual(f.calls.find(([name]) => name === 'av.seek'), ['av.seek', 1]);
  assert.equal(f.player.togglePause(), true);
  assert.equal(f.player.paused, false);
  assert.equal(count(f, 'av.play'), 2);
  f.player.play(live());
  f.prepares[1].success();
  assert.equal(f.player.seekBy(10), false, 'live streams have no generic VOD seek');
  assert.equal(count(f, 'av.seek'), 1);
  f.player.stop();
  assert.equal(f.player.togglePause(), false);
});

test('native playback supports pause/resume and clamps VOD seeks', () => {
  const f = fixture({ hardware: false });
  f.player.play(vod());
  assert.equal(f.player.togglePause(), true);
  assert.equal(f.player.paused, true);
  assert.equal(f.player.seekBy(1000), true);
  assert.equal(f.video.currentTime, 599.8);
  assert.equal(f.player.seekBy(-1000), true);
  assert.equal(f.video.currentTime, 0);
  assert.equal(f.player.togglePause(), true);
  assert.equal(f.player.paused, false);
  f.player.destroy();
  assert.equal(f.tasks.size, 0);
});

test('AVPlay display rectangles scale the viewport to the fixed 1920×1080 plane', () => {
  const f = fixture();
  f.player.play(live());
  assert.deepEqual(f.calls.find(([name]) => name === 'av.rect'), ['av.rect', 960, 150, 720, 405]);
  f.player.setFullscreen(true);
  assert.deepEqual(f.calls.filter(([name]) => name === 'av.rect').at(-1), ['av.rect', 0, 0, 1920, 1080]);
  assert.ok(f.calls.some((entry) => entry[0] === 'av.displayMethod' && entry[1] === 'PLAYER_DISPLAY_MODE_LETTER_BOX'));
  f.player.stop();
});

test('a stalled stream restarts once, then releases playback and reports a bounded failure', () => {
  const f = fixture({ hardware: false });
  f.player.play(vod());
  assert.equal(count(f, 'video.play'), 1);
  f.advance(30000);
  assert.equal(count(f, 'video.play'), 2, 'first 25-second stall gets one new decoder');
  f.advance(30000);
  assert.equal(count(f, 'video.play'), 2, 'second stall must not loop forever');
  assert.equal(f.errors.length, 1);
  assert.equal(f.tasks.size, 0);
  assert.equal(f.player.playing, false);
});

test('unsupported direct TS and unsafe URLs fail without leaking account data', () => {
  const f = fixture({ hardware: false });
  f.player.play({ ...live(), url: 'https://example.invalid/live/user/secret/1.ts' });
  assert.match(f.errors[0], /\.ts/);
  assert.match(f.errors[0], /HLS/);
  assert.equal(count(f, 'video.play'), 0);
  assert.ok(!f.errors[0].includes('secret'));
  f.player.play({ url: 'javascript:alert(1)', live: true });
  assert.equal(f.errors.length, 2);
  assert.equal(f.tasks.size, 0);
  f.player.destroy();
});

test('absolute AVPlay seeks clamp endpoints and expose seconds without persisting playback data', () => {
  const f = fixture();
  assert.equal(f.player.getPlaybackInfo().canSeek, false);
  f.player.play(vod());
  assert.equal(f.player.seekTo(120), false, 'preparing media cannot seek');
  f.prepares[0].success();
  const info = f.player.getPlaybackInfo();
  assert.equal(info.currentTime, 10);
  assert.equal(info.duration, 600);
  assert.equal(info.canSeek, true);
  assert.equal(info.live, false);
  assert.equal(info.seeking, false);
  assert.equal(f.player.seekTo(123.456), true);
  assert.deepEqual(f.calls.filter(([name]) => name === 'av.seek').at(-1), ['av.seek', 123456]);
  f.player.seekTo(1000);
  assert.deepEqual(f.calls.filter(([name]) => name === 'av.seek').at(-1), ['av.seek', 599000]);
  f.player.seekTo(-10);
  assert.deepEqual(f.calls.filter(([name]) => name === 'av.seek').at(-1), ['av.seek', 1]);
  assert.equal(f.player.seekTo(Infinity), false);
  assert.equal(f.player.seekTo('not-a-time'), false);
  f.player.togglePause();
  assert.equal(f.player.getPlaybackInfo().paused, true);
  assert.equal(f.player.seekTo(240), true, 'paused VOD remains seekable');
  f.player.stop();
  assert.equal(f.player.getPlaybackInfo().currentTime, 0);
  assert.equal(f.player.getPlaybackInfo().duration, 0);
  assert.equal(f.player.getPlaybackInfo().canSeek, false);
});

test('AVPlay async seek completion, failure, and timeout cannot unlock a newer seek', () => {
  const f = fixture({ deferSeek: true });
  f.player.play(vod()); f.prepares[0].success();
  assert.equal(f.player.seekTo(100), true);
  assert.equal(f.player.getPlaybackInfo().seeking, true);
  assert.equal(f.player.seekTo(200), false);
  f.seeks[0].failure();
  assert.equal(f.player.getPlaybackInfo().seeking, false);
  assert.match(f.statuses.at(-1).message, /atlanamadı/);
  assert.equal(f.player.seekTo(200), true);
  f.advance(5000);
  assert.equal(f.player.getPlaybackInfo().seeking, false, 'missing SDK callback times out');
  assert.equal(f.player.seekTo(300), true);
  f.seeks[1].success();
  f.seeks[1].failure();
  assert.equal(f.player.getPlaybackInfo().seeking, true, 'late timed-out completion cannot release a newer seek');
  f.seeks[2].success();
  assert.equal(f.player.getPlaybackInfo().seeking, false);
  assert.equal(f.player.seekTo(400), true);
  f.player.play(vod()); f.prepares[1].success();
  assert.equal(f.player.seekTo(500), true);
  f.seeks[3].success();
  assert.equal(f.player.getPlaybackInfo().seeking, true, 'old decoder completion cannot release a new decoder seek');
  f.seeks[4].success();
  assert.equal(f.player.getPlaybackInfo().seeking, false);
  f.player.stop();
  assert.equal(f.tasks.size, 0);
});

test('native absolute seeking uses actual ranges, clamps endpoints, and chooses the closest gap edge', () => {
  const f = fixture({ hardware: false });
  f.player.play(vod());
  f.video.seekable = { length: 2, start(index) { return index === 0 ? 20 : 200; }, end(index) { return index === 0 ? 100 : 600; } };
  assert.equal(f.player.getPlaybackInfo().canSeek, true);
  assert.equal(f.player.seekTo(0), true);
  assert.equal(f.video.currentTime, 20);
  f.player.seekTo(130);
  assert.equal(f.video.currentTime, 100);
  f.player.seekTo(170);
  assert.equal(f.video.currentTime, 200);
  f.player.seekTo(900);
  assert.equal(f.video.currentTime, 599.8);
  f.video.seekable = { length: 0 };
  assert.equal(f.player.getPlaybackInfo().canSeek, false);
  assert.equal(f.player.seekTo(300), false);
  f.video.duration = Infinity; f.video.currentTime = NaN;
  assert.equal(f.player.getPlaybackInfo().duration, 0);
  assert.equal(f.player.getPlaybackInfo().currentTime, 0);
  f.player.stop();
});

test('live media and unknown VOD duration never advertise or accept timeline seeks', () => {
  const f = fixture();
  f.player.play(live()); f.prepares[0].success();
  assert.equal(f.player.getPlaybackInfo().canSeek, false);
  assert.equal(f.player.seekTo(120), false);
  f.player.play(vod()); f.prepares[1].success();
  f.av.getDuration = () => NaN;
  assert.equal(f.player.getPlaybackInfo().duration, 0);
  assert.equal(f.player.getPlaybackInfo().canSeek, false);
  assert.equal(f.player.seekTo(120), false);
  f.player.stop();
});

test('AVPlay metadata, pause, and rectangle updates make no SDK calls during an async seek', () => {
  const f = fixture({ deferSeek: true });
  f.player.play(vod()); f.prepares[0].success(); f.player.togglePause();
  const initial = f.player.getPlaybackInfo();
  assert.equal(initial.paused, true);
  initial.seekable[0].end = 1; // Public snapshots cannot mutate the internal cache.
  assert.equal(f.player.seekTo(120), true);
  const guarded = ['getCurrentTime', 'getDuration', 'getState', 'pause', 'play', 'setDisplayRect'];
  const originals = guarded.map((name) => [name, f.av[name]]);
  const unexpected = [];
  originals.forEach(([name, method]) => { f.av[name] = (...args) => { unexpected.push(name); return method.apply(f.av, args); }; });
  const cached = f.player.getPlaybackInfo();
  assert.equal(cached.currentTime, 10);
  assert.equal(cached.duration, 600);
  assert.equal(cached.paused, true);
  assert.equal(cached.seeking, true);
  assert.equal(cached.seekable[0].end, 599);
  cached.seekable[0].end = 2;
  assert.equal(f.player.getPlaybackInfo().seekable[0].end, 599);
  assert.equal(f.player.togglePause(), false);
  assert.equal(f.player.seekBy(10), false);
  assert.equal(f.player.seekTo(200), false);
  f.player.setFullscreen(true);
  f.player.refreshRect();
  assert.deepEqual(unexpected, [], 'SDK calls are forbidden until the pending seek callback');
  originals.forEach(([name, method]) => { f.av[name] = method; });
  const rectangles = count(f, 'av.rect');
  f.seeks[0].success();
  assert.equal(count(f, 'av.rect'), rectangles + 1, 'deferred geometry applies after seek completion');
  assert.equal(f.player.getPlaybackInfo().seeking, false);
  assert.equal(f.player.getPlaybackInfo().paused, true);
  f.player.stop();
  assert.equal(f.player._playbackInfo, null, 'ephemeral metadata clears with decoder teardown');
});

test('live AVPlay retries a distinct alternate format once before a bounded HLS browser fallback', () => {
  const f = fixture({ hls: true });
  const first = live(), alternate = first.url.replace('.m3u8', '.ts');
  f.player.play({ ...first, alternativeUrls: [first.url, alternate, 'javascript:ignored'] });
  f.prepares[0].failure();
  f.advance(100);
  assert.equal(f.player.engine, 'AVPlay');
  assert.equal(f.calls.filter(([name]) => name === 'av.open').at(-1)[1], alternate);
  f.prepares[1].failure();
  f.advance(100);
  assert.equal(f.player.engine, 'HLS.js');
  assert.equal(f.hlsInstances[0].loads[0], first.url, 'browser chooses HLS instead of unsupported raw TS');
  assert.equal(count(f, 'av.open'), 2);
  const h = f.hlsInstances[0];
  h.emit('error', { fatal: true, type: 'other' });
  assert.equal(f.errors.length, 1, 'failed browser HLS and unsupported TS exhaust alternatives');
  assert.equal(count(f, 'av.open'), 2);
  assert.equal(f.tasks.size, 0);
  assert.equal(f.sources[1].alternative, true);
  assert.equal(f.sources[1].index, 1);
});

test('native-only playback can automatically switch a raw TS URL to HLS without repeated attempts', () => {
  const f = fixture({ hardware: false });
  const hls = live().url, ts = hls.replace('.m3u8', '.ts');
  f.player.play({ url: ts, alternativeUrls: [hls, ts], live: true });
  assert.equal(f.video.src, hls);
  assert.equal(f.player.playing, true);
  assert.equal(f.errors.length, 0);
  f.video.emit('error');
  assert.equal(f.errors.length, 1);
  assert.equal(f.sources.length, 2);
  f.player.stop();
});

test('AVPlay tracks are sanitized, selectable in supported states, and custom subtitles clear on off/stop', () => {
  const f = fixture();
  f.player.play(vod()); f.prepares[0].success();
  assert.equal(f.player.getAudioTracks()[0].label, 'Türkçe');
  assert.equal(f.player.getAudioTracks()[0].selected, true);
  assert.equal(f.player.selectAudioTrack(1), true);
  assert.equal(f.player.getAudioTracks()[1].selected, true);
  assert.equal(f.player.selectAudioTrack(99), false);
  f.player.togglePause();
  assert.equal(f.player.selectAudioTrack(0), false, 'Samsung only permits audio switching in PLAYING');
  assert.equal(f.player.selectSubtitleTrack(4), true, 'TEXT can switch while PAUSED');
  assert.equal(f.player.getSubtitleTracks()[0].selected, true);
  f.listeners[0].onsubtitlechange(500, '<b>Merhaba</b><br>TV\u0000');
  assert.equal(f.subtitles.at(-1), 'Merhaba\nTV');
  f.advance(500);
  assert.equal(f.subtitles.at(-1), '');
  f.listeners[0].onsubtitlechange(500, 'A'.repeat(700));
  assert.equal(f.subtitles.at(-1).length, 500);
  assert.equal(f.player.selectSubtitleTrack(-1), true);
  f.listeners[0].onsubtitlechange(500, 'Hidden');
  assert.equal(f.subtitles.at(-1), '');
  f.player.stop();
  const count = f.subtitles.length;
  f.listeners[0].onsubtitlechange(500, 'Stale');
  f.advance(1000);
  assert.equal(f.subtitles.length, count);
  assert.equal(f.player.getAudioTracks().length, 0);
});

test('native audio/text tracks render selected cue text and release every cue listener on stop', () => {
  const f = fixture({ hardware: false });
  const handlers = new Map();
  const track = { kind: 'subtitles', label: '<b>Türkçe</b>', language: 'tr', mode: 'showing', activeCues: [{ text: '<i>Altyazı</i>' }],
    addEventListener(name, fn) { handlers.set(name, fn); }, removeEventListener(name) { handlers.delete(name); } };
  f.video.textTracks = [track];
  f.video.audioTracks = [{ language: 'tr', enabled: true }, { language: 'en', enabled: false }];
  f.player.play(vod());
  assert.equal(track.mode, 'disabled', 'subtitles start off');
  assert.equal(f.player.getSubtitleTracks()[0].label, 'Türkçe');
  assert.equal(f.player.selectSubtitleTrack(0), true);
  assert.equal(track.mode, 'hidden');
  handlers.get('cuechange')();
  assert.equal(f.subtitles.at(-1), 'Altyazı');
  assert.equal(f.player.selectAudioTrack(1), true);
  assert.equal(f.video.audioTracks[0].enabled, false);
  assert.equal(f.video.audioTracks[1].enabled, true);
  f.player.stop();
  assert.equal(handlers.size, 0);
  assert.equal(track.mode, 'disabled');
  assert.equal(f.subtitles.at(-1), '');
  assert.equal(f.tasks.size, 0);
});

test('track and aspect controls make no AVPlay calls during asynchronous seeking', () => {
  const f = fixture({ deferSeek: true });
  f.player.play(vod()); f.prepares[0].success();
  assert.equal(f.player.setAspectRatio('fill'), true);
  assert.equal(f.calls.filter(([name]) => name === 'av.displayMethod').at(-1)[1], 'PLAYER_DISPLAY_MODE_AUTO_ASPECT_RATIO');
  assert.equal(f.player.setAspectRatio('stretch'), true);
  assert.equal(f.calls.filter(([name]) => name === 'av.displayMethod').at(-1)[1], 'PLAYER_DISPLAY_MODE_FULL_SCREEN');
  assert.equal(f.player.setAspectRatio('invalid'), false);
  f.player.seekTo(120);
  const names = ['getState', 'getTotalTrackInfo', 'getCurrentStreamInfo', 'setSelectTrack', 'setSilentSubtitle', 'setDisplayMethod'], unexpected = [];
  const originals = names.map((name) => [name, f.av[name]]);
  originals.forEach(([name, method]) => { f.av[name] = (...args) => { unexpected.push(name); return method.apply(f.av, args); }; });
  assert.equal(f.player.getAudioTracks().length, 0);
  assert.equal(f.player.getSubtitleTracks().length, 0);
  assert.equal(f.player.selectAudioTrack(0), false);
  assert.equal(f.player.selectSubtitleTrack(-1), false);
  assert.equal(f.player.setAspectRatio('fit'), false);
  assert.deepEqual(unexpected, []);
  originals.forEach(([name, method]) => { f.av[name] = method; });
  f.seeks[0].success(); f.player.stop();
  const native = fixture({ hardware: false });
  native.player.play(vod());
  assert.equal(native.player.setAspectRatio('fill'), true);
  assert.equal(native.video.style.objectFit, 'cover');
  native.player.play(vod());
  assert.equal(native.video.style.objectFit, 'contain', 'each new playback starts in fit mode');
  native.player.stop();
});

test('HLS audio/subtitle selection uses library track indexes and keeps native subtitles hidden', () => {
  const f = fixture({ hardware: false, hls: true });
  f.player.play(live());
  const h = f.hlsInstances[0];
  h.audioTracks = [{ name: '<b>Türkçe</b>', lang: 'tr' }, { name: 'English', lang: 'en' }];
  h.subtitleTracks = [{ name: 'Türkçe CC', lang: 'tr' }];
  h.audioTrack = 0;
  h.emit('manifest');
  assert.equal(h.subtitleTrack, -1);
  assert.equal(h.subtitleDisplay, false);
  assert.equal(f.player.getAudioTracks()[0].label, 'Türkçe');
  assert.equal(f.player.selectAudioTrack(1), true);
  assert.equal(h.audioTrack, 1);
  assert.equal(f.player.getAudioTracks()[1].selected, true);
  assert.equal(f.player.selectSubtitleTrack(0), true);
  assert.equal(h.subtitleTrack, 0);
  assert.equal(h.subtitleDisplay, false);
  assert.equal(f.player.selectSubtitleTrack(-1), true);
  assert.equal(h.subtitleTrack, -1);
  f.player.stop();
  assert.equal(h.destroyed, true);
});

test('AVPlay recovery waits for the native error stack and ignores callbacks from the failed decoder', () => {
  const f = fixture();
  const alternate = live().url.replace('.m3u8', '.ts');
  f.player.play({ ...live(), alternativeUrls: [alternate] });
  const failed = f.listeners[0];
  f.prepares[0].failure();
  assert.equal(count(f, 'av.close'), 1);
  assert.equal(count(f, 'av.open'), 1, 'next open must never run in the prepare error callback stack');
  assert.equal(f.player.playing, false);
  failed.onerror(); failed.oncurrentplaytime(1000); f.prepares[0].success();
  f.advance(99);
  assert.equal(count(f, 'av.open'), 1);
  f.advance(1);
  assert.equal(count(f, 'av.open'), 2);
  assert.equal(f.calls.filter(([name]) => name === 'av.open').at(-1)[1], alternate);
  f.prepares[1].success();
  assert.equal(f.player.playing, true);
  assert.equal(count(f, 'av.play'), 1);
  f.player.stop();
});

test('stop and a newer explicit play cancel a scheduled AVPlay recovery', () => {
  const stopped = fixture();
  stopped.player.play({ ...live(), alternativeUrls: [live(2).url] });
  stopped.prepares[0].failure(); stopped.player.stop(); stopped.advance(1000);
  assert.equal(count(stopped, 'av.open'), 1);
  assert.equal(stopped.tasks.size, 0);

  const replaced = fixture();
  replaced.player.play({ ...live(), alternativeUrls: [live(2).url] });
  replaced.prepares[0].failure();
  replaced.player.play(live(3));
  replaced.advance(1000);
  assert.equal(count(replaced, 'av.open'), 2, 'old scheduled alternative must not reopen after a new user selection');
  assert.equal(replaced.calls.filter(([name]) => name === 'av.open').at(-1)[1], live(3).url);
  replaced.prepares[1].success();
  assert.equal(replaced.player.playing, true);
  replaced.player.stop();
});

test('only the exact bundled reviewer demo may play a local file, while arbitrary file URLs stay rejected', () => {
  const f = fixture();
  f.document.baseURI = 'file:///opt/apps/example/res/wgt/index.html';
  const sample = 'file:///opt/apps/example/res/wgt/media/orbit-review.mp4';
  f.player.play({ url: sample, packagedDemo: true, live: false, title: 'Yerel örnek' });
  assert.equal(f.calls.filter(([name]) => name === 'av.open').at(-1)[1], sample);
  f.prepares[0].success();
  assert.equal(f.player.playing, true);
  assert.equal(f.player.live, false);
  f.player.play({ url: 'file:///etc/passwd', packagedDemo: true, live: false });
  assert.equal(f.errors.length, 1);
  assert.equal(f.player.playing, false);
  f.player.play({ url: sample, live: false });
  assert.equal(f.errors.length, 2, 'non-demo local requests remain blocked');
  const native = fixture({ hardware: false });
  native.document.baseURI = f.document.baseURI;
  native.player.play({ url: sample, packagedDemo: true, live: false });
  assert.equal(native.video.src, sample);
  assert.equal(native.player.playing, true);
  native.player.stop();
});
