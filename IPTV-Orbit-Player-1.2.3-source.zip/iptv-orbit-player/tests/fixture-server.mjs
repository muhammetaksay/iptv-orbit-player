// Local, synthetic Xtream fixture. Never forwards requests or contacts a provider.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
const base = new URL('./fixtures/', import.meta.url);
const port = Number(process.env.AKIS_FIXTURE_PORT || 4174);
http.createServer(async (request, response) => {
  const url = new URL(request.url, 'http://127.0.0.1');
  response.setHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:4173');
  response.setHeader('Cache-Control', 'no-store');
  if (url.pathname === '/player_api.php') {
    response.setHeader('Content-Type', 'application/json');
    if (url.searchParams.get('username') !== 'test' || url.searchParams.get('password') !== 'test-pass') {
      response.end(JSON.stringify({ user_info: { auth: 0 } })); return;
    }
    const action = url.searchParams.get('action') || '';
    let result;
    if (!action) result = { user_info: { auth: 1, status: 'Active', exp_date: null } };
    else if (/categories$/.test(action)) result = [{ category_id: '1', category_name: 'Yerel test yayını' }, { category_id: '2', category_name: 'İkinci test kategorisi' }];
    else if (action === 'get_live_streams') result = Array.from({ length: 5000 }, (_, i) => ({ stream_id: i + 1, name: ['Yerel Test Kanalı', 'Örnek Spor', 'Örnek Belgesel'][i % 3] + ' ' + (i + 1) }));
    else if (action === 'get_vod_streams') result = [{ stream_id: 10, name: 'Yerel örnek film', container_extension: 'mp4' }];
    else if (action === 'get_series') result = [{ series_id: 100, name: 'Yerel örnek dizi', plot: 'Tamamen yerel ve üretilmiş test içeriği.' }];
    else if (action === 'get_series_info') result = { episodes: { '1': [{ id: 201, episode_num: 1, title: 'İlk test bölümü', container_extension: 'mp4' }], '2': [{ id: 202, episode_num: 1, title: 'İkinci sezon', container_extension: 'mp4' }] } };
    else { response.writeHead(400); response.end('{}'); return; }
    response.end(JSON.stringify(result)); return;
  }
  if (!/^\/(live|movie|series)\/test\/test-pass\//.test(url.pathname)) { response.writeHead(404); response.end(); return; }
  const name = url.pathname.split('/').pop();
  let file, type;
  if (/^\d+\.m3u8$/.test(name)) { file = 'sample.m3u8'; type = 'application/vnd.apple.mpegurl'; }
  else if (/^sample\d\d\.ts$/.test(name)) { file = name; type = 'video/mp2t'; }
  else if (/^\d+\.ts$/.test(name)) { file = 'sample00.ts'; type = 'video/mp2t'; }
  else if (/^\d+\.mp4$/.test(name)) { file = 'sample.mp4'; type = 'video/mp4'; }
  if (!file) { response.writeHead(404); response.end(); return; }
  try {
    const data = await readFile(new URL(file, base));
    response.setHeader('Content-Type', type); response.setHeader('Accept-Ranges', 'bytes');
    const range = /^bytes=(\d+)-(\d*)$/.exec(request.headers.range || '');
    if (range) {
      const start = Number(range[1]), end = range[2] ? Math.min(Number(range[2]), data.length - 1) : data.length - 1;
      if (start > end) { response.writeHead(416); response.end(); return; }
      response.writeHead(206, { 'Content-Range': 'bytes ' + start + '-' + end + '/' + data.length, 'Content-Length': end - start + 1 });
      response.end(data.subarray(start, end + 1));
    } else { response.writeHead(200, { 'Content-Length': data.length }); response.end(data); }
  } catch { response.writeHead(404); response.end(); }
}).listen(port, '127.0.0.1', () => {
  console.log('Local synthetic Xtream API: http://127.0.0.1:' + port);
  console.log('Test only — username: test | password: test-pass');
});
