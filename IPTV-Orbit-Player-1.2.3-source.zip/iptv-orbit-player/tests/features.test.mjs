import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { webcrypto, pbkdf2Sync } from 'node:crypto';

const source = readFileSync(new URL('../features.js', import.meta.url), 'utf8');
function fixture(crypto = webcrypto, decoder = TextDecoder) {
  const window = { crypto, btoa, atob, TextDecoder: decoder };
  vm.runInNewContext(source, { window });
  return window.AkisFeatures;
}
const encode = text => Buffer.from(text, 'utf8').toString('base64');

test('PIN uses random salts and interoperable PBKDF2; matching and wrong PINs differ', async () => {
  const features = fixture();
  const first = await features.createPin('4829');
  const second = await features.createPin('4829');
  assert.notEqual(first.salt, second.salt);
  assert.notEqual(first.hash, second.hash);
  assert.equal(Buffer.from(first.salt, 'base64').length, 16);
  assert.equal(Buffer.from(first.hash, 'base64').length, 32);
  const expected = pbkdf2Sync('4829', Buffer.from(first.salt, 'base64'), 100000, 32, 'sha256').toString('base64');
  assert.equal(first.hash, expected);
  assert.equal(await features.verifyPin('4829', first), true);
  assert.equal(await features.verifyPin('4828', first), false);
  assert.equal(await features.verifyPin('4829x', first), false);
  assert.equal(Object.values(first).some(value => value === '4829'), false);
});

test('PIN fails closed without WebCrypto and rejects malformed or excessive-work records', async () => {
  const features = fixture();
  const record = await features.createPin('1937');
  const unavailable = fixture({ getRandomValues: webcrypto.getRandomValues.bind(webcrypto) });
  await assert.rejects(unavailable.createPin('1937'), { code: 'PIN_CRYPTO_UNAVAILABLE' });
  await assert.rejects(unavailable.verifyPin('1937', record), { code: 'PIN_CRYPTO_UNAVAILABLE' });
  for (const change of [
    { v: 2 }, { algorithm: 'SHA256' }, { iterations: 99999 }, { iterations: 200001 },
    { iterations: '100000' }, { salt: '!!!!' }, { hash: record.hash.slice(0, -1) },
    { salt: Buffer.alloc(17).toString('base64') }, { hash: Buffer.alloc(31).toString('base64') }
  ]) {
    await assert.rejects(features.verifyPin('1937', { ...record, ...change }), { code: 'PIN_RECORD_INVALID' });
  }
  for (const pin of ['', '123', '123456789', '12 34', 1937, '١٩٣٧']) {
    await assert.rejects(features.createPin(pin), { code: 'PIN_INVALID' });
  }
});

test('crypto operation failures never produce PIN records or successful verification', async () => {
  const features = fixture();
  const record = await features.createPin('8173');
  const broken = fixture({
    getRandomValues: webcrypto.getRandomValues.bind(webcrypto),
    subtle: { importKey: () => Promise.reject(new Error('unavailable')), deriveBits() {} }
  });
  await assert.rejects(broken.createPin('8173'), { code: 'PIN_CRYPTO_FAILED' });
  await assert.rejects(broken.verifyPin('8173', record), { code: 'PIN_CRYPTO_FAILED' });
});

test('category keys separate modes and preserve delimiter-containing IDs; search folds Turkish', () => {
  const features = fixture();
  assert.notEqual(features.makeCategoryKey('live', '7'), features.makeCategoryKey('vod', '7'));
  assert.equal(features.makeCategoryKey('series', 7), features.makeCategoryKey('series', '7'));
  assert.deepEqual(JSON.parse(features.makeCategoryKey('live', 'a:b|c')), ['live', 'a:b|c']);
  assert.throws(() => features.makeCategoryKey('film', '7'), { code: 'CATEGORY_MODE_INVALID' });
  assert.throws(() => features.makeCategoryKey('live', {}), { code: 'CATEGORY_ID_INVALID' });
  assert.equal(features.normalizeSearch('  IĞDIR   İSTANBUL Çocuk Şenliği  '), 'igdir istanbul cocuk senligi');
  assert.equal(features.normalizeSearch('Café Pokémon'), 'cafe pokemon');
});

test('EPG decodes UTF-8 base64 and prefers Unix times over ambiguous server dates', () => {
  const features = fixture();
  const [entry] = features.normalizeEPG([{
    id: 9, title: encode('Çocuk Şenliği'), description: encode('İlk bölüm — iyi seyirler.'),
    start_timestamp: '1794650400', stop_timestamp: '1794654000',
    start: '2026-11-14 12:00:00', end: '2026-11-14 13:00:00'
  }]);
  assert.equal(entry.title, 'Çocuk Şenliği');
  assert.equal(entry.description, 'İlk bölüm — iyi seyirler.');
  assert.equal(entry.startMs, 1794650400000);
  assert.equal(entry.endMs, 1794654000000);
  assert.equal(entry.startText, '2026-11-14 12:00:00');
  assert.equal(entry.timeSource, 'unix');
  assert.equal(entry.id, '9');
});

test('EPG respects explicit offsets, keeps zone-less dates as labels and rejects invalid dates', () => {
  const features = fixture();
  const rows = features.normalizeEPG([
    { id: 'server', title: 'Akşam Haberleri', start: '2026-11-14 21:00:00', end: '2026-11-14 22:00:00' },
    { id: 'offset', title: encode('Canlı'), start: '2026-11-14T12:00:00+03:00', end: '2026-11-14T13:00:00+03:00' },
    { id: 'invalid', title: 'Program', start: '2026-02-30T12:00:00Z', end: '2026-02-30T13:00:00Z' }
  ]);
  assert.equal(rows[0].id, 'offset');
  assert.equal(rows[0].startMs, Date.parse('2026-11-14T09:00:00Z'));
  assert.equal(rows[0].timeSource, 'offset');
  assert.equal(rows[1].id, 'server');
  assert.equal(rows[1].startMs, null);
  assert.equal(rows[1].endMs, null);
  assert.equal(rows[1].timeSource, 'server');
  assert.equal(rows[2].startMs, null);
});

test('EPG keeps malformed/plain text, bounds rows and does not mutate provider data', () => {
  const features = fixture();
  const rows = [{ id: 'raw', title: 'News', description: '/w==', start_timestamp: 1794650400000, end_timestamp: 1794650300000 }];
  const before = JSON.stringify(rows);
  const entry = features.normalizeEPG(rows)[0];
  assert.equal(entry.title, 'News');
  assert.equal(entry.description, '/w==');
  assert.equal(entry.startMs, 1794650400000);
  assert.equal(entry.endMs, null);
  assert.equal(JSON.stringify(rows), before);
  assert.equal(features.normalizeEPG([rows[0], rows[0]]).length, 1);
  assert.equal(features.normalizeEPG(Array.from({ length: 1000 }, (_, i) => ({ id: i, title: 'Program ' + i }))).length, 300);
  assert.equal(features.normalizeEPG(null).length, 0);
  const noDecoder = fixture(webcrypto, null);
  assert.equal(noDecoder.normalizeEPG([{ title: encode('Şeker ve Çay') }])[0].title, 'Şeker ve Çay');
});
