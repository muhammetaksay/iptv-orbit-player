/* AKIŞ TV feature utilities — MIT. No storage, requests or viewing history. */
(function (global) {
  'use strict';

  const PIN_ITERATIONS = 100000;
  const PIN_MAX_ITERATIONS = 200000;
  const EPG_LIMIT = 300;

  function problem(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  function cryptoProvider() {
    const provider = global.crypto;
    if (!provider || typeof provider.getRandomValues !== 'function' || !provider.subtle ||
        typeof provider.subtle.importKey !== 'function' || typeof provider.subtle.deriveBits !== 'function') {
      throw problem('PIN_CRYPTO_UNAVAILABLE', 'Bu TV güvenli PIN oluşturmayı desteklemiyor. Kategori kilidi etkinleştirilmedi.');
    }
    return provider;
  }

  function validPin(pin) { return typeof pin === 'string' && /^\d{4,8}$/.test(pin); }

  function base64(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return global.btoa(binary);
  }

  function unbase64(value) {
    if (typeof value !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
      throw new Error('Invalid base64');
    }
    const binary = global.atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    if (base64(bytes) !== value) throw new Error('Non-canonical base64');
    return bytes;
  }

  async function derive(pin, salt, iterations) {
    const provider = cryptoProvider();
    const bytes = new Uint8Array(pin.length);
    for (let i = 0; i < pin.length; i++) bytes[i] = pin.charCodeAt(i);
    try {
      const key = await provider.subtle.importKey('raw', bytes, { name: 'PBKDF2' }, false, ['deriveBits']);
      return new Uint8Array(await provider.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
    } catch (_) {
      throw problem('PIN_CRYPTO_FAILED', 'Güvenli PIN işlemi tamamlanamadı. Kilit açılmadı.');
    } finally {
      bytes.fill(0);
    }
  }

  async function createPin(pin) {
    if (!validPin(pin)) throw problem('PIN_INVALID', 'PIN 4–8 rakamdan oluşmalı.');
    const provider = cryptoProvider();
    const salt = new Uint8Array(16);
    let hash;
    try {
      provider.getRandomValues(salt);
      hash = await derive(pin, salt, PIN_ITERATIONS);
      return { v: 1, algorithm: 'PBKDF2-SHA256', iterations: PIN_ITERATIONS, salt: base64(salt), hash: base64(hash) };
    } catch (error) {
      if (error && error.code) throw error;
      throw problem('PIN_CRYPTO_FAILED', 'Güvenli PIN işlemi tamamlanamadı. PIN kaydedilmedi.');
    } finally {
      salt.fill(0);
      if (hash) hash.fill(0);
    }
  }

  function readPinRecord(record) {
    try {
      if (!record || typeof record !== 'object' || Array.isArray(record) || record.v !== 1 ||
          record.algorithm !== 'PBKDF2-SHA256' || !Number.isInteger(record.iterations) ||
          record.iterations < PIN_ITERATIONS || record.iterations > PIN_MAX_ITERATIONS ||
          typeof record.salt !== 'string' || record.salt.length !== 24 ||
          typeof record.hash !== 'string' || record.hash.length !== 44) throw new Error('Invalid record');
      const salt = unbase64(record.salt);
      const hash = unbase64(record.hash);
      if (salt.length !== 16 || hash.length !== 32) throw new Error('Invalid length');
      return { salt, hash, iterations: record.iterations };
    } catch (_) {
      throw problem('PIN_RECORD_INVALID', 'Kayıtlı PIN bilgisi geçersiz. Kategorilerin kilidi açılmadı.');
    }
  }

  async function verifyPin(pin, record) {
    const saved = readPinRecord(record);
    let actual;
    try {
      cryptoProvider();
      if (!validPin(pin)) return false;
      actual = await derive(pin, saved.salt, saved.iterations);
      let difference = 0;
      // Compare all bytes; no early return based on a matching prefix.
      for (let i = 0; i < saved.hash.length; i++) difference |= actual[i] ^ saved.hash[i];
      return difference === 0;
    } finally {
      saved.salt.fill(0);
      saved.hash.fill(0);
      if (actual) actual.fill(0);
    }
  }

  function makeCategoryKey(mode, id) {
    if (mode !== 'live' && mode !== 'vod' && mode !== 'series') {
      throw problem('CATEGORY_MODE_INVALID', 'Kategori türü geçersiz.');
    }
    if ((typeof id !== 'string' && typeof id !== 'number') || (typeof id === 'number' && !Number.isFinite(id)) || String(id).length === 0) {
      throw problem('CATEGORY_ID_INVALID', 'Kategori kimliği geçersiz.');
    }
    return JSON.stringify([mode, String(id)]);
  }

  function normalizeSearch(value) {
    let text = value == null ? '' : String(value);
    if (typeof text.normalize === 'function') text = text.normalize('NFKD');
    return text.replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/ı/g, 'i').replace(/\s+/g, ' ').trim();
  }

  function primitiveText(value, limit) {
    return typeof value === 'string' || typeof value === 'number' ? String(value).slice(0, limit) : '';
  }

  function decodeEPGText(value, limit) {
    const original = primitiveText(value, 32768);
    const encoded = original.replace(/\s+/g, '');
    if (!encoded || encoded.length % 4 === 1 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) return original.slice(0, limit);
    try {
      const padded = encoded + '='.repeat((4 - encoded.length % 4) % 4);
      const bytes = unbase64(padded);
      let decoded;
      if (typeof global.TextDecoder === 'function') decoded = new global.TextDecoder('utf-8', { fatal: true }).decode(bytes);
      else {
        let escaped = '';
        for (let i = 0; i < bytes.length; i++) escaped += '%' + ('0' + bytes[i].toString(16)).slice(-2);
        decoded = decodeURIComponent(escaped);
      }
      if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(decoded)) return original.slice(0, limit);
      return decoded.slice(0, limit);
    } catch (_) {
      return original.slice(0, limit);
    }
  }

  function unixTime(value) {
    if (typeof value !== 'number' && (typeof value !== 'string' || !/^\d+(?:\.\d{1,3})?$/.test(value.trim()))) return null;
    const number = Number(value);
    const milliseconds = number < 100000000000 ? number * 1000 : number;
    return Number.isFinite(milliseconds) && milliseconds > 0 && milliseconds <= 8640000000000000 ? Math.round(milliseconds) : null;
  }

  function offsetTime(value) {
    if (typeof value !== 'string') return null;
    const input = value.trim();
    const match = input.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d{1,3})?)?(Z|[+-]\d{2}:?\d{2})$/i);
    if (!match) return null;
    const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
    const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
    if (month < 1 || month > 12 || day < 1 || day > days || Number(match[4]) > 23 || Number(match[5]) > 59 || Number(match[6] || 0) > 59) return null;
    const milliseconds = Date.parse(input.replace(' ', 'T'));
    return Number.isFinite(milliseconds) ? milliseconds : null;
  }

  function firstTime(values, parse) {
    for (let i = 0; i < values.length; i++) {
      const result = parse(values[i]);
      if (result !== null) return result;
    }
    return null;
  }

  function firstText(values, limit) {
    for (let i = 0; i < values.length; i++) {
      const text = primitiveText(values[i], limit).trim();
      if (text) return text;
    }
    return '';
  }

  function normalizeEPG(rows) {
    if (!Array.isArray(rows)) return [];
    const result = [], seen = Object.create(null);
    const count = Math.min(rows.length, EPG_LIMIT);
    for (let i = 0; i < count; i++) {
      const row = rows[i];
      if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
      const title = decodeEPGText(row.title || row.name, 512).trim();
      const description = decodeEPGText(row.description, 4000).trim();
      const startText = firstText([row.start, row.start_datetime, row.start_time], 80);
      const endText = firstText([row.end, row.stop, row.end_datetime, row.end_time], 80);
      const unixStart = firstTime([row.start_timestamp, row.start_ts, row.start], unixTime);
      const unixEnd = firstTime([row.end_timestamp, row.stop_timestamp, row.end_ts, row.end, row.stop], unixTime);
      let startMs = unixStart === null ? firstTime([row.start, row.start_datetime, row.start_time], offsetTime) : unixStart;
      let endMs = unixEnd === null ? firstTime([row.end, row.stop, row.end_datetime, row.end_time], offsetTime) : unixEnd;
      if (startMs !== null && endMs !== null && endMs <= startMs) endMs = null;
      if (!title && !description && !startText && !endText && startMs === null && endMs === null) continue;
      const sourceId = firstText([row.id, row.epg_id], 200);
      const key = JSON.stringify([sourceId, title, startMs, endMs, startText, endText]);
      if (seen[key]) continue;
      seen[key] = true;
      result.push({
        id: sourceId || key, title: title || 'Program', description, startMs, endMs, startText, endText,
        timeSource: unixStart !== null || unixEnd !== null ? 'unix' : startMs !== null || endMs !== null ? 'offset' : startText || endText ? 'server' : 'unknown',
        order: i
      });
    }
    result.sort(function (a, b) {
      if (a.startMs === null) return b.startMs === null ? a.order - b.order : 1;
      if (b.startMs === null) return -1;
      return a.startMs - b.startMs || a.order - b.order;
    });
    return result.map(function (row) {
      delete row.order;
      return row;
    });
  }

  global.AkisFeatures = Object.freeze({ createPin, verifyPin, makeCategoryKey, normalizeSearch, normalizeEPG });
})(typeof window === 'undefined' ? globalThis : window);
