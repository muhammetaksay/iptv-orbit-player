# Original offline demonstration media

`orbit-review.mp4` is the original 120-second demonstration video created for this application. It is finite local media, not a live broadcast or provider catalogue. All demo list rows intentionally open this same file. It has H.264 video, two synthetic AAC tone tracks and no embedded subtitles. It is provided under the MIT license in this directory. No external subscription or account is needed to play it.
