# IPTV Orbit Player — eksiksiz kaynak kodları

İstenen dört ana dosyanın ve iki yardımcı modülün kısaltılmamış dökümü: index.html, style.css, app.js, config.xml, features.js ve experience.js. HLS.js ve lisansları `vendor/` içinde ayrıca teslim edilir. İsteğe bağlı hesapsız demoda kullanılan özgün 120 saniyelik MP4 ve MIT lisansı `media/` içinde bulunur; ikili video bu metin dökümüne gömülmez. Kurulum için README.md dosyasını izleyin.

## index.html

```html
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=1920">
  <meta name="theme-color" content="#0b1118">
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' file:; style-src 'self' 'unsafe-inline'; connect-src 'self' http: https:; img-src 'self' data: blob: http: https:; media-src 'self' blob: http: https:; object-src 'self'; worker-src 'self' blob:; child-src 'self' blob:; base-uri 'self'; form-action 'none'">
  <title>IPTV Orbit Player</title>
  <meta name="application-name" content="IPTV Orbit Player">
  <link rel="icon" href="icon.png" type="image/png">
  <link rel="stylesheet" href="style.css">
  <script src="$WEBAPIS/webapis/webapis.js" defer></script>
  <script src="vendor/hls.min.js" defer></script>
  <script src="features.js" defer></script>
  <script src="experience.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
  <div class="app-shell">
    <header class="app-header">
      <div id="brand" class="brand" aria-label="IPTV Orbit Player"><img class="brand-icon" src="icon.png" width="36" height="36" alt="" aria-hidden="true"><span>IPTV Orbit Player</span></div>
      <div class="header-divider" aria-hidden="true"></div>
      <span class="header-caption">Ekran senin.</span>
      <div class="header-spacer"></div>
      <span id="connection-status" class="connection-status">Bağlantı bekleniyor</span>
      <time id="clock" class="clock" aria-label="Saat">--:--</time>
      <button id="home-button" class="header-button" data-action="home" data-nav aria-label="Ana ekran">⌂ <span>Ana ekran</span></button>
      <button id="settings-button" class="header-button" data-action="settings" data-nav aria-label="Hesap ve giriş ayarları">⚙ <span>Hesap</span></button>
      <button id="privacy-button" class="header-button" type="button" data-action="privacy" data-nav aria-label="Bilgi ve gizlilik">ⓘ <span>Bilgi ve gizlilik</span></button>
    </header>

    <main class="main-content">
      <section id="login-screen" class="screen login-screen" aria-labelledby="login-title">
        <div class="login-story">
          <div class="eyebrow"><span class="live-dot"></span> SENİN İÇERİĞİN. SENİN EKRANIN.</div>
          <h1 id="login-title">İyi seyirler<br>burada başlar<span class="accent">.</span></h1>
          <p class="hero-description">Canlı yayınlar, filmler ve diziler.<br>Hepsi tek yerde, kumandanın ucunda.</p>
          <div class="hero-art" aria-hidden="true">
            <div class="art-orbit orbit-one"></div><div class="art-orbit orbit-two"></div>
            <div class="art-screen"><span class="art-screen-line"></span><span class="art-play">▶</span><div class="art-progress"><i></i></div><span class="art-time">AKIŞTA KAL</span></div>
            <div class="art-tag art-tag-live"><span class="live-dot"></span> CANLI</div>
            <div class="art-tag art-tag-hd">HD <span>kalitesinde</span></div>
          </div>
          <div class="login-features"><span>↔ Kumandayla kolay gezinme</span><span>◈ Doğrudan TV'de oynatma</span></div>
        </div>
        <div class="login-panel">
          <div class="login-panel-heading"><span class="panel-kicker">HOŞ GELDİN</span><button id="login-privacy-button" class="login-privacy-button" type="button" data-action="privacy" data-nav>Bilgi ve gizlilik</button></div>
          <h2>Hesabını bağla</h2>
          <p class="panel-description">Xtream Codes sağlayıcından aldığın bilgileri gir.</p>
          <form id="login-form" autocomplete="off">
            <label for="server-url">Sunucu adresi</label>
            <input id="server-url" name="server" type="url" placeholder="https://sunucu.com:8080" inputmode="url" autocomplete="url" spellcheck="false" aria-describedby="remember-note" data-nav required>
            <label for="username">Kullanıcı adı</label>
            <input id="username" name="username" type="text" placeholder="Kullanıcı adın" autocomplete="username" spellcheck="false" aria-describedby="remember-note" data-nav required>
            <label for="password">Şifre</label>
            <input id="password" name="password" type="password" placeholder="Şifren" autocomplete="current-password" aria-describedby="remember-note" data-nav required>
            <p id="remember-note" class="remember-note">Bağlan ile sunucu adresi, kullanıcı adı ve şifre giriş ve yayın erişimi için seçtiğin sağlayıcıya gönderilir. Otomatik giriş için TV'de düz metin saklanır; hesabı sıfırlayana veya uygulama verileri silinene kadar tutulur.</p>
            <p id="login-message" class="form-message" role="status" aria-live="polite"></p>
            <button id="login-button" class="button button-primary login-submit" type="submit" aria-describedby="remember-note" data-nav>Bağlan ve izlemeye başla <span aria-hidden="true">→</span></button>
            <button class="button button-quiet demo-button" type="button" data-action="demo" data-nav>Hesapsız yerel örneği izle <span aria-hidden="true">↗</span></button>
          </form>
          <p class="provider-note">İçerik veya abonelik sağlanmaz. Hesapsız deneme, paketteki 120 saniyelik özgün MIT videoyu çevrimdışı oynatır.</p>
        </div>
      </section>

      <section id="home-screen" class="screen home-screen" aria-labelledby="home-title" hidden>
        <div class="home-welcome"><div><span class="eyebrow">HER AN İÇİN BİR AKIŞ</span><h1 id="home-title">Bugün ne izliyoruz?</h1><p>Bir dünya içerik, sadece birkaç tuş uzağında.</p></div><div class="home-actions"><button id="global-search-button" class="button button-secondary global-search-button" type="button" data-action="global-search" data-nav><span aria-hidden="true">⌕</span> Tüm içeriklerde ara</button><div class="account-badge"><span class="account-avatar" aria-hidden="true">◈</span><div><span id="account-name">Hesabım</span><small>Geçerlilik: <span id="account-expiry">—</span></small></div></div></div></div>
        <div class="mode-cards">
          <button class="mode-card mode-live" data-mode="live" data-nav><span class="card-topline"><span class="live-pill"><i></i> ŞİMDİ YAYINDA</span><span class="card-number">01</span></span><span class="mode-visual visual-live" aria-hidden="true"><span class="broadcast-ring"></span><span class="broadcast-ring ring-two"></span><span class="broadcast-dot"></span></span><span class="card-copy"><span class="card-label">Canlı TV</span><span class="card-description">Dünyaya anında bağlan.</span></span><span class="card-arrow" aria-hidden="true">↗</span></button>
          <button class="mode-card mode-vod" data-mode="vod" data-nav><span class="card-topline"><span class="card-kicker">SİNEMA ZAMANI</span><span class="card-number">02</span></span><span class="mode-visual visual-vod" aria-hidden="true"><span class="film-frame frame-back"></span><span class="film-frame frame-front">▶</span></span><span class="card-copy"><span class="card-label">Filmler</span><span class="card-description">Yeni bir hikâyeye dal.</span></span><span class="card-arrow" aria-hidden="true">↗</span></button>
          <button class="mode-card mode-series" data-mode="series" data-nav><span class="card-topline"><span class="card-kicker">BÖLÜM BÖLÜM KEŞFET</span><span class="card-number">03</span></span><span class="mode-visual visual-series" aria-hidden="true"><span class="episode-tile tile-back"></span><span class="episode-tile tile-middle"></span><span class="episode-tile tile-front">▶<small>SONRAKİ BÖLÜM</small></span></span><span class="card-copy"><span class="card-label">Diziler</span><span class="card-description">Sıradaki favorini bul.</span></span><span class="card-arrow" aria-hidden="true">↗</span></button>
        </div>
        <div class="home-bottom"><span><i class="live-dot"></i> Büyük ekran ve kumandayla kullanım için tasarlandı.</span><span class="home-bottom-mark">PRESS PLAY. AKIŞTA KAL.</span></div>
      </section>

      <section id="search-screen" class="screen search-screen" aria-labelledby="searchall-title" hidden>
        <div class="searchall-heading"><div><span class="eyebrow">TEK ARAMA, TÜM İÇERİKLER</span><h1 id="searchall-title">Ne izlemek istersin?</h1></div><div class="search-wrap searchall-input-wrap"><span aria-hidden="true">⌕</span><label class="sr-only" for="searchall-input">Tüm kanallar, filmler ve dizilerde ara</label><input id="searchall-input" type="search" placeholder="Kanal, film veya dizi adı…" maxlength="100" autocomplete="off" spellcheck="false" data-nav readonly></div></div>
        <p id="searchall-status" class="searchall-status" role="status" aria-live="polite">Aramak için bir içerik adı yaz.</p>
        <div id="searchall-results" class="searchall-results" role="list" aria-label="Tüm içeriklerde arama sonuçları"></div>
        <div class="searchall-pagination"><button id="searchall-prev" class="button button-secondary" type="button" data-action="search-prev" data-nav disabled>← Önceki</button><button id="searchall-next" class="button button-secondary" type="button" data-action="search-next" data-nav disabled>Sonraki →</button></div>
      </section>

      <section id="browser-screen" class="screen browser-screen" aria-labelledby="browser-title" hidden>
        <div class="browser-heading"><div><span class="eyebrow">KEŞFET & İZLE</span><h1 id="browser-title">Canlı TV</h1><p id="browser-subtitle">Kategorini seç, akışa katıl.</p></div><div class="search-wrap"><span aria-hidden="true">⌕</span><input id="search-input" type="search" placeholder="Listede ara…" aria-label="Kanal veya içerik ara" spellcheck="false" data-nav></div></div>
        <div class="browser-columns">
          <aside class="category-panel"><div class="section-heading"><h2>Kategoriler</h2><button id="category-settings-button" class="category-settings-button" type="button" data-action="category-settings" data-nav aria-label="Kategorileri gizle veya PIN ile kilitle">Düzenle</button></div><div id="category-list" class="virtual-list category-list" role="list" aria-label="Kategoriler"><div id="category-spacer" class="list-spacer"></div><div id="category-window" class="list-window"></div></div></aside>
          <section class="streams-panel" aria-label="İçerik listesi"><div class="section-heading"><h2>İçerikler</h2><span class="section-hint">SEÇ & İZLE</span></div><div id="stream-list" class="virtual-list stream-list" role="list" aria-label="Kanallar ve içerikler"><div id="stream-spacer" class="list-spacer"></div><div id="stream-window" class="list-window"></div></div></section>
          <aside class="details-panel" aria-label="Yayın önizlemesi ve bilgileri">
            <div id="player-shell" class="player-shell">
              <object id="av-player" type="application/avplayer" aria-label="Samsung donanım oynatıcısı"></object>
              <video id="video" playsinline preload="none" aria-label="Video oynatıcı"></video>
              <div id="subtitle-display" class="subtitle-display" aria-live="off" hidden></div>
              <div id="digit-channel-overlay" class="digit-channel-overlay" role="status" aria-live="polite" hidden><span class="digit-channel-caption">KANAL</span><strong id="digit-channel-number">—</strong><span id="digit-channel-label">Kanal seçiliyor</span></div>
              <div id="player-placeholder" class="player-placeholder"><span class="placeholder-icon" aria-hidden="true">▶</span><span id="placeholder-label">İzlemek için bir içerik seç</span><small>Önizleme burada görünür</small></div>
              <div id="player-overlay" class="player-overlay" hidden>
                <div class="overlay-top"><span class="overlay-brand">IPTV Orbit Player</span><div class="overlay-tools"><span id="overlay-state">Oynatılıyor</span><button id="player-settings-button" class="button overlay-settings-button" type="button" data-action="player-settings" data-nav>Oynatıcı ayarları</button></div></div>
                <div class="overlay-bottom">
                  <h2 id="overlay-title"></h2>
                  <p id="overlay-hint">↑ ↓ Kanal değiştir · Enter Kontroller · Geri Küçült</p>
                  <div id="seek-controls" class="seek-controls" aria-label="Film ve bölüm oynatma kontrolleri" hidden>
                    <div class="seek-times"><span id="seek-position">00:00:00</span><span id="seek-duration">--:--:--</span></div>
                    <div id="seek-track" class="seek-track" role="slider" tabindex="0" data-nav data-action="seek" aria-label="Oynatma konumu" aria-orientation="horizontal" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-valuetext="00:00:00"><div id="seek-fill" class="seek-fill"></div><span id="seek-thumb" class="seek-thumb" aria-hidden="true"></span></div>
                    <div class="seek-actions"><p id="seek-help">← / → Seç · OK Atla · ↓ Zamana git</p><button id="seek-time-button" class="button seek-time-button" type="button" data-action="seek-time" data-nav>Zamana git</button></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="detail-info"><div class="detail-kicker"><span class="live-dot"></span><span id="playback-status" role="status" aria-live="polite">Oynatmaya hazır</span></div><div class="detail-heading"><img id="detail-image" referrerpolicy="no-referrer" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="" hidden><h2 id="detail-title">Bir şeyler keşfet</h2></div><p id="detail-meta" class="detail-meta">Kumandanla seç, büyük ekranda izle.</p><div id="epg-summary" class="epg-summary" aria-label="Şimdiki ve sonraki program" hidden><div class="epg-row"><span class="epg-label">ŞİMDİ</span><span id="epg-now-title" class="epg-title">Yayın bilgisi bekleniyor</span><span id="epg-now-time" class="epg-time">--:--</span></div><div class="epg-row"><span class="epg-label">SONRA</span><span id="epg-next-title" class="epg-title">—</span><span id="epg-next-time" class="epg-time">--:--</span></div></div><p id="detail-description" class="detail-description">Soldaki kategorilerden birini seçerek içeriklere göz atabilirsin.</p><div class="player-actions"><button id="watch-button" class="button button-primary" data-action="watch" data-nav><span aria-hidden="true">▶</span> Tam ekran</button><button id="epg-button" class="button button-secondary" type="button" data-action="programme" data-nav hidden>Yayın akışı</button><button id="retry-button" class="button button-secondary" data-action="retry" data-nav aria-label="Yayını yeniden dene">↻ Tekrar dene</button><button id="pause-button" class="button button-secondary" data-action="pause" data-nav>Duraklat</button><button id="format-button" class="button button-secondary" data-action="format" data-nav>Biçim: HLS</button></div></div>
          </aside>
        </div>
      </section>
    </main>

    <footer class="app-footer"><div id="key-hints"><span class="key">↑ ↓ ← →</span> Gezin <span class="key">OK</span> Seç <span class="key">↩</span> Geri</div><span class="footer-wordmark">KENDİ İÇERİĞİN. ÖZGÜRCE.</span></footer>
  </div>
  <div id="busy-indicator" class="busy-indicator" role="status" hidden><span class="spinner" aria-hidden="true"></span><span>Yükleniyor…</span></div>
  <div id="toast" class="toast" role="status" aria-live="polite" hidden></div>
  <div id="feature-dialog" class="dialog-backdrop feature-dialog" role="dialog" aria-modal="true" aria-labelledby="feature-title" aria-describedby="feature-description" hidden><div class="dialog-card feature-card"><div class="feature-heading"><div><span class="panel-kicker">IPTV Orbit Player</span><h2 id="feature-title">Ayarlar</h2></div><button id="feature-back" class="button button-secondary" type="button" data-action="feature-back" data-nav>Geri</button></div><p id="feature-description"></p><div id="feature-content" class="feature-content"></div></div></div>
  <div id="dialog" class="dialog-backdrop" role="dialog" aria-modal="true" aria-labelledby="dialog-title" aria-describedby="dialog-message" hidden>
    <div class="dialog-card">
      <span class="panel-kicker">IPTV Orbit Player</span><h2 id="dialog-title">Hesap ayarları</h2><p id="dialog-message"></p>
      <div id="seek-time-field" class="seek-time-field" hidden><label id="seek-time-title" for="seek-time-input">Saat : Dakika : Saniye</label><input id="seek-time-input" type="text" inputmode="numeric" autocomplete="off" spellcheck="false" placeholder="00:00:00" maxlength="8" aria-describedby="seek-time-error" data-nav readonly><p id="seek-time-error" class="seek-time-error" role="alert"></p></div>
      <div id="pin-field" class="pin-field" hidden><label for="pin-input">PIN (4–8 rakam)</label><input id="pin-input" type="password" inputmode="numeric" autocomplete="off" placeholder="••••" minlength="4" maxlength="8" aria-describedby="pin-error" data-nav readonly><p id="pin-error" class="pin-error" role="alert"></p></div>
      <div class="dialog-actions"><button id="dialog-confirm" class="button button-primary" data-action="confirm" data-nav>Onayla</button><button id="dialog-cancel" class="button button-secondary" data-action="cancel" data-nav>Vazgeç</button></div>
    </div>
  </div>
</body>
</html>

```

## style.css

```css
:root{color-scheme:dark;--bg:#0b1118;--panel:#111a24;--panel-raised:#192430;--line:#27333f;--text:#f0f4f6;--muted:#a4b1bd;--teal:#61ead0;--amber:#efc27b;--focus:#a4ffe9}
*{box-sizing:border-box}
[hidden]{display:none!important}
html,body{width:100%;height:100%;margin:0}
body{overflow:hidden;background:var(--bg);color:var(--text);font-family:"Segoe UI",Arial,sans-serif;font-size:24px;-webkit-font-smoothing:antialiased}
button,input{font:inherit}
button{cursor:pointer;color:inherit;-webkit-tap-highlight-color:transparent}
button,input{-webkit-appearance:none;border-radius:12px}
button{border:1px solid transparent}
button:focus,input:focus{outline:none}
button:focus,input:focus{outline:3px solid var(--focus);outline-offset:4px;box-shadow:0 0 0 7px rgba(97,234,208,.12)}
.is-focused{outline:3px solid var(--focus)!important;outline-offset:4px;box-shadow:0 0 0 7px rgba(97,234,208,.12)!important}
button:focus-visible,input:focus-visible{outline:3px solid var(--focus);outline-offset:4px;box-shadow:0 0 0 7px rgba(97,234,208,.12)}
button:disabled{opacity:.4;cursor:default}
button:not(:disabled):active{border-color:var(--focus)}
h1,h2,p{margin:0}
.app-shell{height:100%;padding:32px 54px 18px;background:radial-gradient(ellipse at 20% 0,rgba(26,68,67,.14),transparent 50%)}
.app-header{display:flex;align-items:center;height:76px;margin-bottom:26px}
.brand{display:flex;align-items:center;flex-shrink:0;font-size:28px;font-weight:700;letter-spacing:-.4px;white-space:nowrap}
.brand-icon{display:block;flex-shrink:0;width:36px;height:36px;margin-right:12px;border-radius:8px}
.header-divider{width:1px;height:26px;background:var(--line);margin:0 24px}
.header-caption{font-size:21px;color:var(--muted)}
.header-spacer{flex:1}
.connection-status{font-size:18px;color:var(--muted);margin-right:30px;max-width:290px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.connection-status::before{content:"";display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--teal);margin-right:9px;vertical-align:middle}
.clock{font-variant-numeric:tabular-nums;font-size:27px;font-weight:600;margin-right:28px}
.header-button{background:#151e28;font-size:21px;padding:13px 19px;margin-left:12px;border:1px solid #293643}
.header-button span{margin-left:6px}
.main-content{height:calc(100% - 148px)}
.screen{height:100%;min-height:0}
.app-footer{height:46px;display:flex;align-items:flex-end;justify-content:space-between;color:#8796a5;font-size:18px}
#key-hints{display:flex;align-items:center;white-space:pre}
.key{display:inline-block;border:1px solid #394653;border-radius:5px;min-width:31px;text-align:center;font-size:15px;padding:3px 7px;margin:0 10px 0 23px;color:#d5dee5}
.key:first-child{margin-left:0}.footer-wordmark{font-size:14px;letter-spacing:2px;color:#697d8c}
.eyebrow{font-size:16px;font-weight:700;letter-spacing:2.7px;color:var(--teal)}
.live-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--teal);margin-right:9px;vertical-align:middle;flex-shrink:0}
.accent{color:var(--teal)}
.login-screen{display:flex;align-items:center;justify-content:space-between;max-width:1640px;margin:0 auto}
.login-story{position:relative;width:54%;padding:0 45px 0 0;height:100%;display:flex;flex-direction:column;justify-content:center}
.login-story h1{font-size:78px;line-height:1.08;letter-spacing:-3px;margin:27px 0 24px;font-weight:700}
.hero-description{font-size:27px;line-height:1.55;color:var(--muted)}
.hero-art{height:260px;width:510px;position:relative;margin:18px 0 8px 14px}
.art-screen{position:absolute;left:82px;top:35px;width:339px;height:190px;transform:rotate(-7deg);border:1px solid #49646a;border-radius:17px;background:linear-gradient(135deg,#234449,#152632 56%,#263447);box-shadow:0 20px 60px #030b0f}
.art-screen-line{position:absolute;left:17px;right:17px;top:16px;height:3px;background:linear-gradient(90deg,var(--teal) 12%,#426069 12%);border-radius:3px}
.art-play{position:absolute;left:147px;top:56px;font-size:46px;color:var(--teal);text-shadow:0 0 40px #46c9b175}
.art-progress{position:absolute;left:24px;right:24px;bottom:40px;height:3px;background:#4b6068}.art-progress i{display:block;width:39%;height:100%;background:var(--teal)}
.art-time{position:absolute;bottom:17px;left:24px;font-size:10px;color:#a6bebf;letter-spacing:3px}
.art-orbit{position:absolute;border:1px solid #1c3f43;border-radius:50%;width:450px;height:211px;left:10px;top:36px;transform:rotate(-22deg)}
.orbit-two{left:40px;top:47px;transform:rotate(18deg);border-color:#19353a}
.art-tag{position:absolute;border:1px solid #3c595e;background:#152a30;border-radius:9px;padding:13px 18px;font-size:16px;font-weight:700;box-shadow:0 12px 32px #07101580}
.art-tag-live{top:25px;left:32px;transform:rotate(-7deg)}.art-tag-hd{bottom:13px;right:12px;color:var(--amber);transform:rotate(5deg)}.art-tag-hd span{font-weight:400;font-size:14px;color:#b7c3c7;margin-left:5px}
.login-features{display:flex;flex-wrap:wrap;font-size:17px;color:#8ea2ad}.login-features span{margin-right:26px;margin-top:9px}
.login-panel{width:620px;max-width:43%;background:linear-gradient(145deg,#17222e,#101922);border:1px solid #2a3946;border-radius:24px;padding:26px 38px;box-shadow:0 22px 80px #02070c55}
.panel-kicker{display:block;line-height:1.25;font-size:14px;letter-spacing:2.5px;color:var(--teal);font-weight:700}
.login-panel h2{font-size:38px;letter-spacing:-1px;margin:12px 0 10px}.panel-description{font-size:20px;line-height:1.5;color:var(--muted);margin-bottom:20px}
label{display:block;font-size:19px;color:#d6dfe6;margin:14px 0 9px}
input{width:100%;height:54px;border:1px solid #3b4b5b;background:#0b141d;color:var(--text);padding:0 17px;font-size:22px;min-width:0}
input::placeholder{color:#738495;opacity:1}
.remember-note{font-size:14px;color:#a4b6c3;line-height:1.5;margin-top:15px}.form-message{min-height:24px;font-size:17px;line-height:1.4;color:var(--amber);margin-top:9px}
.button{display:inline-flex;align-items:center;justify-content:center;border:1px solid transparent;font-size:20px;font-weight:600;padding:14px 20px;min-height:55px;white-space:nowrap}
.button-primary{color:#092521;background:var(--teal)}.button-primary span{margin:0 10px 0 0}.login-submit{width:100%;font-size:20px;margin-top:6px;justify-content:space-between}.login-submit span{margin:0}
.button-secondary{background:#1c2b37;border-color:#354450;color:#dfe7ed}.button-quiet{background:transparent;border-color:#344451;color:#becbd4}.demo-button{width:100%;font-size:18px;margin-top:12px;justify-content:space-between}
.provider-note{font-size:14px;line-height:1.5;color:#7e919f;margin-top:19px;text-align:center}
.home-screen{display:flex;flex-direction:column;padding-top:35px}.home-welcome{display:flex;justify-content:space-between;align-items:center;margin-bottom:55px}.home-welcome h1{font-size:57px;letter-spacing:-2px;margin:17px 0}.home-welcome p{font-size:25px;color:var(--muted)}
.account-badge{display:flex;align-items:center;border:1px solid #2a3b47;border-radius:13px;background:#131e28;padding:18px 24px;font-size:20px}.account-avatar{color:var(--teal);font-size:32px;width:53px}.account-badge small{display:block;color:#95a4b2;font-size:16px;margin-top:7px}
.mode-cards{display:flex;flex:1;min-height:340px;max-height:530px}.mode-card{position:relative;display:block;text-align:left;width:33.333%;padding:32px 34px;background:#14242d;border:1px solid #29444a;border-radius:19px;overflow:hidden;margin-right:26px}.mode-card:last-child{margin-right:0}.mode-vod{background:#252322;border-color:#484039}.mode-series{background:#202238;border-color:#3c4056}
.card-topline{position:relative;z-index:2;display:flex;justify-content:space-between;align-items:center}.live-pill{display:inline-flex;align-items:center;border:1px solid #3f6e66;background:#1b423c;color:var(--teal);border-radius:5px;padding:8px 11px;font-size:12px;letter-spacing:1.7px;font-weight:700}.live-pill i{width:6px;height:6px;background:var(--teal);border-radius:50%;margin-right:8px}.card-number{color:#70928f;font-size:21px}.mode-vod .card-number{color:#948573}.mode-series .card-number{color:#8588ab}.card-kicker{font-size:13px;font-weight:700;color:var(--amber);letter-spacing:2px}.mode-series .card-kicker{color:#c5c1ff}
.card-copy{position:absolute;left:34px;bottom:36px;z-index:2}.card-label{display:block;font-size:45px;font-weight:700;letter-spacing:-1.5px}.card-description{display:block;font-size:20px;color:#a6b7bd;margin-top:13px}.card-arrow{position:absolute;right:34px;bottom:49px;font-size:35px;color:#b8d4cf}.mode-vod .card-arrow{color:var(--amber)}.mode-series .card-arrow{color:#c5c1ff}
.mode-visual{position:absolute;display:block;left:50%;top:45%;transform:translate(-50%,-50%);width:260px;height:220px}.broadcast-ring{position:absolute;top:27px;left:47px;border:2px solid #3b8b7f;border-radius:50%;width:170px;height:170px;box-shadow:0 0 0 24px #23554b25,0 0 0 48px #23554b15}.broadcast-ring.ring-two{width:105px;height:105px;left:79px;top:60px;border-color:#5bbbaa;box-shadow:none}.broadcast-dot{position:absolute;width:40px;height:40px;border-radius:50%;background:var(--teal);top:92px;left:111px;box-shadow:0 0 50px #61ead03a}
.film-frame{position:absolute;display:flex;align-items:center;justify-content:center;border:1px solid #877256;border-radius:15px;width:178px;height:134px;left:40px;top:53px;background:linear-gradient(135deg,#574832,#302a26);color:var(--amber);font-size:50px}.frame-back{transform:translate(20px,-23px) rotate(13deg);background:#39312a;border-color:#5f5142}.frame-front{transform:rotate(-10deg);box-shadow:0 17px 35px #100d083b}
.episode-tile{position:absolute;border:1px solid #575b80;border-radius:12px;width:180px;height:112px;left:40px;top:62px;background:#303550}.tile-back{transform:translateY(-32px) scale(.83);background:#252a42}.tile-middle{transform:translateY(-16px) scale(.92);background:#2c314c}.tile-front{display:flex;justify-content:center;align-items:center;font-size:38px;color:#c5c1ff;background:linear-gradient(135deg,#41476d,#272b47);box-shadow:0 20px 40px #0c0d1a60}.tile-front small{position:absolute;left:19px;bottom:13px;font-size:8px;letter-spacing:2px;color:#b8bad8}
.home-bottom{display:flex;align-items:center;justify-content:space-between;margin-top:32px;color:#93a5b1;font-size:18px}.home-bottom-mark{color:#607988;font-size:13px;letter-spacing:2.3px}
.browser-screen{display:flex;flex-direction:column}.browser-heading{display:flex;align-items:center;justify-content:space-between;min-height:135px;padding:4px 0 24px}.browser-heading h1{font-size:45px;letter-spacing:-1.2px;margin:8px 0}.browser-heading .eyebrow{font-size:12px}.browser-heading p{font-size:19px;color:var(--muted);max-width:1050px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.search-wrap{display:flex;align-items:center;background:#121e29;border:1px solid #30414e;border-radius:12px;width:395px;margin-left:25px}.search-wrap>span{font-size:32px;color:#859eab;padding-left:17px}.search-wrap input{border:0;background:transparent;font-size:21px;height:57px}
.browser-columns{display:flex;flex:1;min-height:0;padding-bottom:6px}.category-panel{display:flex;flex-direction:column;width:23%;padding-right:20px;border-right:1px solid #263440}.streams-panel{display:flex;flex-direction:column;width:34%;padding:0 22px;border-right:1px solid #263440}.details-panel{width:43%;padding-left:28px;overflow:auto;scrollbar-width:none}.details-panel::-webkit-scrollbar{display:none}
.section-heading{display:flex;align-items:center;justify-content:space-between;min-height:48px;padding:0 10px 16px;color:#8299a9}.section-heading h2{font-size:18px;font-weight:500;letter-spacing:.2px}.section-heading>span{font-size:22px}.section-heading .section-hint{font-size:10px;letter-spacing:1.8px}
.virtual-list{position:relative;flex:1;min-height:0;overflow:auto;overflow-x:hidden;scrollbar-width:thin;scrollbar-color:#344b57 transparent;padding:0 7px;outline:none;contain:strict}.virtual-list::-webkit-scrollbar{width:5px}.virtual-list::-webkit-scrollbar-thumb{background:#344b57;border-radius:5px}.list-spacer{position:relative;width:100%;pointer-events:none}.list-window{position:absolute;top:0;left:0;width:100%;padding:0 7px}
.list-row{position:relative;display:flex;align-items:center;text-align:left;width:100%;margin:0;background:transparent;border:1px solid transparent;border-radius:10px;padding:0 17px;overflow:hidden;color:#b8c5ce}.category-row{height:68px;font-size:21px}.stream-row{height:82px;font-size:21px;border-bottom:1px solid #1e2d38}.list-row.is-selected{background:#183b38;color:var(--teal);border-color:#2c5e54}.list-row.is-playing{background:#1c302e;color:var(--teal)}.list-row.is-focused{z-index:2;outline-offset:-4px!important;box-shadow:inset 0 0 0 7px rgba(97,234,208,.08)!important;background:#213b43;color:#fff}.list-row.is-selected::before{position:absolute;content:"";left:0;top:20px;bottom:20px;width:3px;background:var(--teal);border-radius:2px}
.row-copy{display:block;flex:1;min-width:0}.row-label{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.4;min-width:0}.row-subtitle{display:block;font-size:14px;color:#8da1ad;margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.row-index{color:#60788a;font-size:14px;min-width:33px;margin-right:10px;font-variant-numeric:tabular-nums;flex-shrink:0}.row-icon{display:flex;align-items:center;justify-content:center;width:43px;height:43px;margin-right:13px;background:#233642;border-radius:8px;color:#8cb1ba;font-size:20px;object-fit:contain;flex-shrink:0}.row-count{font-size:14px;margin-left:12px;color:#71988f}.empty-state{padding:25px 16px;color:#8299a9;font-size:19px;line-height:1.6}
.player-shell{position:relative;width:100%;height:0;padding-top:56.25%;overflow:hidden;border-radius:15px;background:#070c11;border:1px solid #2a3a45}
#video,#av-player{position:absolute;inset:0;left:0;top:0;width:100%;height:100%;border:0;background:transparent;object-fit:contain}
#av-player{z-index:0}#video{z-index:1}#video[hidden]{display:none}
.player-placeholder{position:absolute;inset:0;left:0;top:0;right:0;bottom:0;display:flex;flex-direction:column;justify-content:center;align-items:center;background:radial-gradient(ellipse at 50% 35%,#1d333b,#0d171f 75%);color:#a3b5be;font-size:20px;text-align:center;padding:20px;z-index:2}.placeholder-icon{display:flex;align-items:center;justify-content:center;padding-left:4px;width:69px;height:69px;border:1px solid #426266;border-radius:50%;color:var(--teal);font-size:26px;margin-bottom:20px}.player-placeholder small{font-size:14px;color:#6d8997;margin-top:11px}
.detail-info{padding-top:24px}.detail-kicker{display:flex;align-items:center;font-size:14px;color:var(--teal);line-height:1.5;min-height:22px}.detail-heading{display:flex;align-items:center;margin-top:14px}.detail-heading img{max-height:58px;max-width:75px;object-fit:contain;margin-right:15px}.detail-heading h2{font-size:33px;line-height:1.2;letter-spacing:-.7px;overflow-wrap:break-word}.detail-meta{color:#9cabb8;font-size:17px;line-height:1.5;margin-top:11px}.detail-description{color:#8fa1ad;font-size:18px;line-height:1.55;margin-top:15px;max-height:113px;overflow:auto}.player-actions{display:flex;flex-wrap:wrap;margin-top:24px;padding:5px}.player-actions .button{font-size:17px;min-height:52px;margin:0 12px 13px 0;padding:12px 18px}.player-actions .button-primary{font-size:19px}
.player-overlay{position:absolute;inset:0;left:0;top:0;right:0;bottom:0;z-index:5;display:flex;flex-direction:column;justify-content:space-between;pointer-events:none;background:linear-gradient(0deg,#03090be6,transparent 42%,transparent 70%,#03090bb3)}.overlay-top{display:flex;justify-content:space-between;align-items:center;padding:43px 62px;color:#c7d8dc;font-size:22px}.overlay-brand{font-size:24px;font-weight:700;letter-spacing:.2px;color:var(--teal)}.overlay-bottom{padding:44px 62px}.overlay-bottom h2{font-size:42px;margin-bottom:16px}.overlay-bottom p{font-size:21px;color:#a6bbc4}
.player-shell.is-fullscreen{position:fixed;left:0;top:0;width:100vw;height:100vh;padding:0;z-index:30;border:0;border-radius:0;background:#000}
body.avplay-active,.avplay-active .app-shell{background:transparent}.avplay-active .player-shell{background:transparent}.avplay-active #av-player{z-index:0}.avplay-active #video{display:none}
.player-fullscreen .app-header,.player-fullscreen .app-footer,.player-fullscreen .browser-heading,.player-fullscreen .category-panel,.player-fullscreen .streams-panel,.player-fullscreen .detail-info{visibility:hidden}
.player-fullscreen .player-overlay{background:none}
.player-fullscreen .overlay-top{padding:26px 52px;background:rgba(3,9,11,.78)}
.player-fullscreen .overlay-bottom{padding:25px 52px 30px;background:rgba(3,9,11,.9)}
.player-fullscreen .overlay-bottom h2{font-size:36px;line-height:1.2;margin-bottom:10px}
.player-fullscreen .overlay-bottom>p{font-size:18px;line-height:1.4}
.seek-controls{pointer-events:auto;margin-top:18px;padding-top:17px;border-top:1px solid #3a505a}
.seek-times{display:flex;justify-content:space-between;font-size:22px;font-weight:600;line-height:1.3;font-variant-numeric:tabular-nums;color:#edf7f7}
.seek-controls.is-seeking #seek-position{color:var(--teal)}
.seek-track{position:relative;width:100%;height:44px;border-radius:8px;cursor:pointer;touch-action:none}
.seek-track::before{content:"";position:absolute;left:0;right:0;top:20px;height:6px;border-radius:3px;background:#50616a}
.seek-fill{position:absolute;left:0;top:20px;width:0;height:6px;border-radius:3px;background:var(--teal)}
.seek-thumb{position:absolute;left:0;top:14px;width:18px;height:18px;margin-left:-9px;border:2px solid #e4fff8;border-radius:50%;background:var(--teal)}
.seek-actions{display:flex;align-items:center;justify-content:space-between;margin-top:6px}
.seek-actions #seek-help{font-size:18px;line-height:1.4;color:#b0c2ca;margin-right:25px}
.seek-time-button{font-size:18px;min-height:48px;padding:12px 22px;color:#e2fff7;background:#233d43;border-color:#50757a;flex-shrink:0}
.seek-time-field{margin:0 0 25px}.seek-time-field label{font-size:20px;letter-spacing:.5px;margin:0 0 13px;color:#b9ccd5}
.seek-time-field input{height:72px;font-size:36px;text-align:center;font-variant-numeric:tabular-nums;letter-spacing:5px}
.dialog-card .seek-time-error{font-size:17px;line-height:1.5;min-height:26px;margin:12px 0 0;color:var(--amber)}
.busy-indicator{position:fixed;bottom:76px;left:50%;transform:translateX(-50%);display:flex;align-items:center;font-size:20px;background:#19303a;border:1px solid #3a5b65;border-radius:14px;padding:17px 25px;box-shadow:0 12px 40px #0007;z-index:60}.spinner{width:23px;height:23px;border:2px solid #547d83;border-top-color:var(--teal);border-radius:50%;margin-right:13px;animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
.toast{position:fixed;left:50%;bottom:80px;transform:translateX(-50%);z-index:70;padding:20px 28px;max-width:80%;background:#243846;border:1px solid #527080;border-radius:12px;color:#f0f6f8;font-size:22px;text-align:center;box-shadow:0 12px 50px #0008}
.dialog-backdrop{position:fixed;inset:0;left:0;top:0;right:0;bottom:0;background:#040a10dc;display:flex;align-items:center;justify-content:center;z-index:80}.dialog-card{width:700px;background:#172430;border:1px solid #3c5261;border-radius:22px;padding:45px;box-shadow:0 30px 90px #0008}.dialog-card h2{font-size:36px;margin-top:16px}.dialog-card p{font-size:23px;line-height:1.6;color:#b3c2cc;margin:21px 0 32px;white-space:pre-line}.dialog-actions{display:flex}.dialog-actions .button{margin-right:18px;min-width:175px}
@media(min-width:2000px){.app-shell{max-width:2200px;margin:auto}.login-story h1{font-size:88px}.mode-card{max-height:600px}.mode-cards{max-height:600px}}
@media(max-width:1500px){body{font-size:20px}.app-shell{padding:22px 34px 14px}.app-header{height:62px;margin-bottom:17px}.main-content{height:calc(100% - 121px)}.brand{font-size:25px}.brand-icon{margin-right:10px}.header-caption{font-size:16px}.header-divider{margin:0 15px}.connection-status{font-size:14px;margin-right:20px}.clock{font-size:22px;margin-right:15px}.header-button{font-size:16px;padding:10px 13px}.login-panel{padding:26px 30px;max-width:45%;width:520px}.login-story{width:51%}.login-story h1{font-size:60px;margin:20px 0}.hero-description{font-size:22px}.hero-art{height:210px;transform:scale(.8);transform-origin:left top;margin-bottom:-30px}.login-features{font-size:14px}.login-panel h2{font-size:30px}.panel-description{font-size:17px;margin-bottom:12px}label{font-size:16px;margin:13px 0 7px}input{height:49px;font-size:18px}.remember-note{font-size:13px;margin-top:10px}.form-message{font-size:14px;min-height:20px}.button{font-size:17px;min-height:46px;padding:10px 15px}.login-submit{font-size:17px}.demo-button{font-size:16px}.provider-note{font-size:12px;margin-top:13px}.home-screen{padding-top:20px}.home-welcome{margin-bottom:35px}.home-welcome h1{font-size:43px;margin:13px 0}.home-welcome p{font-size:20px}.account-badge{font-size:17px;padding:15px 19px}.account-badge small{font-size:13px}.mode-cards{min-height:290px;max-height:440px}.mode-card{padding:25px;margin-right:20px}.card-copy{left:25px;bottom:30px}.card-label{font-size:35px}.card-description{font-size:17px}.card-arrow{right:25px;font-size:28px;bottom:39px}.mode-visual{transform:translate(-50%,-50%) scale(.8)}.card-kicker{font-size:11px;letter-spacing:1px}.live-pill{font-size:10px;padding:6px 8px}.home-bottom{font-size:15px;margin-top:24px}.home-bottom-mark{font-size:10px}.browser-heading{min-height:113px;padding-bottom:18px}.browser-heading h1{font-size:35px;margin:5px 0}.browser-heading p{font-size:16px}.search-wrap{width:300px}.search-wrap input{height:48px;font-size:17px}.category-panel{padding-right:13px;width:23%}.streams-panel{padding:0 15px;width:34%}.details-panel{padding-left:19px;width:43%}.section-heading h2{font-size:16px}.section-heading{min-height:39px;padding-bottom:11px}.category-row,.stream-row{font-size:17px}.row-subtitle{font-size:12px}.row-index{font-size:12px;min-width:24px;margin-right:6px}.list-row{padding:0 12px}.detail-info{padding-top:17px}.detail-heading{margin-top:10px}.detail-heading h2{font-size:26px}.detail-kicker{font-size:12px}.detail-meta{font-size:14px}.detail-description{font-size:15px;max-height:91px;margin-top:10px}.player-actions{margin-top:15px}.player-actions .button{font-size:14px;padding:9px 12px;min-height:43px;margin:0 8px 10px 0}.player-actions .button-primary{font-size:15px}.placeholder-icon{width:52px;height:52px;font-size:21px;margin-bottom:12px}.player-placeholder{font-size:16px}.player-placeholder small{font-size:12px}.app-footer{font-size:14px;height:42px}.key{font-size:12px;margin-left:18px}.footer-wordmark{font-size:11px}}
@media(max-height:850px){.login-story h1{font-size:57px}.hero-art{height:200px;transform:scale(.75);transform-origin:left top;margin-bottom:-40px}.login-panel{padding-top:23px;padding-bottom:23px}.home-welcome{margin-bottom:28px}.home-welcome h1{font-size:42px}.home-screen{padding-top:15px}.home-bottom{margin-top:24px}.mode-cards{min-height:270px}.mode-visual{transform:translate(-50%,-50%) scale(.75)}.detail-description{max-height:68px}.player-actions{margin-top:14px}}
@media(max-width:1000px){.header-caption,.header-divider,.connection-status,.footer-wordmark,.home-bottom-mark{display:none}.app-shell{padding:16px 22px 12px}.header-button span{display:none}.clock{margin-right:5px}.login-screen{align-items:flex-start;padding-top:20px}.login-story{padding-right:20px}.login-story h1{font-size:46px}.hero-description{font-size:18px}.hero-art{transform:scale(.57);height:160px;margin-top:20px}.login-features{display:block;font-size:12px}.login-features span{display:block;margin-top:12px}.login-panel{padding:22px;max-width:49%;width:49%}.panel-description{font-size:14px}.panel-kicker{font-size:11px}.login-panel h2{font-size:26px}.remember-note{font-size:11px}.provider-note{font-size:10px}.eyebrow{font-size:11px;letter-spacing:1.5px}.home-welcome h1{font-size:34px}.home-welcome p{font-size:16px}.account-badge{font-size:14px;padding:12px}.account-avatar{font-size:25px;width:35px}.account-badge small{font-size:11px}.mode-card{margin-right:12px;padding:20px}.card-topline{align-items:flex-start}.card-number{font-size:15px}.card-kicker{font-size:8px}.live-pill{font-size:8px;letter-spacing:1px}.card-copy{left:20px;bottom:23px}.card-label{font-size:29px}.card-description{font-size:13px}.card-arrow{right:20px;bottom:32px;font-size:23px}.mode-visual{transform:translate(-50%,-50%) scale(.62)}.browser-heading{min-height:100px}.browser-heading h1{font-size:30px}.browser-heading p{font-size:13px}.search-wrap{width:240px}.search-wrap input{font-size:15px}.category-panel{width:24%;padding-right:8px}.streams-panel{width:34%;padding:0 9px}.details-panel{width:42%;padding-left:12px}.section-heading{padding-left:5px;padding-right:5px}.section-heading h2{font-size:13px}.section-heading .section-hint{font-size:8px}.list-row{font-size:14px;padding:0 10px}.row-icon{width:28px;height:28px;margin-right:7px;font-size:15px}.row-index{display:none}.row-subtitle{font-size:10px}.detail-heading h2{font-size:22px}.detail-meta{font-size:12px}.detail-description{font-size:13px}.player-actions .button{font-size:12px;padding:8px 10px}.home-bottom{font-size:12px}.dialog-card{width:80%;padding:30px}.dialog-card h2{font-size:28px}.dialog-card p{font-size:18px}}
.card-topline{position:absolute;left:34px;right:34px;top:32px}
@media(max-width:1500px){.card-topline{left:25px;right:25px;top:25px}}
@media(max-width:1000px){.card-topline{left:20px;right:20px;top:20px}}
@media(prefers-reduced-motion:reduce){.spinner{animation:none}}

@media(max-height:850px){.login-panel{padding:22px 30px}.login-panel h2{font-size:30px;line-height:1.2;margin:8px 0}.login-panel .panel-description{font-size:17px;margin-bottom:12px}.login-panel label{font-size:16px;margin:10px 0 6px}.login-panel input{height:46px;font-size:18px}.login-panel .remember-note{font-size:12px;line-height:1.4;margin-top:10px}.login-panel .form-message{min-height:19px;font-size:14px;margin-top:6px}.login-submit,.demo-button{min-height:45px;padding:10px 15px;font-size:16px}.demo-button{margin-top:10px}.login-panel .provider-note{font-size:11px;margin-top:12px}}
@media(max-height:760px){.login-panel .panel-description,.login-panel .provider-note{display:none}.login-panel .remember-note{font-size:11px;margin-top:8px}.login-panel h2{font-size:27px;margin-bottom:13px}.login-panel input{height:42px}.hero-art{display:none}.login-features{margin-top:30px}}
@media(max-width:650px){
  body{overflow-y:auto;overflow-x:hidden}
  .app-shell{height:auto;min-height:100%;padding:18px}
  .app-header{height:50px;margin-bottom:22px}
  .brand{font-size:16px;letter-spacing:-.2px}.brand-icon{width:32px;height:32px;margin-right:8px}
  .clock{font-size:18px;margin-right:3px}.header-button{font-size:17px;padding:9px 11px;margin-left:8px}
  .main-content{height:auto}
  .login-screen{height:auto;display:flex;flex-direction:column;align-items:stretch;padding-top:0;max-width:100%}
  .login-story{width:100%;height:auto;padding:0;margin-bottom:23px;display:block}
  .login-story .eyebrow{font-size:9px;letter-spacing:1.3px;line-height:1.5}
  .login-story h1{font-size:32px;line-height:1.12;letter-spacing:-1px;margin:12px 0}
  .hero-description{font-size:15px;line-height:1.45}.hero-art,.login-features{display:none}
  .login-panel{width:100%;max-width:100%;padding:20px;border-radius:17px}
  .login-panel .panel-kicker{font-size:10px}.login-panel h2{font-size:26px;line-height:1.2;margin:8px 0}
  .login-panel .panel-description{display:block;font-size:14px;line-height:1.45;margin-bottom:14px}
  .login-panel label{font-size:14px;margin:12px 0 6px}.login-panel input{height:48px;font-size:17px;padding:0 13px}
  .login-panel .remember-note{font-size:11px;line-height:1.45;margin-top:12px}
  .login-panel .form-message{font-size:12px;line-height:1.4;min-height:18px;margin-top:6px}
  .login-submit,.demo-button{font-size:14px;min-height:46px;padding:12px}
  .login-panel .provider-note{display:block;font-size:10px;line-height:1.5;margin-top:15px}
  .home-screen{height:auto;padding-top:0}.home-welcome{display:block;margin-bottom:24px}.home-welcome h1{font-size:32px;line-height:1.15;margin:13px 0}.home-welcome p{font-size:16px;line-height:1.5}
  .account-badge{display:inline-flex;margin-top:20px;padding:12px 16px}.account-badge small{font-size:12px}
  .mode-cards{display:block;flex:none;max-height:none;min-height:0}.mode-card{width:100%;height:245px;margin:0 0 18px;padding:22px}.mode-card:last-child{margin-bottom:0}
  .card-kicker{font-size:10px}.live-pill{font-size:9px}.card-number{font-size:17px}.mode-visual{left:70%;top:44%;transform:translate(-50%,-50%) scale(.62)}
  .card-copy{left:22px;bottom:24px}.card-label{font-size:32px}.card-description{font-size:15px;margin-top:9px}.card-arrow{right:23px;bottom:31px}
  .home-bottom{margin-top:22px;font-size:12px;line-height:1.5}
  .browser-screen{height:calc(100vh - 145px);min-height:580px}
  .app-footer{margin-top:25px;height:33px;font-size:11px}.key{font-size:10px;margin:0 6px 0 11px;padding:3px 5px;min-width:25px}
  .dialog-card{width:calc(100% - 36px);padding:25px}.dialog-card h2{font-size:24px}.dialog-card p{font-size:16px}.dialog-actions .button{min-width:0;flex:1;margin-right:12px;font-size:14px;padding:12px}.dialog-actions .button:last-child{margin-right:0}
  .player-fullscreen .overlay-top{padding:18px 22px;font-size:15px}.player-fullscreen .overlay-brand{font-size:14px;letter-spacing:0;max-width:45%;white-space:normal;line-height:1.3}.player-fullscreen .overlay-bottom{padding:20px 22px 24px}.player-fullscreen .overlay-bottom h2{font-size:25px}.player-fullscreen .overlay-bottom>p{font-size:14px}
  .seek-times{font-size:17px}.seek-actions{align-items:flex-start}.seek-actions #seek-help{font-size:13px;max-width:210px;margin-right:14px}.seek-time-button{font-size:13px;min-height:42px;padding:10px 12px}.seek-time-field label{font-size:16px}.seek-time-field input{height:62px;font-size:29px;letter-spacing:3px}.dialog-card .seek-time-error{font-size:13px;min-height:20px}
}

.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.home-actions{width:350px;flex-shrink:0;margin-left:35px}.global-search-button{width:100%;min-height:52px;font-size:18px;margin-bottom:12px}.global-search-button>span{font-size:25px;margin-right:12px;color:var(--teal)}.home-actions .account-badge{padding:15px 22px}
.search-screen{display:flex;flex-direction:column;min-height:0}.searchall-heading{display:flex;align-items:center;justify-content:space-between;min-height:120px;padding:15px 0 20px}.searchall-heading h1{font-size:42px;letter-spacing:-1.2px;margin-top:13px}.searchall-heading .eyebrow{font-size:12px}.searchall-input-wrap{width:620px;margin-left:30px}.searchall-input-wrap input{height:62px;font-size:23px}.searchall-status{font-size:20px;line-height:1.5;color:var(--muted);margin:0 0 18px}.searchall-results{flex:1;min-height:0;overflow:auto;padding:8px;contain:content;border-top:1px solid var(--line);border-bottom:1px solid var(--line);scrollbar-width:thin;scrollbar-color:#344b57 transparent}.searchall-results::-webkit-scrollbar,.feature-content::-webkit-scrollbar{width:5px}.searchall-results::-webkit-scrollbar-thumb,.feature-content::-webkit-scrollbar-thumb{background:#344b57;border-radius:5px}.search-result-row{display:block;width:100%;min-height:82px;padding:12px 18px;margin:0;font-size:22px;line-height:1.4;text-align:left;white-space:normal;overflow-wrap:break-word;overflow:hidden;color:#d9e7ec;background:transparent;border:1px solid transparent;border-bottom-color:#25333e;border-radius:10px}.search-result-row:focus,.search-result-row.is-focused{background:#213b43}.search-result-kind{color:var(--teal);font-size:14px;letter-spacing:1px;margin-left:24px;flex-shrink:0}.searchall-pagination{display:flex;align-items:center;justify-content:flex-end;min-height:80px;padding:13px 7px 0}.searchall-pagination .button{min-width:180px;margin-left:16px}
.category-settings-button{min-height:28px;padding:6px 10px;background:#172b34;border:1px solid #36515c;border-radius:7px;color:#b7d4d6;font-size:13px;line-height:1.1}
.epg-summary{border-left:2px solid #345d59;padding:3px 0 3px 12px;margin-top:14px}.epg-row{display:flex;align-items:center;min-height:29px;line-height:1.3}.epg-label{width:57px;color:var(--teal);font-size:10px;font-weight:700;letter-spacing:1px;flex-shrink:0}.epg-title{font-size:17px;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#b8cbd1}.epg-time{font-size:14px;font-variant-numeric:tabular-nums;color:#8ba4af;margin-left:12px;flex-shrink:0}
.overlay-tools{display:flex;align-items:center;justify-content:flex-end;min-width:0;max-width:78%}.overlay-tools #overlay-state{max-width:580px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.overlay-settings-button{pointer-events:auto;min-height:48px;padding:11px 19px;font-size:18px;color:#d9eee9;background:#1e343a;border:1px solid #426269;margin-left:24px}
.subtitle-display{position:absolute;left:8%;right:8%;bottom:8%;z-index:4;padding:7px 12px;border-radius:5px;background:rgba(0,0,0,.8);color:#fff;text-align:center;font-size:21px;line-height:1.4;white-space:pre-line;overflow-wrap:break-word;pointer-events:none}.player-shell.is-fullscreen .subtitle-display{left:12%;right:12%;bottom:8%;font-size:38px;line-height:1.35;padding:8px 18px}
.digit-channel-overlay{position:absolute;top:115px;right:52px;z-index:8;min-width:230px;max-width:460px;padding:20px 25px;border:1px solid #3e6e6a;border-radius:14px;background:rgba(8,25,29,.95);text-align:right;pointer-events:none}.digit-channel-caption{display:block;font-size:12px;letter-spacing:3px;color:var(--teal)}#digit-channel-number{display:block;font-size:64px;line-height:1.2;font-variant-numeric:tabular-nums;font-weight:700;margin:4px 0}#digit-channel-label{display:block;font-size:20px;color:#c0d3d8;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dialog-backdrop{z-index:100}.feature-dialog{z-index:90}.toast{z-index:110}.feature-card{display:flex;flex-direction:column;width:1120px;max-width:calc(100% - 108px);max-height:calc(100% - 108px);padding:35px 38px;overflow:hidden}.feature-heading{display:flex;align-items:center;justify-content:space-between;flex-shrink:0}.feature-heading h2{font-size:34px;margin-top:12px}.feature-heading .button{min-width:125px;font-size:19px;margin-left:25px}.feature-card #feature-description{font-size:20px;line-height:1.5;color:#a6bdc8;margin:18px 0 16px;flex-shrink:0}.feature-content{flex:1;min-height:0;max-height:calc(100vh - 300px);overflow:auto;padding:8px;scrollbar-width:thin;scrollbar-color:#344b57 transparent}.feature-section{font-size:15px;font-weight:700;color:var(--teal);letter-spacing:1.8px;margin:22px 0 12px}.feature-section:first-child{margin-top:4px}.feature-row{display:flex;align-items:center;justify-content:space-between;min-height:68px;width:100%;text-align:left;white-space:normal;line-height:1.4;font-size:21px;padding:14px 18px;margin:0 0 10px;border:1px solid #344a58;border-radius:10px;color:#d9e7ec;background:#192d38}.feature-row.is-selected,.feature-row[aria-pressed="true"]{border-color:#5aa99b;background:#1b3b37;color:var(--teal)}.feature-row small,.feature-caption{display:block;font-size:16px;line-height:1.45;color:#98b0bd;margin-top:5px}.feature-value{font-size:18px;color:var(--amber);margin-left:25px;flex-shrink:0;text-align:right}.feature-badge{display:inline-block;padding:4px 8px;border:1px solid #47695f;border-radius:5px;color:var(--teal);font-size:12px;white-space:nowrap;margin-left:12px}.feature-error{font-size:19px;line-height:1.5;color:var(--amber);padding:10px 0}.feature-content .empty-state{padding:18px 8px}.programme-row{padding:16px 10px;border-bottom:1px solid #30424f}.programme-row .programme-time{font-size:16px;color:var(--teal);font-variant-numeric:tabular-nums}.programme-row h3{font-size:23px;line-height:1.35;font-weight:600;margin:7px 0}.programme-row p{font-size:18px;line-height:1.5;color:#9eb5c2;margin:0}
.programme-row.feature-row{display:block}.feature-content .feature-caption{font-size:16px;line-height:1.45;color:#98b0bd;margin:8px 0 18px}
.feature-row:focus,.feature-row.is-focused,.search-result-row:focus,.search-result-row.is-focused{outline-offset:-4px!important;box-shadow:inset 0 0 0 7px rgba(97,234,208,.12)!important}
.pin-field{margin:0 0 25px}.pin-field label{font-size:20px;line-height:1.4;margin:0 0 13px;color:#b9ccd5}.pin-field input{height:72px;text-align:center;font-size:36px;letter-spacing:8px}.dialog-card .pin-error{font-size:17px;line-height:1.5;min-height:26px;margin:12px 0 0;color:var(--amber)}
@media(max-width:1500px){.home-actions{width:290px}.global-search-button{font-size:16px;min-height:45px;margin-bottom:10px}.home-actions .account-badge{padding:12px 18px}.searchall-heading{min-height:100px;padding:10px 0 17px}.searchall-heading h1{font-size:34px}.searchall-input-wrap{width:440px}.searchall-input-wrap input{height:54px;font-size:19px}.searchall-status{font-size:17px;margin-bottom:12px}.searchall-pagination{min-height:65px}.searchall-pagination .button{min-width:150px}.search-result-row{font-size:19px}.epg-title{font-size:14px}.epg-time{font-size:12px;margin-left:8px}.epg-label{font-size:9px;width:48px}.epg-row{min-height:25px}.epg-summary{padding-left:9px}.feature-card{padding:28px 30px}.feature-heading h2{font-size:30px}.feature-card #feature-description{font-size:18px}.feature-row{min-height:60px;font-size:18px}.feature-row small,.feature-caption{font-size:14px}.feature-value{font-size:16px}.feature-content{max-height:calc(100vh - 250px)}}
@media(max-width:1000px){.home-actions{width:235px;margin-left:25px}.global-search-button{font-size:14px;min-height:42px}.global-search-button>span{font-size:21px;margin-right:8px}.home-actions .account-badge{padding:12px}.searchall-heading{display:block;padding-bottom:15px}.searchall-heading h1{font-size:31px}.searchall-input-wrap{width:100%;margin:20px 0 0}.searchall-status{font-size:16px}.epg-label{width:39px;font-size:8px;letter-spacing:.5px}.epg-time{font-size:10px}.epg-title{font-size:12px}.epg-summary{padding-left:7px;margin-top:10px}.overlay-tools #overlay-state{max-width:250px}.overlay-settings-button{font-size:15px;min-height:42px;padding:9px 13px;margin-left:15px}.feature-card{max-width:calc(100% - 54px);max-height:calc(100% - 54px);padding:26px}.feature-heading h2{font-size:27px}.feature-heading .button{font-size:16px;min-width:100px}.feature-card #feature-description{font-size:16px}.feature-content{max-height:calc(100vh - 220px)}.feature-row{font-size:17px;min-height:58px;padding:12px 14px}.feature-value{font-size:14px;margin-left:15px}.feature-row small,.feature-caption{font-size:13px}}
@media(max-width:650px){.home-actions{width:100%;margin:20px 0 0}.global-search-button{margin:0;min-height:46px;font-size:15px}.home-actions .account-badge{display:flex;width:100%;margin-top:12px;padding:13px 16px}.search-screen{height:calc(100vh - 145px);min-height:620px}.searchall-heading{padding-top:0}.searchall-heading .eyebrow{font-size:9px}.searchall-heading h1{font-size:27px;margin-top:10px}.searchall-input-wrap input{font-size:16px;height:50px}.searchall-status{font-size:14px;line-height:1.45}.search-result-row{font-size:16px;min-height:74px;padding:10px 12px}.search-result-kind{font-size:10px;margin-left:12px}.searchall-pagination .button{min-width:125px;font-size:14px;padding:10px 15px;margin-left:12px}.overlay-tools{max-width:70%}.overlay-tools #overlay-state{font-size:11px;max-width:100px}.overlay-settings-button{font-size:11px;min-height:38px;padding:8px 10px;margin-left:9px}.player-shell.is-fullscreen .subtitle-display{font-size:21px;left:6%;right:6%;padding:6px 10px}.digit-channel-overlay{top:95px;right:22px;min-width:170px;max-width:calc(100% - 44px);padding:14px 18px}#digit-channel-number{font-size:44px}#digit-channel-label{font-size:16px}.feature-card{padding:22px 18px;max-width:calc(100% - 30px);max-height:calc(100% - 50px)}.feature-heading h2{font-size:23px}.feature-heading .button{min-width:70px;font-size:14px;padding:10px 13px;margin-left:15px}.feature-card #feature-description{font-size:14px;margin:15px 0 12px}.feature-row{font-size:15px;padding:12px;min-height:56px}.feature-row small,.feature-caption{font-size:12px}.feature-value{font-size:12px;margin-left:12px;max-width:42%}.feature-section{font-size:11px;letter-spacing:1.1px}.feature-content{max-height:calc(100vh - 210px)}.feature-badge{font-size:10px;padding:3px 5px;margin-left:7px}.programme-row h3{font-size:18px}.programme-row p{font-size:14px}.programme-row .programme-time{font-size:13px}.pin-field label{font-size:16px}.pin-field input{height:62px;font-size:29px;letter-spacing:6px}.dialog-card .pin-error{font-size:13px;min-height:20px}}
@media(max-width:1500px){.feature-content .feature-caption{font-size:14px}}
@media(max-width:1000px){.feature-content .feature-caption{font-size:13px}}
@media(max-width:650px){.feature-content .feature-caption{font-size:12px}}

@media(max-width:375px){.app-header .clock{display:none}}

.login-panel-heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:2px}.login-privacy-button{font-size:15px;line-height:1.25;min-height:34px;padding:7px 12px;margin-left:15px;background:#1b303b;border:1px solid #3c5b68;border-radius:8px;color:#c9e4e5}
#privacy-button{font-size:18px;padding:13px 16px}
.privacy-section{display:block;width:100%;padding:20px;margin:0 0 12px;border:1px solid #334d5c;border-radius:10px;background:#162934;color:#e6f0f2}.privacy-section h3{font-size:24px;line-height:1.3;font-weight:600;margin:0 0 10px}.privacy-section p{font-size:21px;line-height:1.55;color:#b9cdd7;margin:0}.privacy-section p.privacy-url{font-size:18px;line-height:1.55;color:var(--teal);overflow-wrap:break-word;word-break:break-word;margin-top:11px}.privacy-section:focus,.privacy-section.is-focused{outline-offset:-4px!important;box-shadow:inset 0 0 0 7px rgba(97,234,208,.12)!important;background:#1d3741}
@media(max-width:1500px){.login-privacy-button{font-size:13px;padding:6px 10px;min-height:30px}#privacy-button{font-size:16px;padding:10px 13px}.privacy-section{padding:17px}.privacy-section h3{font-size:22px}.privacy-section p{font-size:19px}.privacy-section p.privacy-url{font-size:17px}}
@media(max-width:1000px){.privacy-section h3{font-size:20px}.privacy-section p{font-size:17px}.privacy-section p.privacy-url{font-size:15px}}
@media(max-width:650px){.login-panel-heading .panel-kicker{letter-spacing:1.7px}.login-privacy-button{font-size:11px;min-height:30px;padding:6px 9px;margin-left:8px}#privacy-button{font-size:17px;padding:9px 11px}.privacy-section{padding:15px}.privacy-section h3{font-size:18px}.privacy-section p{font-size:15px;line-height:1.55}.privacy-section p.privacy-url{font-size:13px}}

```

## app.js

```javascript
/* AKIŞ playback engine: one decoder and one active playback generation at a time. */
(function (global) {
  'use strict';

  class TVPlayer {
    constructor(options) {
      this.options = options || {};
      this.video = this.options.video;
      this.shell = this.options.shell;
      this.avObject = document.getElementById('av-player');
      this.av = global.webapis && global.webapis.avplay;
      this.engine = '';
      this.live = false;
      this.paused = false;
      this.playing = false;
      this.fullscreen = false;
      this._generation = 0;
      this._avOwner = 0;
      this._hls = null;
      this._listeners = [];
      this._timers = new Set();
      this._request = null;
      this._attempt = null;
      this._failed = false;
      this._lastPosition = -1;
      this._lastProgress = 0;
      this._seekBusy = false;
      this._seekToken = 0;
      this._playbackInfo = null;
      this._rectPending = false;
      this.aspectRatio = 'fit';
      this._subtitleIndex = -1;
      this._subtitleTimer = null;
      this._trackCleanup = [];
      this._destroyed = false;
      if (!this.video || !this.shell) throw new Error('Video ve oynatıcı alanı gerekli.');
      this.video.controls = false;
      this.video.setAttribute('playsinline', '');
      this.video.preload = 'metadata';
    }

    _emit(name, ...args) {
      const handler = this.options[name];
      if (typeof handler === 'function') {
        try { handler(...args); } catch (_) { /* UI callbacks must not break decoder cleanup. */ }
      }
    }

    _status(status, message) { this._emit('onStatus', status, message || ''); }
    _valid(id) { return !this._destroyed && id === this._generation && !this._failed; }

    _after(fn, delay) {
      const timer = global.setTimeout(() => {
        this._timers.delete(timer);
        fn();
      }, delay);
      this._timers.add(timer);
      return timer;
    }

    _listen(event, handler) {
      this.video.addEventListener(event, handler);
      this._listeners.push([event, handler]);
    }

    _avState() {
      try { return this.av ? this.av.getState() : 'NONE'; } catch (_) { return 'NONE'; }
    }

    _closeAV() {
      if (!this.av || !this._avOwner) return;
      this._avOwner = 0;
      try {
        if (['READY', 'PLAYING', 'PAUSED'].indexOf(this._avState()) !== -1) this.av.stop();
      } catch (_) { /* close() still releases an interrupted preparation. */ }
      try { this.av.close(); } catch (_) { /* Already closed, including canceled prepareAsync. */ }
    }

    _dispose() {
      this._trackCleanup.forEach(function (cleanup) { cleanup(); }); this._trackCleanup = [];
      this._nativeBound = null;
      this._subtitleIndex = -1; this._subtitleTimer = null; this._emit('onSubtitle', '');
      this._timers.forEach(function (timer) { global.clearTimeout(timer); });
      this._timers = new Set();
      this._listeners.forEach((entry) => this.video.removeEventListener(entry[0], entry[1]));
      this._listeners = [];
      if (this._hls) {
        const previous = this._hls;
        this._hls = null;
        try { previous.destroy(); } catch (_) { /* Continue releasing the media element. */ }
      }
      try {
        this.video.pause();
        this.video.removeAttribute('src');
        this.video.load();
      } catch (_) { /* Device teardown can race with application suspension. */ }
      this._closeAV();
      this._seekBusy = false;
      ++this._seekToken;
      this._playbackInfo = null;
      this._rectPending = false;
      this.playing = false;
      this.paused = false;
    }

    _showEngine(name) {
      this.engine = name;
      const hardware = name === 'AVPlay';
      this.video.hidden = hardware;
      this.video.style.display = hardware ? 'none' : 'block';
      if (this.avObject) {
        this.avObject.hidden = !hardware;
        this.avObject.style.display = hardware ? 'block' : 'none';
      }
      this.shell.dataset.engine = name;
      this._emit('onEngine', name);
    }

    play(request) {
      if (this._destroyed) return;
      let parsed;
      try { parsed = new URL(request && request.url); } catch (_) {
        this.stop();
        this._status('error', 'Geçersiz yayın adresi.');
        this._emit('onError', 'Geçersiz yayın adresi.');
        return;
      }
      let packagedDemo = false;
      if (request && request.packagedDemo === true) {
        try { packagedDemo = parsed.protocol === 'file:' && parsed.href === new URL('media/orbit-review.mp4', document.baseURI).href; } catch (_) { /* Only the exact bundled demo file may bypass HTTP validation. */ }
      }
      if ((!/^https?:$/.test(parsed.protocol) && !packagedDemo) || parsed.username || parsed.password) {
        this.stop();
        this._status('error', 'Yayın adresi HTTP veya HTTPS olmalı.');
        this._emit('onError', 'Yayın adresi HTTP veya HTTPS olmalı.');
        return;
      }
      this._request = {
        url: parsed.href,
        live: Boolean(request.live),
        title: String(request.title || ''),
        startAt: Math.max(0, Number(request.startAt) || 0)
      };
      const sources = [parsed.href];
      if (request.live && Array.isArray(request.alternativeUrls)) request.alternativeUrls.slice(0, 2).forEach(function (value) {
        try { const u = new URL(value); if (/^https?:$/.test(u.protocol) && !u.username && !u.password && sources.indexOf(u.href) === -1) sources.push(u.href); } catch (_) { /* Ignore invalid alternatives. */ }
      });
      this.aspectRatio = 'fit';
      this._attempt = { browserOnly: false, restarts: 0, sources, avSourceIndex: 0, browserTried: new Set() };
      this._start();
    }

    _start() {
      const id = ++this._generation;
      this._dispose();
      this._failed = false;
      this.live = this._request.live;
      this._lastPosition = -1;
      this._lastProgress = Date.now();
      this._status('loading', 'Yayın açılıyor…');
      if (!this._valid(id)) return;
      this._emit('onSourceChanged', { url: this._request.url, index: this._attempt.sources.indexOf(this._request.url), alternative: this._request.url !== this._attempt.sources[0] });
      this._after(() => {
        if (this._valid(id) && !this.playing && !this.paused) {
          if (this.engine === 'AVPlay') this._fallback(id);
          else this._fail(id, 'Yayın 25 saniye içinde açılamadı. Sunucu, ağ ve yayın biçimini kontrol edin.');
        }
      }, 25000);
      if (this.av && this.avObject && !this._attempt.browserOnly) this._startAV(id);
      else {
        this._attempt.browserOnly = true; this._attempt.browserTried.add(this._request.url);
        this._startBrowser(id);
      }
    }

    _startAV(id) {
      this._showEngine('AVPlay');
      this._avOwner = id;
      try {
        this.av.open(this._request.url);
        if (!this._valid(id)) return;
        this.av.setListener({
          onbufferingstart: () => {
            if (this._valid(id)) this._status('buffering', 'Yayın arabelleğe alınıyor…');
          },
          onbufferingprogress: (percent) => {
            if (this._valid(id)) this._status('buffering', 'Arabellek %' + Math.round(Number(percent) || 0));
          },
          onbufferingcomplete: () => {
            if (this._valid(id) && this.playing && !this.paused) this._status('playing', '');
          },
          oncurrentplaytime: (milliseconds) => {
            if (this._valid(id)) {
              if (!this.paused) this._markPlaying(id);
              this._progress(Number(milliseconds) / 1000);
            }
          },
          onstreamcompleted: () => { if (this._valid(id)) this._ended(id); },
          onsubtitlechange: (duration, value) => { if (this._valid(id) && this._subtitleIndex >= 0) this._showSubtitle(value, duration, id); },
          onerror: () => { if (this._valid(id)) this._fallback(id); }
        });
        if (!this._valid(id)) return;
        this.refreshRect();
        this.setAspectRatio(this.aspectRatio);
        try { this.av.setSilentSubtitle(true); } catch (_) { /* Optional native subtitle control. */ }
        this.av.prepareAsync(() => {
          // A canceled preparation must never stop, close, or play a newer channel.
          if (!this._valid(id) || this._avOwner !== id) return;
          try {
            this.refreshRect();
            const start = this._request.startAt;
            if (!this.live && start > 0) {
              try { this.av.seekTo(Math.round(start * 1000)); } catch (_) { /* Resume is optional. */ }
            }
            this.av.play();
            this._markPlaying(id);
          } catch (_) { this._fallback(id); }
        }, () => { if (this._valid(id)) this._fallback(id); });
      } catch (_) { this._fallback(id); }
    }

    _fallback(id) {
      if (!this._valid(id)) return;
      if (!this.live && this._lastPosition > 0) this._request.startAt = this._lastPosition;
      if (this.live && this._attempt.avSourceIndex + 1 < this._attempt.sources.length) {
        this._request.url = this._attempt.sources[++this._attempt.avSourceIndex];
      } else {
        this._attempt.browserOnly = true;
        this._request.url = this._attempt.sources.find((url) => /\.m3u8$/i.test(new URL(url).pathname)) || this._request.url;
      }
      // Samsung may still own the native error callback stack here. Invalidate
      // immediately, but let that callback and decoder teardown settle before open().
      const recovery = ++this._generation, request = this._request, attempt = this._attempt;
      this._dispose();
      this._after(() => {
        if (this._valid(recovery) && this._request === request && this._attempt === attempt) this._start();
      }, 100);
    }

    _startBrowser(id) {
      const request = this._request;
      const pathname = new URL(request.url).pathname.toLowerCase();
      const hlsSource = /\.m3u8$/.test(pathname);
      const directTS = /\.ts$/.test(pathname);
      this._showEngine('HTML5');
      this.setAspectRatio(this.aspectRatio);
      this._bindNativeSubtitles(id);
      this._listen('playing', () => { if (this._valid(id)) this._markPlaying(id); });
      this._listen('timeupdate', () => {
        if (this._valid(id)) this._progress(this.video.currentTime);
      });
      this._listen('waiting', () => {
        if (this._valid(id)) this._status('buffering', 'Yayın arabelleğe alınıyor…');
      });
      this._listen('pause', () => {
        if (this._valid(id) && !this.video.ended && this.playing) {
          this.paused = true;
          this._status('paused', 'Duraklatıldı');
        }
      });
      this._listen('ended', () => { if (this._valid(id)) this._ended(id); });
      this._listen('error', () => {
        if (!this._valid(id) || this._hls) return;
        this._fail(id, 'Yayın açılamadı. Sunucu erişimini, CORS iznini ve desteklenen ses/video codec’lerini kontrol edin.');
      });
      this._listen('loadedmetadata', () => {
        if (!this._valid(id) || request.live || !request.startAt) return;
        try {
          const maximum = Number.isFinite(this.video.duration) ? Math.max(0, this.video.duration - 1) : request.startAt;
          this.video.currentTime = Math.min(request.startAt, maximum);
        } catch (_) { /* Seeking before the first seekable range is available is optional. */ }
      });
      if (hlsSource && global.Hls && global.Hls.isSupported()) {
        this._startHLS(id);
        return;
      }
      if (directTS && !this.video.canPlayType('video/mp2t')) {
        this._fail(id, 'Doğrudan .ts akışı bu tarayıcıda desteklenmiyor. Canlı yayın biçimini HLS (.m3u8) yapın veya TV’de AVPlay kullanın.');
        return;
      }
      if (hlsSource && !this.video.canPlayType('application/vnd.apple.mpegurl') && !this.video.canPlayType('application/x-mpegURL')) {
        this._fail(id, 'Bu cihazda HLS için MediaSource veya yerel HLS desteği bulunamadı.');
        return;
      }
      this.video.src = request.url;
      this.video.load();
      this._playVideo(id);
    }

    _startHLS(id) {
      this._showEngine('HLS.js');
      const Hls = global.Hls;
      let networkRecoveries = 0;
      let mediaRecoveries = 0;
      try {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          maxBufferLength: 20,
          maxMaxBufferLength: 30,
          backBufferLength: this.live ? 10 : 20,
          maxBufferSize: 30 * 1000 * 1000,
          capLevelToPlayerSize: true,
          startLevel: -1,
          manifestLoadPolicy: { default: { maxTimeToFirstByteMs: 10000, maxLoadTimeMs: 15000, timeoutRetry: { maxNumRetry: 1, retryDelayMs: 1000, maxRetryDelayMs: 2000 }, errorRetry: { maxNumRetry: 1, retryDelayMs: 1000, maxRetryDelayMs: 2000 } } }
        });
        this._hls = hls;
        hls.subtitleDisplay = false;
        hls.on(Hls.Events.MEDIA_ATTACHED, () => { if (this._valid(id)) hls.loadSource(this._request.url); });
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (this._valid(id)) { if (this._subtitleIndex < 0) hls.subtitleTrack = -1; this._playVideo(id); }
        });
        hls.on(Hls.Events.ERROR, (_, data) => {
          if (!this._valid(id) || !data || !data.fatal) return;
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR && networkRecoveries++ < 2) {
            this._status('buffering', 'Ağ bağlantısı yeniden deneniyor…');
            this._after(() => {
              if (this._valid(id) && this._hls === hls) {
                try { hls.startLoad(); } catch (_) { this._fail(id, 'Yayın bağlantısı yeniden kurulamadı.'); }
              }
            }, 1000 * networkRecoveries);
          } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRecoveries++ < 1) {
            try { hls.recoverMediaError(); } catch (_) { this._fail(id, 'Ses veya video bu cihazda çözümlenemedi.'); }
          } else {
            this._fail(id, 'HLS yayını açılamadı. Ağ, CORS, HTTPS ve codec uyumunu kontrol edin.');
          }
        });
        hls.attachMedia(this.video);
      } catch (_) { this._fail(id, 'HLS oynatıcı başlatılamadı. Cihazın MediaSource desteğini kontrol edin.'); }
    }

    _playVideo(id) {
      if (!this._valid(id)) return;
      try {
        const started = this.video.play();
        if (started && typeof started.catch === 'function') {
          started.catch((error) => {
            if (!this._valid(id)) return;
            const denied = error && error.name === 'NotAllowedError';
            this._fail(id, denied ? 'Otomatik oynatma engellendi. Kumandada Yeniden dene veya Enter tuşuna basın.' : 'Video başlatılamadı. Yayın biçimini ve sunucu erişimini kontrol edin.');
          });
        }
      } catch (_) { this._fail(id, 'Video başlatılamadı.'); }
    }

    _markPlaying(id) {
      if (!this._valid(id)) return;
      const first = !this.playing;
      const resumed = this.paused;
      this.playing = true;
      this.paused = false;
      if (first || resumed) {
        this._lastProgress = Date.now();
        this._status('playing', '');
      }
      if (first) {
        this._emit('onPlaying');
        this._watch(id);
      }
    }

    _progress(position) {
      if (Number.isFinite(position) && Math.abs(position - this._lastPosition) > 0.05) {
        this._lastPosition = position;
        this._lastProgress = Date.now();
      }
    }

    _watch(id) {
      this._after(() => {
        if (!this._valid(id)) return;
        if (!this.paused && !document.hidden && Date.now() - this._lastProgress > 25000) {
          if (this._attempt.restarts < 1) {
            this._attempt.restarts += 1;
            if (!this.live && this._lastPosition > 0) this._request.startAt = this._lastPosition;
            this._start();
          } else {
            this._fail(id, 'Yayın ilerlemiyor. Otomatik kurtarma sınırına ulaşıldı; Yeniden dene ile tekrar açın.');
          }
          return;
        }
        if (this.paused || document.hidden) this._lastProgress = Date.now();
        this._watch(id);
      }, 5000);
    }

    _fail(id, message) {
      if (!this._valid(id)) return;
      if (this.live && this._attempt && this._attempt.browserOnly) {
        const next = this._attempt.sources.find((url) => !this._attempt.browserTried.has(url));
        if (next) { this._request.url = next; this._start(); return; }
      }
      ++this._generation;
      this._failed = true;
      this._dispose();
      this._status('error', message);
      this._emit('onError', message);
    }

    _ended(id) {
      if (!this._valid(id)) return;
      ++this._generation;
      this._dispose();
      this._status('ended', 'Yayın sona erdi.');
      this._emit('onEnded');
    }

    togglePause() {
      if (!this.playing || this._failed || this._destroyed) return false;
      if (this.engine === 'AVPlay' && this._seekBusy) return false;
      try {
        if (this.engine === 'AVPlay') {
          const state = this._avState();
          if (state === 'PLAYING') {
            this.av.pause();
            this.paused = true;
            this._status('paused', 'Duraklatıldı');
          } else if (state === 'PAUSED') {
            this.av.play();
            this.paused = false;
            this._lastProgress = Date.now();
            this._status('playing', '');
          } else return false;
        } else if (this.video.paused) {
          this.paused = false;
          this._lastProgress = Date.now();
          this._playVideo(this._generation);
        } else {
          this.video.pause();
        }
        return true;
      } catch (_) {
        this._status(this.paused ? 'paused' : 'playing', 'Bu yayın duraklatma/devam ettirme işlemini desteklemiyor.');
        return false;
      }
    }

    _plainText(value, limit) {
      return String(value == null ? '' : value).replace(/<br\s*\/?\s*>/gi, '\n').replace(/<[^>]*>/g, '')
        .replace(/&nbsp;/gi, ' ').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&amp;/gi, '&')
        .replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, '').slice(0, limit || 500);
    }

    _showSubtitle(value, duration, id) {
      if (this._subtitleTimer) { global.clearTimeout(this._subtitleTimer); this._timers.delete(this._subtitleTimer); this._subtitleTimer = null; }
      const text = this._plainText(value, 500); this._emit('onSubtitle', text);
      if (text) this._subtitleTimer = this._after(() => {
        this._subtitleTimer = null; if (this._valid(id)) this._emit('onSubtitle', '');
      }, Math.max(200, Math.min(20000, Number(duration) || 3000)));
    }

    _bindNativeSubtitles(id) {
      const list = this.video.textTracks;
      this._nativeBound = new Set();
      const sync = () => { if (this._valid(id)) this._syncNativeSubtitles(id); };
      if (list && typeof list.addEventListener === 'function') {
        list.addEventListener('addtrack', sync); list.addEventListener('change', sync);
        this._trackCleanup.push(() => { list.removeEventListener('addtrack', sync); list.removeEventListener('change', sync); });
      }
      sync();
    }

    _syncNativeSubtitles(id) {
      const list = this.video.textTracks, rows = [];
      if (!list) return;
      for (let i = 0; i < list.length; i++) if (list[i].kind === 'subtitles' || list[i].kind === 'captions') rows.push(list[i]);
      let chosen = this._subtitleIndex < 0 ? null : rows[this._subtitleIndex];
      const hlsTrack = this._hls && this._hls.subtitleTracks && this._hls.subtitleTracks[this._subtitleIndex];
      if (hlsTrack) chosen = rows.find((track) => track.language === hlsTrack.lang && (!hlsTrack.name || track.label === hlsTrack.name)) || chosen;
      rows.forEach((track) => {
        const mode = track === chosen ? 'hidden' : 'disabled';
        if (track.mode !== mode) track.mode = mode;
        if (this._nativeBound.has(track) || typeof track.addEventListener !== 'function') return;
        this._nativeBound.add(track);
        const changed = () => {
          if (!this._valid(id) || this._subtitleIndex < 0 || track.mode !== 'hidden') return;
          const cues = track.activeCues || [], text = [];
          for (let n = 0; n < cues.length; n++) text.push(cues[n].text || '');
          this._showSubtitle(text.join('\n'), 10000, id);
        };
        track.addEventListener('cuechange', changed);
        this._trackCleanup.push(() => { track.removeEventListener('cuechange', changed); try { track.mode = 'disabled'; } catch (_) { /* Removed track. */ } });
      });
    }

    _getTracks(type) {
      if (!this.playing || this._destroyed || this._failed || this.engine === 'AVPlay' && this._seekBusy) return [];
      try {
        if (this.engine === 'AVPlay') {
          if (['PLAYING', 'PAUSED'].indexOf(this._avState()) === -1) return [];
          const current = this.av.getCurrentStreamInfo() || [];
          return (this.av.getTotalTrackInfo() || []).filter((track) => track.type === type).slice(0, 100).map((track) => {
            let meta = {}; try { meta = JSON.parse(track.extra_info || '{}'); } catch (_) { /* Invalid optional metadata. */ }
            const language = this._plainText(meta.language || meta.track_lang || '', 24).replace(/\s+/g, ' ');
            return { index: Number(track.index), language, label: this._plainText(meta.label || meta.name || language || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (Number(track.index) + 1), 80).replace(/\s+/g, ' '),
              selected: type === 'TEXT' ? Number(track.index) === this._subtitleIndex : current.some((row) => row.type === type && Number(row.index) === Number(track.index)) };
          }).filter((track) => Number.isInteger(track.index) && track.index >= 0);
        }
        const hlsRows = this._hls && (type === 'AUDIO' ? this._hls.audioTracks : this._hls.subtitleTracks);
        if (hlsRows && hlsRows.length) return hlsRows.slice(0, 100).map((track, index) => ({ index,
          language: this._plainText(track.lang || '', 24), label: this._plainText(track.name || track.lang || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (index + 1), 80),
          selected: type === 'AUDIO' ? this._hls.audioTrack === index : this._subtitleIndex === index }));
        const list = type === 'AUDIO' ? this.video.audioTracks : this.video.textTracks, result = [];
        if (!list) return result;
        let subtitle = 0;
        for (let n = 0; n < list.length && n < 100; n++) {
          const track = list[n];
          if (type === 'TEXT' && track.kind !== 'subtitles' && track.kind !== 'captions') continue;
          const index = type === 'AUDIO' ? n : subtitle++;
          result.push({ index, language: this._plainText(track.language || '', 24), label: this._plainText(track.label || track.language || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (index + 1), 80),
            selected: type === 'AUDIO' ? Boolean(track.enabled) : this._subtitleIndex === index });
        }
        return result;
      } catch (_) { return []; }
    }

    getAudioTracks() { return this._getTracks('AUDIO'); }
    getSubtitleTracks() { return this._getTracks('TEXT'); }

    selectAudioTrack(value) {
      const index = Number(value);
      if (!Number.isInteger(index) || !this.getAudioTracks().some((track) => track.index === index)) return false;
      try {
        if (this.engine === 'AVPlay') {
          if (this._seekBusy || this._avState() !== 'PLAYING') return false;
          this.av.setSelectTrack('AUDIO', index);
        } else if (this._hls && this._hls.audioTracks && this._hls.audioTracks.length) this._hls.audioTrack = index;
        else {
          const tracks = this.video.audioTracks;
          for (let n = 0; n < tracks.length; n++) tracks[n].enabled = n === index;
        }
        return true;
      } catch (_) { return false; }
    }

    selectSubtitleTrack(value) {
      const index = Number(value);
      if (!this.playing || !Number.isInteger(index) || index < -1 || this.engine === 'AVPlay' && this._seekBusy) return false;
      if (index !== -1 && !this.getSubtitleTracks().some((track) => track.index === index)) return false;
      try {
        if (this.engine === 'AVPlay') {
          if (['PLAYING', 'PAUSED'].indexOf(this._avState()) === -1) return false;
          if (index !== -1) this.av.setSelectTrack('TEXT', index);
          this.av.setSilentSubtitle(true);
        } else if (this._hls) { this._hls.subtitleDisplay = false; this._hls.subtitleTrack = index; }
        this._subtitleIndex = index; this._showSubtitle('', 0, this._generation);
        if (this.engine !== 'AVPlay') this._syncNativeSubtitles(this._generation);
        return true;
      } catch (_) { return false; }
    }

    setAspectRatio(mode) {
      const modes = { fit: 'PLAYER_DISPLAY_MODE_LETTER_BOX', fill: 'PLAYER_DISPLAY_MODE_AUTO_ASPECT_RATIO', stretch: 'PLAYER_DISPLAY_MODE_FULL_SCREEN' };
      if (!Object.prototype.hasOwnProperty.call(modes, mode)) return false;
      if (this.engine === 'AVPlay' && this._seekBusy) return false;
      try {
        if (this.engine === 'AVPlay' && this._avOwner) this.av.setDisplayMethod(modes[mode]);
        this.video.style.objectFit = { fit: 'contain', fill: 'cover', stretch: 'fill' }[mode];
        this.aspectRatio = mode;
        return true;
      } catch (_) { return false; }
    }

    getPlaybackInfo() {
      const active = Boolean(this._request && this.playing && !this._failed && !this._destroyed);
      // Samsung forbids other AVPlay calls until an asynchronous seek completes.
      if (this.engine === 'AVPlay' && this._seekBusy) {
        const cached = this._playbackInfo || { currentTime: 0, duration: 0, seekable: [], canSeek: false };
        return Object.assign({}, cached, { seekable: cached.seekable.map((range) => Object.assign({}, range)),
          paused: this.paused, playing: active, live: this.live, canSeek: active && cached.canSeek, seeking: true });
      }
      let currentTime = 0, duration = 0, seekable = [];
      if (active) {
        try {
          if (this.engine === 'AVPlay') {
            currentTime = Number(this.av.getCurrentTime()) / 1000;
            duration = Number(this.av.getDuration()) / 1000;
          } else {
            currentTime = Number(this.video.currentTime);
            duration = Number(this.video.duration);
          }
        } catch (_) { /* Metadata can be temporarily unavailable during a decoder transition. */ }
      }
      duration = Number.isFinite(duration) && duration > 0 ? duration : 0;
      currentTime = Number.isFinite(currentTime) && currentTime > 0 ? currentTime : 0;
      if (duration) currentTime = Math.min(currentTime, duration);
      if (active && !this.live && duration) {
        if (this.engine === 'AVPlay') {
          if (duration >= 2 && ['READY', 'PLAYING', 'PAUSED'].indexOf(this._avState()) !== -1) seekable = [{ start: 0.001, end: duration - 1 }];
        } else {
          const maximum = Math.max(0, duration - 0.2);
          const ranges = this.video.seekable;
          if (ranges) {
            try {
              for (let i = 0; i < ranges.length; i++) {
                const start = Math.max(0, Number(ranges.start(i)));
                const end = Math.min(maximum, Number(ranges.end(i)));
                if (Number.isFinite(start) && Number.isFinite(end) && end >= start) seekable.push({ start, end });
              }
            } catch (_) { seekable = []; }
          } else if (duration > 0.2) seekable = [{ start: 0, end: maximum }];
        }
      }
      const info = { currentTime, duration, seekable, paused: this.paused, playing: active,
        live: this.live, canSeek: seekable.length > 0, seeking: this._seekBusy };
      this._playbackInfo = info;
      return Object.assign({}, info, { seekable: seekable.map((range) => Object.assign({}, range)) });
    }

    seekTo(seconds) {
      const requested = Number(seconds), info = this.getPlaybackInfo();
      if (!Number.isFinite(requested) || !info.canSeek || this._seekBusy) return false;
      // Keep targets inside a real seekable range; choose its closest edge for gaps.
      let target = info.seekable[0].start, distance = Infinity;
      info.seekable.forEach(function (range) {
        const candidate = Math.max(range.start, Math.min(range.end, requested));
        const difference = Math.abs(candidate - requested);
        if (difference < distance) { distance = difference; target = candidate; }
      });
      try {
        if (this.engine === 'AVPlay') {
          const id = this._generation, seekToken = ++this._seekToken;
          this._seekBusy = true;
          const completed = (failed) => {
            if (!this._valid(id) || this._seekToken !== seekToken || !this._seekBusy) return;
            global.clearTimeout(timeout); this._timers.delete(timeout);
            this._seekBusy = false; this._lastProgress = Date.now();
            if (this._rectPending) { this._rectPending = false; this.refreshRect(); }
            if (failed) this._status(this.paused ? 'paused' : 'playing', 'Bu konuma atlanamadı; başka bir zaman deneyin.');
          };
          const timeout = this._after(() => completed(true), 5000);
          try { this.av.seekTo(Math.round(target * 1000), () => completed(false), () => completed(true)); }
          catch (_) { completed(true); return false; }
        } else {
          this.video.currentTime = target;
          this._lastProgress = Date.now();
        }
        return true;
      } catch (_) {
        this._status(this.paused ? 'paused' : 'playing', 'Bu yayında ileri/geri sarma kullanılamıyor.');
        return false;
      }
    }

    seekBy(seconds) {
      const delta = Number(seconds);
      if (!Number.isFinite(delta)) return false;
      return this.seekTo(this.getPlaybackInfo().currentTime + delta);
    }

    setFullscreen(enabled) {
      this.fullscreen = Boolean(enabled);
      this.refreshRect();
    }

    refreshRect() {
      if (this.engine !== 'AVPlay' || !this._avOwner) return;
      if (this._seekBusy) { this._rectPending = true; return; }
      const bounds = this.fullscreen ? { left: 0, top: 0, width: global.innerWidth, height: global.innerHeight } : this.shell.getBoundingClientRect();
      const viewportWidth = document.documentElement.clientWidth || global.innerWidth || 1920;
      const viewportHeight = document.documentElement.clientHeight || global.innerHeight || 1080;
      const x = Math.max(0, Math.min(1919, Math.round(bounds.left * 1920 / viewportWidth)));
      const y = Math.max(0, Math.min(1079, Math.round(bounds.top * 1080 / viewportHeight)));
      const width = Math.max(1, Math.min(1920 - x, Math.round(bounds.width * 1920 / viewportWidth)));
      const height = Math.max(1, Math.min(1080 - y, Math.round(bounds.height * 1080 / viewportHeight)));
      try { this.av.setDisplayRect(x, y, width, height); } catch (_) { /* Only valid after open() on the hardware decoder. */ }
    }

    stop() {
      ++this._generation;
      this._failed = false;
      this._dispose();
      this._request = null;
      this._attempt = null;
      this._status('stopped', '');
    }

    destroy() {
      if (this._destroyed) return;
      this.stop();
      this._destroyed = true;
      this.options = {};
    }
  }

  global.TVPlayer = TVPlayer;
})(window);

/* AKIŞ TV — MIT. This controller is bundled after TVPlayer in app.js. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var STORE = 'akis.credentials.v1';
  var PREFS = 'akis.preferences.v1';
  var MODES = { live: 'Canlı TV', vod: 'Filmler', series: 'Diziler' };
  var state = {
    screen: 'login', mode: 'live', credentials: null, account: null, demo: false,
    categories: [], items: [], filtered: [], categoryIndex: 0, selected: -1,
    episodes: null, playing: null, fullscreen: false, editing: null,
    token: 0, loginToken: 0, searchToken: 0, requests: new Set(), cache: new Map(),
    format: 'm3u8', busy: false, confirm: null, lastFocus: null, suspended: false,
    seekTarget: null, dialogType: '', seekRepeats: 0
  };
  var tuneTimer, filterTimer, toastTimer, overlayTimer, transportTimer, focusedNode, extras;

  function text(id, value) {
    var node = $(id), copy = value == null ? '' : String(value);
    if (node.textContent !== copy) node.textContent = copy;
  }
  function message(value) {
    text('toast', value); $('toast').hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { $('toast').hidden = true; }, 4500);
  }
  function busy(value) {
    state.busy = value; $('busy-indicator').hidden = !value;
    $('browser-screen').setAttribute('aria-busy', String(value));
    $('login-button').disabled = value && state.screen === 'login';
  }
  function safeStorage(method, key, value) {
    // Explicit preferences may persist; viewing and search activity never do.
    if (key !== STORE && key !== 'akis.format' && key !== PREFS) return null;
    try { return localStorage[method](key, value); }
    catch (error) { if (method === 'setItem') message('TV depolaması kullanılamıyor; bilgiler bu oturumda tutulacak.'); return null; }
  }
  function clearLegacyHistory() {
    // Remove this app's obsolete keys without touching another app's storage.
    try {
      for (var i = localStorage.length - 1; i >= 0; i--) {
        var key = localStorage.key(i);
        if (key && key.indexOf('akis.') === 0 && key !== STORE && key !== 'akis.format' && key !== PREFS) localStorage.removeItem(key);
      }
      for (var n = sessionStorage.length - 1; n >= 0; n--) {
        var transient = sessionStorage.key(n);
        if (transient && transient.indexOf('akis.') === 0) sessionStorage.removeItem(transient);
      }
    } catch (_) { /* Storage can be unavailable; playback never depends on it. */ }
  }
  function normalizeServer(value) {
    var parsed;
    try { parsed = new URL(String(value).trim()); } catch (error) { throw new Error('Sunucu adresini http:// veya https:// ile girin.'); }
    if (!/^https?:$/.test(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new Error('Sunucu alanına yalnızca HTTP/HTTPS adresi ve gerekiyorsa port / dizin girin.');
    }
    parsed.pathname = parsed.pathname.replace(/\/player_api\.php\/?$/i, '').replace(/\/+$/, '');
    return parsed.href.replace(/\/+$/, '');
  }
  function abortRequests() {
    state.requests.forEach(function (xhr) { xhr.abort(); }); state.requests.clear();
  }
  function api(action, params, credentials) {
    var auth = credentials || state.credentials;
    var url = auth.server + '/player_api.php?username=' + encodeURIComponent(auth.username) + '&password=' + encodeURIComponent(auth.password);
    if (action) url += '&action=' + encodeURIComponent(action);
    Object.keys(params || {}).forEach(function (key) { url += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(params[key]); });
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest(); state.requests.add(xhr);
      function done(error, data) { state.requests.delete(xhr); error ? reject(error) : resolve(data); }
      xhr.open('GET', url, true); xhr.timeout = 16000;
      xhr.onload = function () {
        if (xhr.status < 200 || xhr.status >= 300) return done(new Error('Sunucu HTTP ' + xhr.status + ' yanıtı verdi.'));
        if (xhr.responseText.length > 16 * 1024 * 1024) return done(new Error('Kategori yanıtı 16 MB sınırını aşıyor. Sağlayıcıdan daha küçük kategoriler isteyin.'));
        try { done(null, JSON.parse(xhr.responseText)); }
        catch (error) { done(new Error('Sunucu geçerli JSON göndermedi. URL ve Xtream Codes desteğini kontrol edin.')); }
      };
      xhr.onprogress = function (event) {
        if (event.loaded > 16 * 1024 * 1024) {
          xhr.onabort = function () { done(new Error('Yanıt 16 MB sınırını aştı; daha küçük bir kategori gerekli.')); }; xhr.abort();
        }
      };
      xhr.onerror = function () { done(new Error('Bağlantı kurulamadı. Ağ, CORS, HTTP/HTTPS ve sertifikayı kontrol edin.')); };
      xhr.ontimeout = function () { done(new Error('Sunucu 16 saniye içinde yanıt vermedi.')); };
      xhr.onabort = function () { var error = new Error('İstek iptal edildi.'); error.cancelled = true; done(error); };
      xhr.send();
    });
  }
  function short(value, max) { return String(value == null ? '' : value).slice(0, max || 300); }
  function imageURL(value) {
    try { var u = new URL(String(value)); return /^https?:$/.test(u.protocol) && !u.username && !u.password ? u.href : ''; }
    catch (error) { return ''; }
  }
  function normalizeItems(rows, kind, token) {
    if (!Array.isArray(rows)) return Promise.reject(new Error('Sağlayıcı beklenen liste biçimini göndermedi.'));
    return new Promise(function (resolve, reject) {
      var result = [], cursor = 0;
      function chunk() {
        if (token !== state.token) { var e = new Error('İstek iptal edildi.'); e.cancelled = true; return reject(e); }
        var end = Math.min(cursor + 300, rows.length);
        for (; cursor < end; cursor++) {
          var row = rows[cursor] || {};
          var id = kind === 'series' ? row.series_id : row.stream_id;
          if (id == null || !/^\d+$/.test(String(id))) continue;
          result.push({ id: String(id), kind: kind, name: short(row.name || 'İsimsiz yayın', 220),
            image: imageURL(row.stream_icon || row.cover), category: short(row.category_id || Array.isArray(row.category_ids) && row.category_ids[0] || '', 60),
            categories: (Array.isArray(row.category_ids) ? row.category_ids : [row.category_id]).filter(function (value) { return value != null; }).map(function (value) { return short(value, 60); }).slice(0, 30),
            extension: /^[a-z0-9]{2,5}$/i.test(row.container_extension || '') ? row.container_extension : 'mp4',
            description: short(row.plot || row.description || '', 800), rating: short(row.rating || '', 12) });
        }
        if (cursor < rows.length) setTimeout(chunk, 0); else resolve(result);
      }
      chunk();
    });
  }

  // Only visible rows exist in the DOM, even with thousands of channels.
  function VirtualList(kind, height, label) {
    this.kind = kind; this.height = height; this.label = label; this.rows = [];
    this.root = $(kind + '-list'); this.window = $(kind + '-window'); this.spacer = $(kind + '-spacer');
    this.start = -1; this.end = -1; this.frame = null; this.nodes = new Map();
    var self = this;
    this.root.addEventListener('scroll', function () {
      if (!self.frame) self.frame = requestAnimationFrame(function () { self.frame = null; self.render(); });
    });
  }
  VirtualList.prototype.set = function (rows) {
    if (this.frame) cancelAnimationFrame(this.frame);
    this.frame = null;
    this.nodes.clear();
    while (this.window.firstChild) this.window.removeChild(this.window.firstChild);
    this.rows = rows; this.root.scrollTop = 0; this.start = -1; this.end = -1;
    this.spacer.style.height = (rows.length * this.height) + 'px'; this.render(true);
  };
  VirtualList.prototype.render = function (force) {
    var start = Math.max(0, Math.floor(this.root.scrollTop / this.height) - 3);
    var end = Math.min(this.rows.length, start + Math.ceil((this.root.clientHeight || 600) / this.height) + 7);
    if (!force && start === this.start && end === this.end) return;
    var active = document.activeElement;
    var restore = !state.fullscreen && active && this.window.contains(active) ? Number(active.dataset.index) : -1;
    this.start = start; this.end = end;
    this.window.style.transform = 'translateY(' + start * this.height + 'px)';
    var self = this;
    this.nodes.forEach(function (node, index) {
      if (index < start || index >= end) { node.remove(); self.nodes.delete(index); }
    });
    var cursor = this.window.firstChild;
    for (var i = start; i < end; i++) {
      var row = this.rows[i], button = this.nodes.get(i);
      if (!button) {
        button = document.createElement('button');
        button.type = 'button'; button.className = 'list-row ' + this.kind + '-row';
        button.dataset.nav = ''; button.dataset.zone = this.kind; button.dataset.index = String(i);
        button.setAttribute('aria-label', this.label(row, i));
        if (this.kind !== 'category') {
          var number = document.createElement('span'); number.className = 'row-index'; number.textContent = String(i + 1).padStart(2, '0'); button.appendChild(number);
        }
        var copy = document.createElement('span'); copy.className = 'row-copy';
        var title = document.createElement('span'); title.className = 'row-label'; title.textContent = (row.locked ? '🔒 ' : '') + row.name; copy.appendChild(title);
        if (this.kind === 'stream') {
          var subtitle = document.createElement('span'); subtitle.className = 'row-subtitle';
          subtitle.textContent = row.kind === 'live' ? 'CANLI YAYIN' : row.kind === 'episode' ? 'BÖLÜM' : row.kind === 'series' ? 'DİZİ' : 'FİLM'; copy.appendChild(subtitle);
        }
        button.appendChild(copy); this.nodes.set(i, button);
      }
      if (this.kind === 'category') {
        var selected = i === state.categoryIndex;
        button.classList.toggle('is-selected', selected); button.setAttribute('aria-pressed', String(selected));
      } else {
        button.classList.toggle('is-selected', i === state.selected);
        button.classList.toggle('is-playing', !!state.playing && state.playing.id === row.id && state.playing.kind === row.kind);
      }
      if (button !== cursor) this.window.insertBefore(button, cursor);
      cursor = button.nextSibling;
    }
    if (restore >= start && restore < end) this.focus(restore, false);
  };
  VirtualList.prototype.focus = function (index, scroll) {
    if (!this.rows.length) return focusElement($('search-input'));
    index = Math.max(0, Math.min(index, this.rows.length - 1));
    if (scroll !== false) {
      var top = index * this.height, bottom = top + this.height;
      if (top < this.root.scrollTop) this.root.scrollTop = top;
      else if (bottom > this.root.scrollTop + this.root.clientHeight) this.root.scrollTop = bottom - this.root.clientHeight;
      this.render();
    }
    focusElement(this.window.querySelector('[data-index="' + index + '"]'));
  };
  var categories = new VirtualList('category', 68, function (row) { return row.name; });
  var streams = new VirtualList('stream', 82, function (row, i) { return (i + 1) + '. ' + row.name; });

  function visible(element) { return element && !element.disabled && element.getBoundingClientRect().width > 0 && !element.closest('[hidden]'); }
  function focusElement(element) {
    if (!visible(element)) return;
    if (!$('dialog').hidden && !$('dialog').contains(element)) return;
    if ($('dialog').hidden && !$('feature-dialog').hidden && !$('feature-dialog').contains(element)) return;
    try { element.focus({ preventScroll: true }); } catch (error) { element.focus(); }
    if (element.closest('#feature-content,.detail-info,#searchall-results')) {
      try { element.scrollIntoView({ block: 'nearest' }); } catch (_) { /* Optional on older TV engines. */ }
    }
  }
  function showScreen(screen) {
    state.screen = screen;
    ['login', 'home', 'browser', 'search'].forEach(function (name) { $(name + '-screen').hidden = name !== screen; });
    $('home-button').hidden = screen === 'login'; $('settings-button').hidden = screen === 'login';
    text('key-hints', screen === 'login' ? 'Yön tuşları: gezin  ·  OK: alanı düzenle / tamamla  ·  Geri: düzenlemeyi kapat' :
      'Yön tuşları: gezin  ·  OK: seç / tam ekran  ·  Geri: önceki ekran');
    requestAnimationFrame(function () { player.refreshRect(); });
  }
  function showLogin(note) {
    state.token++; state.loginToken++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    player.stop(); state.playing = null; state.cache.clear(); state.credentials = null;
    state.demo = false; showScreen('login'); setFullscreen(false); busy(false);
    if (extras) extras.resetSession();
    text('connection-status', 'HESAP BAĞLI DEĞİL'); text('login-message', note || 'Xtream Codes hesabınızla kütüphanenize bağlanın.');
    focusElement($('server-url'));
  }
  function updateAccount() {
    text('account-name', state.demo ? 'Yerel örnek · hesap gerekmez' : state.credentials.username);
    var expiry = state.account && state.account.exp_date;
    text('account-expiry', state.demo ? '120 saniyelik MIT video · çevrimdışı' :
      expiry && Number(expiry) > 0 ? 'Bitiş: ' + new Date(Number(expiry) * 1000).toLocaleDateString('tr-TR') : 'Hesap etkin');
    text('connection-status', state.demo ? 'YEREL ÖRNEK MODU' : 'XTREAM BAĞLI');
  }
  function showHome() {
    state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer); busy(false);
    player.stop(); state.playing = null; showScreen('home'); setFullscreen(false); updateAccount();
    if (extras) extras.resetSession();
    focusElement(document.querySelector('[data-mode="' + state.mode + '"]'));
  }
  async function login(credentials, automatic) {
    var token = ++state.loginToken; busy(true); text('login-message', automatic ? 'Kayıtlı hesabınıza bağlanılıyor…' : 'Hesap doğrulanıyor…');
    try {
      credentials.server = normalizeServer(credentials.server);
      if (!credentials.username || !credentials.password) throw new Error('Kullanıcı adı ve şifre gerekli.');
      if (location.protocol === 'https:' && credentials.server.indexOf('http:') === 0) throw new Error('HTTPS önizlemesi HTTP sunucuya erişemez. TV widget’ını veya sağlayıcının HTTPS adresini kullanın.');
      var response = await api('', {}, credentials);
      if (token !== state.loginToken) return;
      var account = response && response.user_info;
      if (!account || !(account.auth === true || Number(account.auth) === 1)) throw new Error('Giriş reddedildi. Kullanıcı adı ve şifreyi kontrol edin.');
      if (account.status && String(account.status).toLowerCase() !== 'active') throw new Error('Hesap etkin değil. Sağlayıcınızla görüşün.');
      state.credentials = credentials; state.account = account; state.demo = false;
      safeStorage('setItem', STORE, JSON.stringify(credentials)); busy(false); showHome();
    } catch (error) {
      if (token !== state.loginToken || error.cancelled) return;
      busy(false); text('login-message', error.message); focusElement($('login-button'));
    }
  }
  function demoItems(mode) {
    var label = mode === 'live' ? 'Örnek video · Liste satırı' : mode === 'vod' ? 'Örnek video · Film görünümü' : 'Örnek video · Dizi görünümü';
    var count = mode === 'live' ? 5000 : mode === 'vod' ? 120 : 24;
    return Array.from({ length: count }, function (_, i) {
      return { id: String(i + 1), kind: mode, name: label + ' ' + (i + 1),
        image: '', extension: 'mp4', description: 'Her demo satırı paketteki aynı 120 saniyelik özgün MIT örnek videoyu açar. Bu bir canlı TV yayını veya film/dizi kataloğu değildir. İki ses parçası yalnız sentetik test tonlarıdır; gömülü altyazı yoktur.', rating: '' };
    });
  }
  async function loadMode(mode, desiredCategory) {
    if (!MODES[mode]) return;
    if (extras) extras.clearDigits();
    state.mode = mode; state.episodes = null; state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    player.stop(); state.playing = null; state.selected = -1; state.categories = []; state.filtered = []; state.items = [];
    categories.set([]); streams.set([]); $('search-input').value = ''; showScreen('browser');
    text('browser-title', MODES[mode]); text('browser-subtitle', 'Kategoriler yükleniyor…'); resetDetails(); busy(true);
    focusElement($('home-button'));
    var token = state.token;
    try {
      var rows = state.demo ? [{ category_id: 'demo', category_name: 'Yerel örnek video' }, { category_id: 'sample', category_name: 'Liste gezinme testi' }] :
        await api(mode === 'live' ? 'get_live_categories' : mode === 'vod' ? 'get_vod_categories' : 'get_series_categories');
      if (token !== state.token) return;
      if (!Array.isArray(rows)) throw new Error('Kategori listesi alınamadı.');
      state.categories = rows.map(function (row) { return { id: short(row.category_id, 60), name: short(row.category_name || 'İsimsiz kategori', 120) }; });
      if (!state.categories.length) state.categories = [{ id: '', name: 'Tüm içerikler' }];
      if (extras) { extras.rememberCategories(mode, state.categories); state.categories = extras.visibleCategories(mode, state.categories); }
      state.categoryIndex = Math.max(0, state.categories.findIndex(function (row) { return row.id === desiredCategory; }));
      categories.set(state.categories);
      if (!state.categories.length) { busy(false); text('browser-subtitle', 'Tüm kategoriler gizli. Kategori ayarlarından tekrar gösterebilirsiniz.'); focusElement($('category-settings-button')); return; }
      categories.focus(state.categoryIndex);
      return await loadCategory(state.categoryIndex);
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); text('browser-subtitle', error.message); message(error.message); } }
  }
  async function loadCategory(index) {
    if (!state.categories[index]) return;
    if (extras) extras.clearDigits();
    if (extras && !extras.categoryAllowed(state.mode, state.categories[index].id)) {
      return extras.unlockCategory(state.mode, state.categories[index].id, function () { loadCategory(index); });
    }
    if (index === state.categoryIndex && state.items.length && !state.episodes && !state.busy && !$('search-input').value) return state.token;
    state.categoryIndex = index; state.episodes = null; state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    var token = state.token, category = state.categories[index];
    var key = state.mode + ':' + category.id;
    state.items = []; state.filtered = []; state.selected = -1; streams.set([]); categories.render(true);
    player.stop(); state.playing = null; $('search-input').value = ''; resetDetails(); busy(true);
    text('browser-subtitle', category.name + ' · yükleniyor…');
    try {
      var items = state.cache.get(key);
      if (!items) {
        if (state.demo) items = demoItems(state.mode);
        else {
          var action = state.mode === 'live' ? 'get_live_streams' : state.mode === 'vod' ? 'get_vod_streams' : 'get_series';
          var rows = await api(action, category.id ? { category_id: category.id } : {});
          items = await normalizeItems(rows, state.mode, token);
        }
        if (token !== state.token) return;
        state.cache.set(key, items);
        while (state.cache.size > 3) state.cache.delete(state.cache.keys().next().value);
      }
      if (token !== state.token) return;
      items.forEach(function (item) { if (!item.category) item.category = category.id; });
      if (extras) items = items.filter(function (item) { return extras.itemAllowed(item); });
      state.items = items; state.filtered = items; streams.set(items); busy(false); updateCount();
      if (items.length) selectItem(0, false);
      return token;
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); text('browser-subtitle', error.message); message(error.message); } }
  }
  function updateCount() {
    var category = state.categories[state.categoryIndex];
    text('browser-subtitle', (state.episodes ? state.episodes.title + ' · Bölümler' : category ? category.name : MODES[state.mode]) +
      ' · ' + state.filtered.length.toLocaleString('tr-TR') + ' içerik' + (state.demo ? ' · DEMO' : ''));
  }
  function resetDetails() {
    if (extras) extras.clearEPG();
    text('detail-title', 'Bir içerik seçin'); text('detail-meta', 'Kütüphaneniz hazır');
    text('detail-description', 'Yön tuşlarıyla gezinin. Canlı kanallar kısa beklemenin ardından önizlemede açılır. OK ile tam ekrana geçin.');
    $('detail-image').hidden = true; $('detail-image').removeAttribute('src');
    $('watch-button').disabled = true; $('retry-button').disabled = true; $('pause-button').disabled = true;
    $('format-button').hidden = state.demo || state.mode !== 'live';
    $('player-placeholder').hidden = false; text('placeholder-label', 'Yayın önizlemesi');
    text('playback-status', 'Bir içerik seçin');
  }
  function selectItem(index, preview) {
    var item = state.filtered[index]; if (!item) return;
    state.selected = index; text('detail-title', item.name);
    text('detail-meta', (item.kind === 'episode' ? 'Dizi bölümü' : MODES[item.kind]) + (item.rating ? ' · ★ ' + item.rating : '') + (state.demo ? ' · YEREL ÖRNEK · 120 sn' : ''));
    text('detail-description', item.description || (item.kind === 'live' ? 'OK ile tam ekrana geçin. Tam ekranda ↑ / ↓ ile kanal değiştirin.' :
      item.kind === 'series' ? 'OK ile sezon ve bölüm listesini açın.' : 'OK ile oynatın. Tam ekranda ← / → ile 10 saniye sarın.'));
    var image = $('detail-image'); image.hidden = !item.image;
    if (item.image && image.getAttribute('src') !== item.image) image.src = item.image;
    if (!item.image) image.removeAttribute('src');
    $('watch-button').disabled = false; text('watch-button', item.kind === 'series' ? 'Bölümleri aç' : 'Tam ekran izle');
    $('format-button').hidden = state.demo || item.kind !== 'live';
    if (extras) extras.selectItem(item);
    streams.window.querySelectorAll('[data-index]').forEach(function (button) { button.classList.toggle('is-selected', Number(button.dataset.index) === index); });
    clearTimeout(tuneTimer);
    if (preview && item.kind === 'live' && (!state.playing || state.playing.id !== item.id)) {
      tuneTimer = setTimeout(function () { startPlayback(item, false); }, 450);
    }
  }
  async function openSeries(item) {
    if (extras && !extras.itemAllowed(item)) return extras.unlockItem(item, function () { openSeries(item); });
    state.token++; abortRequests(); clearTimeout(tuneTimer); var token = state.token; busy(true);
    try {
      var response = state.demo ? { episodes: { '1': Array.from({ length: 8 }, function (_, i) { return { id: String(i + 1), episode_num: i + 1, title: 'Yerel örnek bölüm ' + (i + 1) + ' · 120 sn', container_extension: 'mp4' }; }) } } : await api('get_series_info', { series_id: item.id });
      if (token !== state.token) return;
      var rows = response && response.episodes;
      if (!rows || typeof rows !== 'object') throw new Error('Dizinin bölüm bilgisi bulunamadı.');
      var episodes = [];
      Object.keys(rows).sort(function (a, b) { return Number(a) - Number(b); }).forEach(function (season) {
        if (!Array.isArray(rows[season])) return;
        rows[season].forEach(function (episode) {
          if (!episode || !/^\d+$/.test(String(episode.id))) return;
          episodes.push({ id: String(episode.id), kind: 'episode', name: 'S' + season + ' · B' + (episode.episode_num || episodes.length + 1) + ' — ' + short(episode.title || item.name, 160),
            image: imageURL(episode.info && episode.info.movie_image) || item.image, category: item.category, categories: item.categories,
            extension: /^[a-z0-9]{2,5}$/i.test(episode.container_extension || '') ? episode.container_extension : 'mp4',
            description: short(episode.info && episode.info.plot || item.description, 800), rating: '' });
        });
      });
      if (!episodes.length) throw new Error('Bu dizide oynatılabilir bölüm bulunamadı.');
      state.episodes = { items: state.items, filtered: state.filtered, query: $('search-input').value, selected: state.selected, title: item.name };
      state.items = episodes; state.filtered = episodes; state.searchToken++; $('search-input').value = '';
      streams.set(episodes); busy(false); updateCount(); streams.focus(0);
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); message(error.message); } }
  }
  function streamURL(item, liveFormat) {
    var c = state.credentials, segment = item.kind === 'live' ? 'live' : item.kind === 'vod' ? 'movie' : 'series';
    return c.server + '/' + segment + '/' + encodeURIComponent(c.username) + '/' + encodeURIComponent(c.password) + '/' + item.id + '.' + (item.kind === 'live' ? liveFormat || state.format : item.extension);
  }
  function timeLabel(seconds) {
    var total = Math.max(0, Math.floor(Number(seconds) || 0));
    return [Math.floor(total / 3600), Math.floor(total / 60) % 60, total % 60].map(function (n) { return String(n).padStart(2, '0'); }).join(':');
  }
  function updateSeekControls() {
    var enabled = state.fullscreen && state.playing && state.playing.kind !== 'live';
    $('seek-controls').hidden = !enabled;
    if (!enabled) return;
    var info = player.getPlaybackInfo(), position = state.seekTarget == null ? info.currentTime : state.seekTarget;
    var percentage = info.duration > 0 ? Math.max(0, Math.min(100, position / info.duration * 100)) : 0;
    text('seek-position', timeLabel(position)); text('seek-duration', timeLabel(info.duration));
    text('seek-help', !info.canSeek ? 'Bu içerikte zaman bilgisi / sarma desteği bekleniyor.' :
      state.seekTarget == null ? '← / → Konum seç  ·  OK Duraklat  ·  ↓ Zamana git' : '← / → Konum seç  ·  OK Buraya atla  ·  Geri Vazgeç');
    $('seek-controls').classList.toggle('is-seeking', state.seekTarget != null);
    $('seek-track').setAttribute('aria-valuemax', String(Math.floor(info.duration)));
    $('seek-track').setAttribute('aria-valuenow', String(Math.floor(position)));
    $('seek-track').setAttribute('aria-valuetext', timeLabel(position) + ' / ' + timeLabel(info.duration));
    $('seek-track').setAttribute('aria-disabled', String(!info.canSeek));
    $('seek-time-button').disabled = !info.canSeek;
    var width = percentage.toFixed(2) + '%';
    if ($('seek-fill').style.width !== width) { $('seek-fill').style.width = width; $('seek-thumb').style.left = width; }
  }
  function scheduleTransport() {
    clearTimeout(transportTimer);
    if (!state.fullscreen || !state.playing || state.playing.kind === 'live' || document.hidden || $('player-overlay').hidden) return;
    updateSeekControls();
    if (!player.playing) return;
    transportTimer = setTimeout(scheduleTransport, 500);
  }
  function previewSeek(direction, repeated) {
    var info = player.getPlaybackInfo();
    if (!info.canSeek) { message('Bu içerikte sarma henüz kullanılamıyor.'); return; }
    state.seekRepeats = repeated ? state.seekRepeats + 1 : 0;
    var base = extras ? extras.seekStep() : 10;
    var step = state.seekRepeats > 14 ? Math.max(120, base * 4) : state.seekRepeats > 5 ? Math.max(60, base * 2) : base;
    var origin = state.seekTarget == null ? info.currentTime : state.seekTarget;
    state.seekTarget = Math.max(0, Math.min(Math.max(0, info.duration - 1), origin + direction * step));
    showOverlay(); focusElement($('seek-track'));
  }
  function commitSeek() {
    if (state.seekTarget == null) return;
    if (!player.seekTo(state.seekTarget)) { message('Sarma tamamlanana kadar kısa süre bekleyin veya başka bir konum seçin.'); return; }
    state.seekTarget = null; state.seekRepeats = 0; showOverlay();
  }
  function openSeekDialog() {
    var info = player.getPlaybackInfo();
    if (!info.canSeek) return message('Bu içerikte sarma desteklenmiyor veya süre henüz alınamadı.');
    ask('Zamana git', 'Saat:dakika:saniye yazın. Örnek: 01:20:00 veya 012000. Toplam: ' + timeLabel(info.duration), null);
    state.dialogType = 'seek'; $('seek-time-field').hidden = false;
    $('seek-time-input').value = timeLabel(state.seekTarget == null ? info.currentTime : state.seekTarget);
    text('seek-time-error', ''); focusElement($('seek-time-input'));
  }
  function parseSeekTime(value) {
    var copy = String(value).trim(), match = /^(\d{1,2}):([0-5]\d):([0-5]\d)$/.exec(copy) || /^(\d{2})([0-5]\d)([0-5]\d)$/.exec(copy);
    return match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) : NaN;
  }
  var player = new window.TVPlayer({
    video: $('video'), shell: $('player-shell'),
    onStatus: function (status, detail) {
      var label = detail || ({ playing: 'Oynatılıyor', stopped: 'Durduruldu', ended: 'Yayın sona erdi.' })[status] || '';
      text('playback-status', label); text('overlay-state', label);
      if (status === 'stopped' || status === 'error' || status === 'ended') {
        state.seekTarget = null; clearTimeout(transportTimer);
        document.body.classList.remove('avplay-active'); $('pause-button').disabled = true;
        $('player-placeholder').hidden = false;
      }
    },
    onError: function (detail) { $('player-placeholder').hidden = false; text('placeholder-label', detail); $('retry-button').disabled = !state.playing; showOverlay(); },
    onPlaying: function () { $('player-placeholder').hidden = true; $('pause-button').disabled = false; text('pause-button', 'Duraklat / devam'); if (extras) extras.playing(); showOverlay(); },
    onSubtitle: function (value) { text('subtitle-display', value); $('subtitle-display').hidden = !value; },
    onSourceChanged: function (source) { var extension = /\.ts(?:\?|$)/i.test(source.url) ? 'TS' : 'HLS'; text('format-button', state.demo ? 'Biçim: MP4 · Yerel örnek' : 'Biçim: ' + extension + (source.alternative ? ' · Otomatik' : '')); },
    onEngine: function (engine) {
      $('player-shell').dataset.engine = engine; document.body.classList.toggle('avplay-active', engine === 'AVPlay');
    },
    onEnded: function () { message('İçerik sona erdi.'); setFullscreen(false); }
  });
  function startPlayback(item, fullscreen) {
    if (!item) return;
    if (extras && !extras.itemAllowed(item)) return extras.unlockItem(item, function () { startPlayback(item, fullscreen); });
    if (item.kind === 'series') return openSeries(item);
    clearTimeout(tuneTimer); clearTimeout(transportTimer); state.seekTarget = null; state.seekRepeats = 0;
    state.playing = item; $('retry-button').disabled = false; $('pause-button').disabled = true;
    $('player-placeholder').hidden = false; text('placeholder-label', 'Yayın açılıyor…'); text('overlay-title', item.name);
    if (fullscreen) setFullscreen(true);
    player.play(state.demo ? { url: new URL('media/orbit-review.mp4', document.baseURI).href, packagedDemo: true, live: false, title: item.name + ' · 120 saniyelik yerel örnek' } :
      { url: streamURL(item), alternativeUrls: item.kind === 'live' ? [streamURL(item, state.format === 'ts' ? 'm3u8' : 'ts')] : [], live: item.kind === 'live', title: item.name });
    streams.render(true);
  }
  function activateSelected() {
    var item = state.filtered[state.selected]; if (!item) return;
    if (item.kind === 'series') return openSeries(item);
    if (state.playing && state.playing.id === item.id && state.playing.kind === item.kind && player.playing) setFullscreen(true);
    else startPlayback(item, true);
  }
  function showOverlay() {
    clearTimeout(overlayTimer); $('player-overlay').hidden = !state.fullscreen;
    if (!state.fullscreen) return;
    scheduleTransport();
    overlayTimer = setTimeout(function () {
      if (state.fullscreen && player.playing && !player.paused && state.seekTarget == null && $('dialog').hidden && $('feature-dialog').hidden) {
        $('player-overlay').hidden = true; clearTimeout(transportTimer);
      }
    }, 4000);
  }
  function setFullscreen(value) {
    var previous = state.fullscreen;
    state.fullscreen = value; state.seekTarget = null; clearTimeout(transportTimer); $('player-shell').classList.toggle('is-fullscreen', value);
    document.body.classList.toggle('player-fullscreen', value); $('privacy-button').hidden = value; player.setFullscreen(value);
    text('overlay-hint', state.mode === 'live' ? '↑ / ↓ Kanal  ·  0–9 Numara  ·  → Oynatıcı ayarları  ·  ← Yayın akışı' : '← / → Konum seç  ·  OK Atla / duraklat  ·  ↓ Kontroller  ·  Geri Küçült');
    updateSeekControls();
    showOverlay();
    if (previous && !value && state.screen === 'browser' && state.selected >= 0) streams.focus(state.selected);
  }
  function changeChannel(delta) {
    if (state.mode !== 'live' || !state.filtered.length) return;
    var next = (state.selected + delta + state.filtered.length) % state.filtered.length;
    selectItem(next, false); text('overlay-title', state.filtered[next].name); showOverlay();
    clearTimeout(tuneTimer); tuneTimer = setTimeout(function () { startPlayback(state.filtered[state.selected], true); }, 220);
  }
  function search() {
    clearTimeout(filterTimer); clearTimeout(tuneTimer); var token = ++state.searchToken;
    filterTimer = setTimeout(function () {
      var query = $('search-input').value.trim().toLocaleLowerCase('tr-TR'), source = state.items, result = [], i = 0;
      function chunk() {
        if (token !== state.searchToken || state.screen !== 'browser') return;
        var end = Math.min(i + 400, source.length);
        for (; i < end; i++) if (!query || source[i].name.toLocaleLowerCase('tr-TR').indexOf(query) !== -1) result.push(source[i]);
        if (i < source.length) return setTimeout(chunk, 0);
        player.stop(); state.playing = null;
        state.filtered = result; state.selected = -1; streams.set(result); updateCount();
        if (result.length) selectItem(0, false); else resetDetails();
      }
      chunk();
    }, 180);
  }

  function startEdit(input) {
    state.editing = input; input.readOnly = false; input.classList.add('is-editing');
    input.blur(); input.focus();
  }
  function endEdit(next) {
    var input = state.editing; if (!input) return;
    state.editing = null; input.readOnly = true; input.classList.remove('is-editing'); input.blur(); focusElement(input);
    if (input.id === 'seek-time-input') { if (next) focusElement($('dialog-confirm')); return; }
    if (input.id === 'pin-input') { if (next) focusElement($('dialog-confirm')); return; }
    if (input.id === 'searchall-input') { if (next && extras) extras.runSearch(); return; }
    if (next && input.id !== 'search-input') {
      var ids = ['server-url', 'username', 'password', 'login-button']; focusElement($(ids[ids.indexOf(input.id) + 1]));
    }
  }
  function ask(title, detail, callback) {
    clearTimeout(tuneTimer); state.lastFocus = document.activeElement; state.confirm = callback;
    state.dialogType = 'confirm'; $('seek-time-field').hidden = true; text('seek-time-error', '');
    $('pin-field').hidden = true; $('pin-input').value = ''; text('pin-error', '');
    text('dialog-title', title); text('dialog-message', detail); $('dialog').hidden = false; focusElement($('dialog-cancel'));
  }
  function closeDialog(confirmed) {
    if (confirmed && extras && extras.confirmDialog()) return;
    if (confirmed && state.dialogType === 'seek') {
      var target = parseSeekTime($('seek-time-input').value), info = player.getPlaybackInfo();
      if (!Number.isFinite(target) || target >= info.duration) {
        text('seek-time-error', '00:00:00 veya 000000 biçiminde, videonun süresinden kısa bir zaman girin.');
        focusElement($('seek-time-input')); return;
      }
      if (!player.seekTo(target)) { text('seek-time-error', 'Bu konuma henüz atlanamıyor; kısa süre bekleyip tekrar deneyin.'); return; }
      state.seekTarget = null;
    }
    var callback = state.confirm; state.confirm = null; $('dialog').hidden = true;
    state.dialogType = ''; $('seek-time-field').hidden = true;
    $('pin-field').hidden = true; $('pin-input').value = ''; if (extras) extras.dialogClosed();
    if (confirmed && callback) callback(); else focusElement(state.lastFocus);
    if (state.fullscreen) showOverlay();
  }
  function back() {
    if (state.editing) return endEdit(false);
    if (!$('dialog').hidden) return closeDialog(false);
    if (extras && extras.back()) return;
    if (state.fullscreen && state.seekTarget != null) { state.seekTarget = null; showOverlay(); return; }
    if (state.fullscreen) return setFullscreen(false);
    if (state.screen === 'browser' && state.episodes) {
      state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer); busy(false); player.stop(); state.playing = null;
      var context = state.episodes; state.episodes = null; state.items = context.items; state.filtered = context.filtered;
      $('search-input').value = context.query; streams.set(state.filtered); updateCount(); streams.focus(context.selected); return;
    }
    if (state.screen === 'browser') return showHome();
    ask('Uygulamadan çıkılsın mı?', 'IPTV Orbit Player kapatılacak. Giriş bilgileriniz TV’de kayıtlı kalır.', function () {
      try { var application = window.tizen.application.getCurrentApplication(); player.destroy(); application.exit(); }
      catch (error) { message('Tarayıcı önizlemesinden çıkmak için sekmeyi kapatın.'); }
    });
  }
  function action(name) {
    if (extras && extras.action(name)) return;
    if (name === 'confirm') return closeDialog(true);
    if (name === 'cancel') return closeDialog(false);
    if (name === 'home') return showHome();
    if (name === 'settings') return (extras ? extras.protect : function (callback) { callback(); })(function () { ask('Hesabı değiştir / sıfırla', 'TV’de kayıtlı sunucu, kullanıcı adı ve şifre silinecek. Yeniden giriş yapabilirsiniz.', function () {
      safeStorage('removeItem', STORE); $('password').value = ''; $('username').value = ''; $('server-url').value = ''; showLogin('Kayıtlı giriş bilgileri silindi.');
    }); });
    if (name === 'demo') { state.loginToken++; abortRequests(); state.demo = true; state.account = null; state.credentials = null; state.cache.clear(); busy(false); return showHome(); }
    if (name === 'watch') return activateSelected();
    if (name === 'seek') return commitSeek();
    if (name === 'seek-time') return openSeekDialog();
    if (name === 'retry' && state.playing) return startPlayback(state.playing, state.fullscreen);
    if (name === 'format') {
      if (state.demo) return message('Yerel örnek sabit bir MP4 dosyasıdır; canlı yayın biçimi kullanılmaz.');
      state.format = state.format === 'm3u8' ? 'ts' : 'm3u8'; text('format-button', 'Biçim: ' + state.format.toUpperCase());
      safeStorage('setItem', 'akis.format', state.format);
      if (state.playing && state.playing.kind === 'live') startPlayback(state.playing, state.fullscreen);
      return;
    }
    if (name === 'pause') { player.togglePause(); showOverlay(); }
  }
  function navigate(direction) {
    var element = document.activeElement, zone = element && element.dataset.zone, index = element && Number(element.dataset.index);
    if (!$('dialog').hidden) {
      var field = state.dialogType === 'pin' ? $('pin-input') : $('seek-time-input');
      if ((state.dialogType === 'seek' || state.dialogType === 'pin') && (element === field || direction === 'ArrowUp')) return focusElement(element === field ? $('dialog-confirm') : field);
      return focusElement(element === $('dialog-confirm') ? $('dialog-cancel') : $('dialog-confirm'));
    }
    if (extras && extras.navigate(direction)) return;
    if (zone === 'stream') {
      if (direction === 'ArrowLeft') return categories.focus(state.categoryIndex);
      if (direction === 'ArrowRight') return focusElement($('watch-button'));
      if (direction === 'ArrowUp' && index === 0) return focusElement($('search-input'));
      return streams.focus(index + (direction === 'ArrowUp' ? -1 : 1));
    }
    if (zone === 'category') {
      if (direction === 'ArrowRight') return streams.focus(Math.max(state.selected, 0));
      if (direction === 'ArrowLeft' || direction === 'ArrowUp' && index === 0) return focusElement($('home-button'));
      return categories.focus(index + (direction === 'ArrowUp' ? -1 : 1));
    }
    if (element === $('search-input') && direction === 'ArrowDown') return streams.focus(0);
    if (element === $('search-input') && direction === 'ArrowLeft') return categories.focus(state.categoryIndex);
    if (element && element.closest('.player-actions') && direction === 'ArrowLeft') return streams.focus(Math.max(state.selected, 0));
    // Geometry handles login, dashboard, header and player action buttons.
    var origin = visible(element) ? element.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
    var ox = origin.left + origin.width / 2, oy = origin.top + origin.height / 2, candidate = null, best = Infinity;
    document.querySelectorAll('[data-nav]').forEach(function (node) {
      if (node === element || !visible(node)) return;
      var rect = node.getBoundingClientRect(), dx = rect.left + rect.width / 2 - ox, dy = rect.top + rect.height / 2 - oy;
      var primary = direction === 'ArrowLeft' ? -dx : direction === 'ArrowRight' ? dx : direction === 'ArrowUp' ? -dy : dy;
      var cross = direction === 'ArrowLeft' || direction === 'ArrowRight' ? Math.abs(dy) : Math.abs(dx);
      if (primary <= 4) return;
      var score = primary + cross * 2.5;
      if (score < best) { best = score; candidate = node; }
    });
    focusElement(candidate);
  }
  document.addEventListener('focusin', function (event) {
    if (focusedNode && focusedNode !== event.target) focusedNode.classList.remove('is-focused');
    var element = event.target; if (element.hasAttribute('data-nav')) element.classList.add('is-focused');
    focusedNode = element;
    if (state.editing && state.editing !== element) { state.editing.readOnly = true; state.editing.classList.remove('is-editing'); state.editing = null; }
    if (element.dataset.zone === 'stream') selectItem(Number(element.dataset.index), true);
    else if (!state.fullscreen) clearTimeout(tuneTimer);
  });
  document.addEventListener('click', function (event) {
    var element = event.target.closest('[data-nav]'); if (!element || element.disabled) return;
    if (element.tagName === 'INPUT') return startEdit(element);
    if (element.id === 'seek-track' && event.detail > 0) {
      var info = player.getPlaybackInfo(), rect = element.getBoundingClientRect();
      if (info.canSeek && rect.width) { state.seekTarget = Math.max(0, Math.min(info.duration - 1, (event.clientX - rect.left) / rect.width * info.duration)); commitSeek(); }
      return;
    }
    if (element.dataset.zone === 'category') return loadCategory(Number(element.dataset.index));
    if (element.dataset.zone === 'stream') { selectItem(Number(element.dataset.index), false); return activateSelected(); }
    if (element.dataset.mode) return loadMode(element.dataset.mode);
    if (element.dataset.action) action(element.dataset.action);
  });
  document.addEventListener('keydown', function (event) {
    var names = { 37: 'ArrowLeft', 38: 'ArrowUp', 39: 'ArrowRight', 40: 'ArrowDown', 13: 'Enter', 10009: 'Back', 27: 'Back', 65376: 'Done', 65385: 'Back' };
    var key = names[event.keyCode] || event.key || '';
    if (event.repeat && (key === 'Enter' || key === 'Done')) { event.preventDefault(); return; }
    if (state.editing) {
      if (key === 'Back' || key === 'Enter' || key === 'Done') { event.preventDefault(); endEdit(key !== 'Back'); }
      return;
    }
    if (key === 'Back' || key === 'Escape' || key === 'Backspace' && event.target.tagName !== 'INPUT') { event.preventDefault(); back(); return; }
    if (!$('dialog').hidden) {
      if (key.indexOf('Arrow') === 0) { event.preventDefault(); navigate(key); }
      else if ((key === 'Enter' || key === 'Done') && !event.repeat) {
        event.preventDefault(); var active = document.activeElement;
        if (active.tagName === 'INPUT') startEdit(active); else active.click();
      }
      return;
    }
    if (extras && extras.handleKey(key, event)) { event.preventDefault(); return; }
    var media = event.keyCode;
    if (media === 10252 || media === 415 || media === 19) {
      event.preventDefault();
      if (media === 10252 || media === 415 && player.paused || media === 19 && !player.paused) player.togglePause();
      showOverlay(); return;
    }
    if (media === 413) { event.preventDefault(); player.stop(); setFullscreen(false); return; }
    if (media === 427 || media === 428) { event.preventDefault(); if (state.fullscreen) changeChannel(media === 427 ? 1 : -1); return; }
    if (media === 412 || media === 417) { event.preventDefault(); player.seekBy(media === 412 ? -10 : 10); return; }
    if (state.fullscreen) {
      if (key.indexOf('Arrow') === 0 || key === 'Enter') {
        event.preventDefault();
        if (key === 'Enter' && document.activeElement === $('player-settings-button') && !$('player-overlay').hidden && extras) extras.openPlayerSettings();
        else if (state.mode !== 'live' && key === 'Enter' && document.activeElement === $('seek-time-button') && !$('player-overlay').hidden) openSeekDialog();
        else if (state.mode !== 'live' && key === 'Enter' && state.seekTarget != null) commitSeek();
        else if (key === 'Enter') {
          if (!player.playing && state.playing) startPlayback(state.playing, true);
          else player.togglePause();
        }
        else if (state.mode === 'live' && (key === 'ArrowUp' || key === 'ArrowDown')) changeChannel(key === 'ArrowUp' ? 1 : -1);
        else if (state.mode !== 'live' && (key === 'ArrowLeft' || key === 'ArrowRight')) previewSeek(key === 'ArrowLeft' ? -1 : 1, event.repeat);
        else if (state.mode !== 'live' && key === 'ArrowDown') { showOverlay(); focusElement(document.activeElement === $('seek-time-button') ? $('player-settings-button') : $('seek-time-button')); }
        else if (state.mode !== 'live' && key === 'ArrowUp') { showOverlay(); focusElement($('seek-track')); }
        showOverlay();
      }
      return;
    }
    if (key.indexOf('Arrow') === 0) { event.preventDefault(); navigate(key); }
    else if (key === 'Enter' || key === 'Done') {
      event.preventDefault(); if (event.repeat) return;
      var element = document.activeElement;
      if (element && element.tagName === 'INPUT') startEdit(element);
      else if (element && typeof element.click === 'function') element.click();
    }
  });
  $('login-form').addEventListener('submit', function (event) {
    event.preventDefault(); if (state.busy) return;
    login({ server: $('server-url').value, username: $('username').value.trim(), password: $('password').value }, false);
  });
  ['server-url', 'username', 'password', 'search-input', 'seek-time-input', 'pin-input', 'searchall-input'].forEach(function (id) { $(id).readOnly = true; });
  $('search-input').addEventListener('input', search);
  $('detail-image').addEventListener('error', function () { this.hidden = true; });
  window.addEventListener('resize', function () { categories.render(true); streams.render(true); player.refreshRect(); });
  window.addEventListener('offline', function () { message('Ağ bağlantısı kesildi. Bağlantıdan sonra Yeniden dene seçeneğini kullanın.'); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { clearTimeout(tuneTimer); clearTimeout(transportTimer); state.seekTarget = null; state.suspended = !!state.playing; player.stop(); if (extras) extras.suspend(); }
    else if (state.suspended) { state.suspended = false; message('Uygulama geri açıldı. Yayına dönmek için OK / Yeniden dene seçin.'); }
  });
  window.addEventListener('pagehide', function () { abortRequests(); clearTimeout(tuneTimer); clearTimeout(transportTimer); if (extras) extras.resetSession(); player.destroy(); });
  try {
    if (window.tizen && tizen.tvinputdevice) ['MediaPlayPause', 'MediaPlay', 'MediaPause', 'MediaStop', 'MediaRewind', 'MediaFastForward', 'ChannelUp', 'ChannelDown', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].forEach(function (name) {
      try { tizen.tvinputdevice.registerKey(name); } catch (error) { /* Optional keys differ by remote. Mandatory arrows/Back are automatic. */ }
    });
  } catch (error) { /* Browser preview has no Tizen API. */ }
  function updateClock() { text('clock', new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })); }
  updateClock(); setInterval(updateClock, 30000);
  clearLegacyHistory();
  extras = window.AkisExperience({ state: state, player: player, api: api, normalizeItems: normalizeItems, demoItems: demoItems,
    storage: safeStorage, message: message, text: text, focus: focusElement, showHome: showHome, showScreen: showScreen,
    setFullscreen: setFullscreen, loadMode: loadMode, loadCategory: loadCategory, selectItem: selectItem, startPlayback: startPlayback,
    ask: ask, closeDialog: closeDialog, showOverlay: showOverlay, categories: categories, streams: streams, abortRequests: abortRequests,
    cancelPreview: function () { clearTimeout(tuneTimer); } });
  state.format = safeStorage('getItem', 'akis.format') === 'ts' ? 'ts' : 'm3u8'; text('format-button', 'Biçim: ' + state.format.toUpperCase());
  showScreen('login'); focusElement($('server-url'));
  try {
    var saved = JSON.parse(safeStorage('getItem', STORE) || 'null');
    if (saved && typeof saved.server === 'string' && typeof saved.username === 'string' && typeof saved.password === 'string') {
      $('server-url').value = saved.server; $('username').value = saved.username; $('password').value = saved.password; login(saved, true);
    }
  } catch (error) { safeStorage('removeItem', STORE); }
}());

```

## config.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<widget xmlns="http://www.w3.org/ns/widgets"
        xmlns:tizen="http://tizen.org/ns/widgets"
        id="https://akis-tv.example/app"
        version="1.2.3"
        width="1920"
        height="1080"
        viewmodes="fullscreen">
    <tizen:application id="AkisTV2026.AkisTV" package="AkisTV2026" required_version="5.0"/>
    <content src="index.html"/>
    <icon src="icon.png"/>
    <name>IPTV Orbit Player</name>
    <description>IPTV Orbit Player: kumanda ile kullanılan, açık kaynak Xtream Codes uyumlu IPTV oynatıcı. İçerik sağlamaz.</description>
    <author>AKIŞ TV contributors</author>
    <license href="LICENSE">MIT</license>
    <access origin="*" subdomains="true"/>
    <tizen:profile name="tv-samsung"/>
    <feature name="http://tizen.org/feature/screen.size.normal.1080.1920"/>
    <tizen:privilege name="http://tizen.org/privilege/internet"/>
    <tizen:privilege name="http://tizen.org/privilege/tv.inputdevice"/>
    <tizen:privilege name="http://developer.samsung.com/privilege/drmplay"/>
    <tizen:setting screen-orientation="landscape"
                   context-menu="disable"
                   background-support="disable"
                   encryption="disable"
                   install-location="auto"
                   hwkey-event="enable"
                   pointing-device-support="disable"/>
    <tizen:metadata key="http://samsung.com/tv/metadata/prelaunch.support" value="false"/>
    <tizen:metadata key="http://samsung.com/tv/metadata/use.network" value="true"/>
    <tizen:content-security-policy>default-src 'self'; script-src 'self' file:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: http: https:; media-src 'self' blob: http: https:; connect-src http: https:; worker-src 'self' blob:; child-src 'self' blob:; object-src 'self'; font-src 'self'; frame-src 'none'; base-uri 'self'; form-action 'none';</tizen:content-security-policy>
</widget>

```

## features.js

```javascript
/* AKIŞ TV feature utilities — MIT. No storage, requests or viewing history. */
(function (global) {
  'use strict';

  const PIN_ITERATIONS = 100000;
  const PIN_MAX_ITERATIONS = 200000;
  const EPG_LIMIT = 300;

  function problem(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  function cryptoProvider() {
    const provider = global.crypto;
    if (!provider || typeof provider.getRandomValues !== 'function' || !provider.subtle ||
        typeof provider.subtle.importKey !== 'function' || typeof provider.subtle.deriveBits !== 'function') {
      throw problem('PIN_CRYPTO_UNAVAILABLE', 'Bu TV güvenli PIN oluşturmayı desteklemiyor. Kategori kilidi etkinleştirilmedi.');
    }
    return provider;
  }

  function validPin(pin) { return typeof pin === 'string' && /^\d{4,8}$/.test(pin); }

  function base64(bytes) {
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return global.btoa(binary);
  }

  function unbase64(value) {
    if (typeof value !== 'string' || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) {
      throw new Error('Invalid base64');
    }
    const binary = global.atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    if (base64(bytes) !== value) throw new Error('Non-canonical base64');
    return bytes;
  }

  async function derive(pin, salt, iterations) {
    const provider = cryptoProvider();
    const bytes = new Uint8Array(pin.length);
    for (let i = 0; i < pin.length; i++) bytes[i] = pin.charCodeAt(i);
    try {
      const key = await provider.subtle.importKey('raw', bytes, { name: 'PBKDF2' }, false, ['deriveBits']);
      return new Uint8Array(await provider.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
    } catch (_) {
      throw problem('PIN_CRYPTO_FAILED', 'Güvenli PIN işlemi tamamlanamadı. Kilit açılmadı.');
    } finally {
      bytes.fill(0);
    }
  }

  async function createPin(pin) {
    if (!validPin(pin)) throw problem('PIN_INVALID', 'PIN 4–8 rakamdan oluşmalı.');
    const provider = cryptoProvider();
    const salt = new Uint8Array(16);
    let hash;
    try {
      provider.getRandomValues(salt);
      hash = await derive(pin, salt, PIN_ITERATIONS);
      return { v: 1, algorithm: 'PBKDF2-SHA256', iterations: PIN_ITERATIONS, salt: base64(salt), hash: base64(hash) };
    } catch (error) {
      if (error && error.code) throw error;
      throw problem('PIN_CRYPTO_FAILED', 'Güvenli PIN işlemi tamamlanamadı. PIN kaydedilmedi.');
    } finally {
      salt.fill(0);
      if (hash) hash.fill(0);
    }
  }

  function readPinRecord(record) {
    try {
      if (!record || typeof record !== 'object' || Array.isArray(record) || record.v !== 1 ||
          record.algorithm !== 'PBKDF2-SHA256' || !Number.isInteger(record.iterations) ||
          record.iterations < PIN_ITERATIONS || record.iterations > PIN_MAX_ITERATIONS ||
          typeof record.salt !== 'string' || record.salt.length !== 24 ||
          typeof record.hash !== 'string' || record.hash.length !== 44) throw new Error('Invalid record');
      const salt = unbase64(record.salt);
      const hash = unbase64(record.hash);
      if (salt.length !== 16 || hash.length !== 32) throw new Error('Invalid length');
      return { salt, hash, iterations: record.iterations };
    } catch (_) {
      throw problem('PIN_RECORD_INVALID', 'Kayıtlı PIN bilgisi geçersiz. Kategorilerin kilidi açılmadı.');
    }
  }

  async function verifyPin(pin, record) {
    const saved = readPinRecord(record);
    let actual;
    try {
      cryptoProvider();
      if (!validPin(pin)) return false;
      actual = await derive(pin, saved.salt, saved.iterations);
      let difference = 0;
      // Compare all bytes; no early return based on a matching prefix.
      for (let i = 0; i < saved.hash.length; i++) difference |= actual[i] ^ saved.hash[i];
      return difference === 0;
    } finally {
      saved.salt.fill(0);
      saved.hash.fill(0);
      if (actual) actual.fill(0);
    }
  }

  function makeCategoryKey(mode, id) {
    if (mode !== 'live' && mode !== 'vod' && mode !== 'series') {
      throw problem('CATEGORY_MODE_INVALID', 'Kategori türü geçersiz.');
    }
    if ((typeof id !== 'string' && typeof id !== 'number') || (typeof id === 'number' && !Number.isFinite(id)) || String(id).length === 0) {
      throw problem('CATEGORY_ID_INVALID', 'Kategori kimliği geçersiz.');
    }
    return JSON.stringify([mode, String(id)]);
  }

  function normalizeSearch(value) {
    let text = value == null ? '' : String(value);
    if (typeof text.normalize === 'function') text = text.normalize('NFKD');
    return text.replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/ı/g, 'i').replace(/\s+/g, ' ').trim();
  }

  function primitiveText(value, limit) {
    return typeof value === 'string' || typeof value === 'number' ? String(value).slice(0, limit) : '';
  }

  function decodeEPGText(value, limit) {
    const original = primitiveText(value, 32768);
    const encoded = original.replace(/\s+/g, '');
    if (!encoded || encoded.length % 4 === 1 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) return original.slice(0, limit);
    try {
      const padded = encoded + '='.repeat((4 - encoded.length % 4) % 4);
      const bytes = unbase64(padded);
      let decoded;
      if (typeof global.TextDecoder === 'function') decoded = new global.TextDecoder('utf-8', { fatal: true }).decode(bytes);
      else {
        let escaped = '';
        for (let i = 0; i < bytes.length; i++) escaped += '%' + ('0' + bytes[i].toString(16)).slice(-2);
        decoded = decodeURIComponent(escaped);
      }
      if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(decoded)) return original.slice(0, limit);
      return decoded.slice(0, limit);
    } catch (_) {
      return original.slice(0, limit);
    }
  }

  function unixTime(value) {
    if (typeof value !== 'number' && (typeof value !== 'string' || !/^\d+(?:\.\d{1,3})?$/.test(value.trim()))) return null;
    const number = Number(value);
    const milliseconds = number < 100000000000 ? number * 1000 : number;
    return Number.isFinite(milliseconds) && milliseconds > 0 && milliseconds <= 8640000000000000 ? Math.round(milliseconds) : null;
  }

  function offsetTime(value) {
    if (typeof value !== 'string') return null;
    const input = value.trim();
    const match = input.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d{1,3})?)?(Z|[+-]\d{2}:?\d{2})$/i);
    if (!match) return null;
    const year = Number(match[1]), month = Number(match[2]), day = Number(match[3]);
    const days = new Date(Date.UTC(year, month, 0)).getUTCDate();
    if (month < 1 || month > 12 || day < 1 || day > days || Number(match[4]) > 23 || Number(match[5]) > 59 || Number(match[6] || 0) > 59) return null;
    const milliseconds = Date.parse(input.replace(' ', 'T'));
    return Number.isFinite(milliseconds) ? milliseconds : null;
  }

  function firstTime(values, parse) {
    for (let i = 0; i < values.length; i++) {
      const result = parse(values[i]);
      if (result !== null) return result;
    }
    return null;
  }

  function firstText(values, limit) {
    for (let i = 0; i < values.length; i++) {
      const text = primitiveText(values[i], limit).trim();
      if (text) return text;
    }
    return '';
  }

  function normalizeEPG(rows) {
    if (!Array.isArray(rows)) return [];
    const result = [], seen = Object.create(null);
    const count = Math.min(rows.length, EPG_LIMIT);
    for (let i = 0; i < count; i++) {
      const row = rows[i];
      if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
      const title = decodeEPGText(row.title || row.name, 512).trim();
      const description = decodeEPGText(row.description, 4000).trim();
      const startText = firstText([row.start, row.start_datetime, row.start_time], 80);
      const endText = firstText([row.end, row.stop, row.end_datetime, row.end_time], 80);
      const unixStart = firstTime([row.start_timestamp, row.start_ts, row.start], unixTime);
      const unixEnd = firstTime([row.end_timestamp, row.stop_timestamp, row.end_ts, row.end, row.stop], unixTime);
      let startMs = unixStart === null ? firstTime([row.start, row.start_datetime, row.start_time], offsetTime) : unixStart;
      let endMs = unixEnd === null ? firstTime([row.end, row.stop, row.end_datetime, row.end_time], offsetTime) : unixEnd;
      if (startMs !== null && endMs !== null && endMs <= startMs) endMs = null;
      if (!title && !description && !startText && !endText && startMs === null && endMs === null) continue;
      const sourceId = firstText([row.id, row.epg_id], 200);
      const key = JSON.stringify([sourceId, title, startMs, endMs, startText, endText]);
      if (seen[key]) continue;
      seen[key] = true;
      result.push({
        id: sourceId || key, title: title || 'Program', description, startMs, endMs, startText, endText,
        timeSource: unixStart !== null || unixEnd !== null ? 'unix' : startMs !== null || endMs !== null ? 'offset' : startText || endText ? 'server' : 'unknown',
        order: i
      });
    }
    result.sort(function (a, b) {
      if (a.startMs === null) return b.startMs === null ? a.order - b.order : 1;
      if (b.startMs === null) return -1;
      return a.startMs - b.startMs || a.order - b.order;
    });
    return result.map(function (row) {
      delete row.order;
      return row;
    });
  }

  global.AkisFeatures = Object.freeze({ createPin, verifyPin, makeCategoryKey, normalizeSearch, normalizeEPG });
})(typeof window === 'undefined' ? globalThis : window);

```

## experience.js

```javascript
/* AKIŞ TV — MIT. Explicit settings only; no viewing or search history. */
(function (global) {
  'use strict';
  global.AkisExperience = function (ctx) {
    var F = global.AkisFeatures, state = ctx.state, player = ctx.player;
    var $ = function (id) { return document.getElementById(id); };
    var KEY = 'akis.preferences.v1', labels = { live: 'Canlı TV', vod: 'Film', series: 'Dizi' };
    var prefs = { v: 1, hidden: [], locked: [], pin: null, aspect: 'fit', seekStep: 10 };
    try {
      var stored = JSON.parse(ctx.storage('getItem', KEY) || 'null');
      if (stored && stored.v === 1) {
        ['hidden', 'locked'].forEach(function (key) { prefs[key] = Array.isArray(stored[key]) ? stored[key].filter(function (v) { return typeof v === 'string' && v.length < 240; }).slice(0, 3000) : []; });
        prefs.pin = stored.pin && typeof stored.pin === 'object' ? stored.pin : null;
        if (['fit', 'fill', 'stretch'].indexOf(stored.aspect) !== -1) prefs.aspect = stored.aspect;
        if ([10, 30, 60].indexOf(stored.seekStep) !== -1) prefs.seekStep = stored.seekStep;
      }
    } catch (_) { /* Corrupt nonsecurity preferences use defaults. */ }
    var grants = new Set(), catalogCategories = {}, catalogScope = '', feature = null, featureFocus = null;
    var epgItem = null, epgRows = [], epgTimer, epgJob = 0, epgLoadedAt = 0;
    var searchJob = 0, results = [], resultPage = 0, digitBuffer = '', digitTimer, digitContext;
    var pinPrompt = null, pinToken = 0, pinBusy = false, failures = 0, lockedUntil = 0;

    function persist() { ctx.storage('setItem', KEY, JSON.stringify(prefs)); }
    function modeOf(item) { return item.kind === 'episode' ? 'series' : item.kind; }
    function scope() {
      // A compact account scope, never a password or a watched-title identifier.
      var value = state.credentials ? state.credentials.server + '\n' + state.credentials.username : 'demo';
      var hash = 2166136261;
      for (var i = 0; i < value.length; i++) { hash ^= value.charCodeAt(i); hash = Math.imul(hash, 16777619); }
      return (hash >>> 0).toString(16) + ':';
    }
    function categoryKey(mode, id) { return scope() + (id === '' ? JSON.stringify([mode, '']) : F.makeCategoryKey(mode, id)); }
    function hidden(mode, id) { return prefs.hidden.indexOf(categoryKey(mode, id)) !== -1; }
    function locked(mode, id) { return prefs.locked.indexOf(categoryKey(mode, id)) !== -1; }
    function categoryAllowed(mode, id) { return !hidden(mode, id) && (!locked(mode, id) || grants.has(categoryKey(mode, id))); }
    function itemCategories(item) {
      var values = (item.categories || []).slice();
      if (item.category != null && item.category !== '' && values.indexOf(item.category) === -1) values.push(item.category);
      if (!values.length) values.push('');
      return values;
    }
    function itemAllowed(item) { return itemCategories(item).every(function (id) { return categoryAllowed(modeOf(item), id); }); }
    function visibleCategories(mode, rows) {
      return rows.filter(function (row) { return !hidden(mode, row.id); }).map(function (row) { return Object.assign({}, row, { locked: locked(mode, row.id) }); });
    }
    function rememberCategories(mode, rows) {
      if (catalogScope !== scope()) { catalogCategories = {}; catalogScope = scope(); }
      catalogCategories[mode] = rows.map(function (row) { return { id: row.id, name: row.name }; });
    }
    function toggle(list, key) { var index = list.indexOf(key); if (index < 0) list.push(key); else list.splice(index, 1); }

    function node(tag, className, text) {
      var element = document.createElement(tag);
      if (className) element.className = className;
      if (text != null) element.textContent = String(text);
      return element;
    }
    function button(title, operation, value, disabled) {
      var element = node('button', 'button button-secondary feature-row', title);
      element.type = 'button'; element.dataset.nav = ''; element.dataset.featureOp = operation;
      if (value != null) element.dataset.value = String(value);
      element.disabled = !!disabled; return element;
    }
    function section(title) { $('feature-content').appendChild(node('h3', 'feature-section', title)); }
    function note(title) { $('feature-content').appendChild(node('p', 'feature-caption', title)); }
    function openFeature(type, title, description) {
      clearDigits(); ctx.cancelPreview();
      if ($('feature-dialog').hidden) featureFocus = document.activeElement;
      feature = { type: type }; $('feature-content').textContent = '';
      ctx.text('feature-title', title); ctx.text('feature-description', description || ''); $('feature-dialog').hidden = false;
      ctx.showOverlay();
    }
    function focusFirst() { ctx.focus($('feature-content').querySelector('[data-nav]:not(:disabled)') || $('feature-back')); }
    function closeFeature() {
      $('feature-dialog').hidden = true; $('feature-content').textContent = ''; feature = null;
      ctx.focus(featureFocus); if (state.fullscreen) ctx.showOverlay();
    }

    function openPrivacy() {
      openFeature('privacy', 'Bilgi ve gizlilik', 'Yukarı / Aşağı ile tüm bölümleri okuyun. Geri ile önceki ekrana dönün.');
      var sections = [
        ['Uygulama ve hesapsız yerel örnek', 'IPTV Orbit Player bağımsız, ücretsiz ve açık kaynaklı bir oynatıcıdır; TV yayını, kanal hesabı veya abonelik sağlamaz. Hesapsız deneme, paketteki özgün 120 saniyelik MIT videoyu hesap ve internet olmadan oynatır. Canlı, Film ve Bölüm demo satırları aynı sonlu dosyayı açar.'],
        ['Hangi bilgiler, hangi amaçla kullanılır?', 'Kendi seçtiğiniz sağlayıcının sunucu adresi, kullanıcı adı ve şifresini girersiniz. Bağlan düğmesi bu bilgileri hesabınıza giriş, katalog alma ve yetkili yayın erişimi için kullanır. Geçerli giriş otomatik bağlanma için yalnız bu TV uygulamasının yerel alanına kaydedilir.'],
        ['Doğrudan sağlayıcı bağlantısı', 'Hesap bilgileri seçtiğiniz sağlayıcıya giriş ve yayın erişimi için gönderilir. Yayınlar ve görseller, sağlayıcının belirttiği sunuculardan veya yönlendirdiği medya/görsel sunucularından alınır. Uygulama yayıncıya bir analiz hesabı veya izleme kaydı göndermez. Mümkünse sağlayıcınızın HTTPS adresini kullanın.'],
        ['Düz metin saklama ve silme', 'Giriş bilgileri TV’de düz metin tutulur; şifreli kasa değildir. Hesabı sıfırlayana veya uygulama verileri silinene kadar saklanır. Silmek için Geri ile çıkın, üstte Hesap → Hesabı değiştir / sıfırla → Onayla yolunu izleyin. Bu işlem sağlayıcıdaki hesabınızı silmez. Uygulamayı kaldırma ve yedekten geri yükleme davranışı TV sistemine bağlıdır.'],
        ['Yerel tercihler ve PIN', 'Seçtiğiniz yayın biçimi, görüntü oranı, sarma adımı, gizlenen/kilitlenen kategoriler ve oluşturduğunuz PIN’in rastgele tuzlu doğrulama kaydı ayrıca yerelde saklanır. Hesabı sıfırlamak giriş bilgilerini kaldırır; bu tercihler ayrı tutulur. PIN düz metin kaydedilmez.'],
        ['Geçmiş ve analiz', 'Uygulama izleme geçmişi, arama geçmişi veya kaldığınız yeri kalıcı olarak kaydetmez; analiz/telemetri göndermez. TV işletim sistemi, ağ ve sağlayıcı kendi günlüklerini tutabilir; bunlar uygulamanın kontrolünde değildir. Sağlayıcı isteklerindeki hesap bilgileri onun erişim günlüklerinde görünebilir.'],
        ['Gizlilik politikası', 'Bu yerel bilgi ekranı internet bağlantısı gerektirmez. Ayrıntılı yayımlanmış politikayı başka bir cihazda aşağıdaki adresten okuyabilirsiniz:', 'https://muhammetaksay.github.io/iptv-orbit-player/privacy.html'],
        ['Gizlilik ve destek iletişimi', 'Yayıncı: Muhammet Kamil Aksay. Gizlilik ve destek e-postası: aksay84@gmail.com. Aşağıdaki GitHub Issues adresini de kullanabilirsiniz. Bildirimler herkese açıktır ve GitHub hesabı gerektirir; şifre, PIN, kişisel sunucu adresi veya kişisel veri eklemeyin.', 'https://github.com/muhammetaksay/iptv-orbit-player/issues']
      ];
      sections.forEach(function (row, index) {
        var entry = node('section', 'privacy-section'); entry.id = 'privacy-section-' + index; entry.tabIndex = 0; entry.dataset.nav = '';
        var heading = node('h3', '', row[0]); heading.id = 'privacy-heading-' + index;
        var copy = node('p', '', row[1]); copy.id = 'privacy-copy-' + index;
        entry.setAttribute('role', 'group'); entry.setAttribute('aria-labelledby', heading.id); entry.setAttribute('aria-describedby', copy.id);
        entry.appendChild(heading); entry.appendChild(copy);
        if (row[2]) {
          var address = node('p', 'privacy-url', row[2]); address.id = 'privacy-url-' + index;
          entry.setAttribute('aria-describedby', copy.id + ' ' + address.id); entry.appendChild(address);
        }
        $('feature-content').appendChild(entry);
      });
      focusFirst();
    }

    function promptPin(title, callback) {
      clearDigits();
      if (Date.now() < lockedUntil) return ctx.message('Çok fazla yanlış PIN. 30 saniye bekleyin.');
      ctx.ask(title, 'Kumandada OK ile alanı açın. 4–8 rakam girin, Bitti ve Onayla seçin.', null);
      state.dialogType = 'pin'; $('pin-field').hidden = false; $('pin-input').value = '';
      pinPrompt = { callback: callback, token: ++pinToken }; pinBusy = false;
      ctx.focus($('pin-input'));
    }
    function pinError(error) {
      return error && error.code === 'PIN_CRYPTO_UNAVAILABLE' ? 'Bu TV güvenli PIN işlemini desteklemiyor; kategori kilidi açılamadı.' : 'PIN doğrulanamadı. Ayar kaydını ve güvenli şifreleme desteğini kontrol edin.';
    }
    function protect(callback) {
      if (!prefs.pin) return callback();
      promptPin('PIN gerekli', async function (pin) {
        if (!await F.verifyPin(pin, prefs.pin)) {
          failures++; if (failures >= 5) { lockedUntil = Date.now() + 30000; failures = 0; }
          throw new Error('PIN yanlış.');
        }
        failures = 0; return callback;
      });
    }
    function createPin(callback) {
      var first = '';
      promptPin('Yeni PIN oluştur', async function (pin) {
        first = pin;
        return function () {
          promptPin('PIN’i tekrar girin', async function (again) {
            if (first !== again) throw new Error('PIN’ler aynı değil.');
            var record = await F.createPin(again); first = '';
            return function () { prefs.pin = record; persist(); if (callback) callback(); };
          });
        };
      });
    }
    function confirmDialog() {
      if (state.dialogType !== 'pin') return false;
      if (!pinPrompt || pinBusy) return true;
      if (Date.now() < lockedUntil) { ctx.text('pin-error', '30 saniye bekleyip tekrar deneyin.'); return true; }
      var pin = $('pin-input').value;
      if (!/^\d{4,8}$/.test(pin)) { ctx.text('pin-error', 'PIN 4–8 rakam olmalı.'); return true; }
      var prompt = pinPrompt; pinBusy = true; $('dialog-confirm').disabled = true; ctx.text('pin-error', 'Kontrol ediliyor…');
      Promise.resolve().then(function () { return prompt.callback(pin); }).then(function (next) {
        if (!pinPrompt || prompt.token !== pinToken) return;
        pinPrompt = null; pinBusy = false; $('dialog-confirm').disabled = false;
        ctx.closeDialog(false); if (typeof next === 'function') next();
      }).catch(function (error) {
        if (!pinPrompt || prompt.token !== pinToken) return;
        pinBusy = false; $('dialog-confirm').disabled = false;
        ctx.text('pin-error', error && /^(PIN yanlış\.|PIN’ler aynı değil\.)$/.test(error.message) ? error.message : pinError(error));
      });
      return true;
    }
    function dialogClosed() { ++pinToken; pinPrompt = null; pinBusy = false; $('dialog-confirm').disabled = false; }
    function unlockCategory(mode, id, callback) {
      if (hidden(mode, id)) return ctx.message('Bu kategori gizli. Kategori ayarlarından tekrar gösterebilirsiniz.');
      if (!locked(mode, id)) return callback();
      if (!prefs.pin) return ctx.message('Bu kilit için geçerli PIN kaydı gerekli. Kategori ayarlarını kontrol edin.');
      protect(function () { grants.add(categoryKey(mode, id)); callback(); });
    }
    function unlockItem(item, callback) {
      var mode = modeOf(item), ids = itemCategories(item);
      if (ids.some(function (id) { return hidden(mode, id); })) return ctx.message('Bu içerik gizlenen bir kategoride.');
      var lockedIds = ids.filter(function (id) { return !categoryAllowed(mode, id); });
      if (!lockedIds.length) return callback();
      if (!prefs.pin) return ctx.message('Bu kilit için geçerli PIN kaydı gerekli.');
      protect(function () { lockedIds.forEach(function (id) { grants.add(categoryKey(mode, id)); }); callback(); });
    }

    async function getCategories(mode) {
      if (catalogScope !== scope()) { catalogCategories = {}; catalogScope = scope(); }
      if (catalogCategories[mode]) return catalogCategories[mode];
      var rows = state.demo ? [{ category_id: 'demo', category_name: 'Yerel örnek video' }, { category_id: 'sample', category_name: 'Liste gezinme testi' }] :
        await ctx.api(mode === 'live' ? 'get_live_categories' : mode === 'vod' ? 'get_vod_categories' : 'get_series_categories');
      if (!Array.isArray(rows)) throw new Error('Kategori bilgisi alınamadı.');
      var normalized = rows.map(function (row) { return { id: String(row.category_id || '').slice(0, 60), name: String(row.category_name || 'İsimsiz kategori').slice(0, 120) }; });
      if (!normalized.length) normalized = [{ id: '', name: 'Tüm içerikler' }];
      rememberCategories(mode, normalized); return normalized;
    }
    function renderCategories(mode, page) {
      if (!feature || feature.type !== 'categories') return;
      feature.mode = mode; feature.page = Math.max(0, page || 0); $('feature-content').textContent = '';
      ['live', 'vod', 'series'].forEach(function (kind) { $('feature-content').appendChild(button((mode === kind ? '✓ ' : '') + labels[kind], 'category-mode', kind)); });
      section('Gizleme ve PIN kilidi');
      var rows = catalogCategories[mode] || [], start = feature.page * 8;
      rows.slice(start, start + 8).forEach(function (row) {
        section(row.name);
        $('feature-content').appendChild(button(hidden(mode, row.id) ? 'Tekrar göster' : 'Kategoriyi gizle', 'category-hide', row.id));
        $('feature-content').appendChild(button(locked(mode, row.id) ? 'PIN kilidini kaldır' : 'PIN ile kilitle', 'category-lock', row.id));
      });
      $('feature-content').appendChild(button('Önceki kategoriler', 'category-page', -1, start === 0));
      $('feature-content').appendChild(button('Sonraki kategoriler', 'category-page', 1, start + 8 >= rows.length));
      section('PIN yönetimi');
      $('feature-content').appendChild(button(prefs.pin ? 'PIN’i değiştir' : 'PIN oluştur', 'pin-create'));
      if (prefs.pin) $('feature-content').appendChild(button('PIN’i ve kategori kilitlerini kaldır', 'pin-remove'));
      note('Yalnız tercihler kaydedilir. Kilidi açılan kategori uygulamadan ayrılınca veya ana ekrana dönünce tekrar kilitlenir.'); focusFirst();
    }
    function openCategories() {
      protect(function () {
        openFeature('categories', 'Kategoriler ve PIN', 'Gizlenen kategoriler aramada da gösterilmez.');
        var mode = state.mode; loadCategorySettings(mode);
      });
    }
    function loadCategorySettings(mode) {
      var current = feature; if (!current || current.type !== 'categories') return;
      current.request = (current.request || 0) + 1; var request = current.request;
      getCategories(mode).then(function () {
        if (feature === current && current.request === request) renderCategories(mode, 0);
      }).catch(function () {
        if (feature === current && current.request === request) { note('Kategoriler yüklenemedi.'); focusFirst(); }
      });
    }
    function applyCategoryPreference(operation, id) {
      if (!feature || feature.type !== 'categories') return;
      var mode = feature.mode, page = feature.page;
      function apply() {
        toggle(operation === 'category-hide' ? prefs.hidden : prefs.locked, categoryKey(mode, id));
        grants.delete(categoryKey(mode, id)); persist();
        // Stop currently exposed content immediately when changing its protection.
        if (state.mode === mode && (state.categories[state.categoryIndex] && state.categories[state.categoryIndex].id === id ||
            state.playing && !itemAllowed(state.playing) || state.filtered.some(function (item) { return !itemAllowed(item); }))) {
          clearDigits(); player.stop(); state.playing = null; state.selected = -1; state.items = []; state.filtered = []; ctx.streams.set([]); clearEPG();
        }
        renderCategories(mode, page);
        // Refresh the visible category list on exit, without restarting hidden media.
        feature.refresh = true;
      }
      if (operation === 'category-lock' && !prefs.pin) createPin(apply); else apply();
    }

    function openPlayerSettings() {
      openFeature('player', 'Oynatıcı ayarları', 'Ses ve altyazı seçenekleri yayının içeriğine göre değişir.');
      renderPlayer();
    }
    function renderPlayer() {
      if (!feature || feature.type !== 'player') return;
      $('feature-content').textContent = '';
      section('Ses dili');
      var audio = player.getAudioTracks();
      if (!audio.length) note('Yayın ses parçası bilgisi göndermedi veya oynatıcı henüz hazır değil.');
      audio.forEach(function (track) { $('feature-content').appendChild(button((track.selected ? '✓ ' : '') + track.label, 'audio', track.index)); });
      section('Altyazı');
      var subtitles = player.getSubtitleTracks();
      $('feature-content').appendChild(button('Altyazıyı kapat', 'subtitle', -1));
      subtitles.forEach(function (track) { $('feature-content').appendChild(button((track.selected ? '✓ ' : '') + track.label, 'subtitle', track.index)); });
      if (!subtitles.length) note('Bu yayında seçilebilir altyazı bulunamadı.');
      section('Görüntü oranı');
      [['fit', 'Ekrana sığdır'], ['fill', 'Ekranı doldur'], ['stretch', 'Ekrana uzat']].forEach(function (option) {
        $('feature-content').appendChild(button((prefs.aspect === option[0] ? '✓ ' : '') + option[1], 'aspect', option[0]));
      });
      section('Sarma adımı');
      [10, 30, 60].forEach(function (seconds) { $('feature-content').appendChild(button((prefs.seekStep === seconds ? '✓ ' : '') + seconds + ' saniye', 'seek-step', seconds)); });
      note('Ses dili değiştirmek için bazı Samsung yayınlarını önce devam ettirmek gerekir.'); focusFirst();
    }

    function clearEPG() {
      clearTimeout(epgTimer); ++epgJob; epgItem = null; epgRows = []; epgLoadedAt = 0;
      $('epg-summary').hidden = true; $('epg-button').hidden = true;
    }
    function programmeTime(row) {
      function label(ms, value) { return ms != null ? new Date(ms).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : String(value || '').slice(-8, -3) || '—'; }
      return label(row.startMs, row.startText) + ' – ' + label(row.endMs, row.endText);
    }
    function renderEPGSummary() {
      if (!epgItem || epgItem.kind !== 'live') return;
      var now = Date.now(), index = epgRows.findIndex(function (row) { return row.startMs != null && row.endMs != null && row.startMs <= now && row.endMs > now; });
      if (index < 0) index = Math.max(0, epgRows.findIndex(function (row) { return row.endMs == null || row.endMs > now; }));
      var current = epgRows[index], next = epgRows[index + 1];
      ctx.text('epg-now-title', current ? current.title : 'Sağlayıcı program bilgisi göndermedi.');
      ctx.text('epg-now-time', current ? programmeTime(current) : '');
      ctx.text('epg-next-title', next ? next.title : 'Sıradaki program bilgisi yok.');
      ctx.text('epg-next-time', next ? programmeTime(next) : '');
    }
    async function fetchEPG(item, full) {
      var job = ++epgJob;
      try {
        var data;
        if (state.demo) {
          data = { epg_listings: [{ title: 'Yerel örnek video · 120 saniye', description: 'Aynı paket dosyasını oynatan demo liste satırı. Bu bir canlı yayın veya gerçek program akışı değildir.' }] };
        } else {
          data = await ctx.api(full ? 'get_simple_data_table' : 'get_short_epg', { stream_id: item.id, limit: full ? 100 : 6 });
        }
        if (job !== epgJob || !epgItem || epgItem.id !== item.id) return;
        epgRows = F.normalizeEPG(data && data.epg_listings || []); epgLoadedAt = Date.now(); renderEPGSummary();
      } catch (error) {
        if (job !== epgJob || error.cancelled) return;
        epgRows = []; ctx.text('epg-now-title', 'Yayın akışı alınamadı.'); ctx.text('epg-next-title', 'Sağlayıcı bu özelliği desteklemiyor olabilir.');
      }
      if (feature && feature.type === 'epg') renderProgramme(feature.page || 0);
    }
    function selectItem(item) {
      if (item.kind !== 'live') return clearEPG();
      if (epgItem && epgItem.id === item.id && Date.now() - epgLoadedAt < 60000) return;
      clearEPG(); epgItem = item; $('epg-summary').hidden = false; $('epg-button').hidden = false;
      ctx.text('epg-now-title', 'Program bilgisi yükleniyor…'); ctx.text('epg-now-time', ''); ctx.text('epg-next-title', ''); ctx.text('epg-next-time', '');
      epgTimer = setTimeout(function () { fetchEPG(item, false); }, 350);
    }
    function renderProgramme(page) {
      if (!feature || feature.type !== 'epg') return;
      feature.page = Math.max(0, page); $('feature-content').textContent = '';
      if (!epgRows.length) note('Bu kanal için yayın akışı bulunamadı.');
      epgRows.slice(feature.page * 20, feature.page * 20 + 20).forEach(function (row) {
        var entry = node('button', 'programme-row feature-row'); entry.type = 'button'; entry.dataset.nav = ''; entry.appendChild(node('p', 'programme-time', programmeTime(row)));
        entry.appendChild(node('h3', '', row.title)); if (row.description) entry.appendChild(node('p', '', row.description)); $('feature-content').appendChild(entry);
      });
      $('feature-content').appendChild(button('Önceki programlar', 'epg-page', -1, feature.page === 0));
      $('feature-content').appendChild(button('Sonraki programlar', 'epg-page', 1, (feature.page + 1) * 20 >= epgRows.length)); focusFirst();
    }
    function openProgramme() {
      if (!epgItem) return ctx.message('Önce canlı kanal seçin.');
      var item = epgItem; clearTimeout(epgTimer); openFeature('epg', 'Yayın akışı', item.name); feature.page = 0;
      renderProgramme(0); fetchEPG(item, true);
    }

    function renderResults() {
      var container = $('searchall-results'); container.textContent = '';
      results.slice(resultPage * 30, resultPage * 30 + 30).forEach(function (item, index) {
        var row = button(item.name, 'search-result', resultPage * 30 + index);
        row.className = 'search-result-row';
        row.appendChild(node('span', 'row-subtitle', labels[item.kind])); container.appendChild(row);
      });
      $('searchall-prev').disabled = resultPage === 0;
      $('searchall-next').disabled = (resultPage + 1) * 30 >= results.length;
    }
    function openSearch() {
      clearDigits(); ++state.token; ++state.searchToken; ++searchJob; ctx.abortRequests(); ctx.cancelPreview();
      player.stop(); state.playing = null; ctx.setFullscreen(false); clearEPG(); grants.clear();
      results = []; resultPage = 0; $('searchall-input').value = ''; renderResults();
      ctx.text('searchall-status', 'Kanal, film veya dizi adı yazın. Bitti ile aramayı başlatın.'); ctx.showScreen('search'); ctx.focus($('searchall-input'));
    }
    async function runSearch() {
      var query = F.normalizeSearch($('searchall-input').value.trim());
      if (query.length < 2) { ctx.text('searchall-status', 'En az 2 karakter yazın.'); return; }
      var job = ++searchJob, token = ++state.token; ctx.abortRequests(); results = []; resultPage = 0; renderResults();
      var errors = [], limited = false, seen = new Set();
      for (var mode of ['live', 'vod', 'series']) {
        if (job !== searchJob || state.screen !== 'search') return;
        ctx.text('searchall-status', labels[mode] + ' aranıyor… ' + results.length + ' sonuç');
        try {
          var categories = await getCategories(mode), restrictions = categories.some(function (row) { return !categoryAllowed(mode, row.id); });
          var batches = restrictions ? categories.filter(function (row) { return categoryAllowed(mode, row.id); }) : [null], modeMatches = 0;
          for (var category of batches) {
            if (job !== searchJob || state.screen !== 'search') return;
            var rows = state.demo ? ctx.demoItems(mode).map(function (item) { return Object.assign({}, item, { stream_id: item.id, series_id: item.id, category_id: category ? category.id : 'demo', container_extension: item.extension }); }) :
              await ctx.api(mode === 'live' ? 'get_live_streams' : mode === 'vod' ? 'get_vod_streams' : 'get_series', category && category.id ? { category_id: category.id } : {});
            var items = await ctx.normalizeItems(rows, mode, token);
            if (job !== searchJob || state.screen !== 'search') return;
            for (var item of items) {
              if (!item.category && category) item.category = category.id;
              if (!itemAllowed(item) || F.normalizeSearch(item.name).indexOf(query) === -1) continue;
              var resultKey = JSON.stringify([item.kind, item.id]); if (seen.has(resultKey)) continue;
              if (modeMatches++ < 100) { results.push(item); seen.add(resultKey); } else limited = true;
            }
            renderResults();
          }
        } catch (error) { if (job !== searchJob || error.cancelled) return; errors.push(labels[mode]); }
      }
      if (job !== searchJob) return;
      ctx.text('searchall-status', results.length + ' sonuç' + (limited ? ' · Her türün ilk 100 sonucu; aramayı daraltabilirsiniz.' : '') + (errors.length ? ' · Alınamayan katalog: ' + errors.join(', ') : ''));
      if (document.activeElement === $('searchall-input')) ctx.focus($('searchall-results').querySelector('button') || $('searchall-input'));
    }
    async function openResult(index) {
      var item = results[index]; if (!item) return;
      if (!itemAllowed(item)) return unlockItem(item, function () { openResult(index); });
      var job = ++searchJob, loadedToken = await ctx.loadMode(item.kind, item.category);
      if (job !== searchJob || loadedToken !== state.token || state.screen !== 'browser' || state.mode !== item.kind) return;
      var selected = state.filtered.findIndex(function (row) { return row.id === item.id && row.kind === item.kind; });
      if (selected < 0) return ctx.message('Bu sonuç kategori listesinde bulunamadı; sağlayıcı verisi değişmiş olabilir.');
      ctx.selectItem(selected, false); ctx.streams.focus(selected); ctx.startPlayback(state.filtered[selected], true);
    }

    function clearDigits() { digitBuffer = ''; digitContext = null; clearTimeout(digitTimer); $('digit-channel-overlay').hidden = true; }
    function commitDigits() {
      var index = Number(digitBuffer) - 1, current = digitContext; clearDigits();
      if (!current || current.token !== state.token || current.items !== state.filtered || state.screen !== 'browser' || state.mode !== 'live' || !$('feature-dialog').hidden || !$('dialog').hidden) return;
      if (index < 0 || index >= state.filtered.length) return ctx.message('Bu listede o numarada kanal yok.');
      ctx.selectItem(index, false); ctx.startPlayback(state.filtered[index], true);
    }
    function handleKey(key, event) {
      if (!$('feature-dialog').hidden) {
        if (key.indexOf('Arrow') === 0) { navigate(key); return true; }
        if (key === 'Enter') { document.activeElement.click(); return true; }
        return /^\d$/.test(key) || event.keyCode >= 48 && event.keyCode <= 57;
      }
      var digit = /^\d$/.test(key) ? key : event.keyCode >= 48 && event.keyCode <= 57 ? String(event.keyCode - 48) : event.keyCode >= 96 && event.keyCode <= 105 ? String(event.keyCode - 96) : '';
      if (state.screen === 'browser' && state.mode === 'live' && digit !== '') {
        if (digitContext && (digitContext.token !== state.token || digitContext.items !== state.filtered)) clearDigits();
        digitContext = { token: state.token, items: state.filtered };
        if (digitBuffer.length >= 5) { clearDigits(); digitContext = { token: state.token, items: state.filtered }; } digitBuffer += digit; clearTimeout(digitTimer);
        $('digit-channel-overlay').hidden = false; ctx.text('digit-channel-number', digitBuffer);
        var item = state.filtered[Number(digitBuffer) - 1]; ctx.text('digit-channel-label', item ? item.name + ' · OK ile aç' : 'Bu listede kanal yok');
        digitTimer = setTimeout(commitDigits, 1600); return true;
      }
      if (digitBuffer && key === 'Enter') { commitDigits(); return true; }
      if (digitBuffer && key.indexOf('Arrow') === 0) clearDigits();
      if (state.fullscreen && state.mode === 'live' && key === 'ArrowRight') { openPlayerSettings(); return true; }
      if (state.fullscreen && state.mode === 'live' && key === 'ArrowLeft') { openProgramme(); return true; }
      return false;
    }
    function navigate(direction) {
      if (!$('feature-dialog').hidden) {
        var nodes = Array.from($('feature-dialog').querySelectorAll('[data-nav]:not(:disabled)')).filter(function (element) { return !element.closest('[hidden]'); });
        var index = nodes.indexOf(document.activeElement), delta = direction === 'ArrowUp' || direction === 'ArrowLeft' ? -1 : 1;
        ctx.focus(nodes[(Math.max(0, index) + delta + nodes.length) % nodes.length]); return true;
      }
      if (state.screen === 'search') {
        var entries = [$('searchall-input')].concat(Array.from($('searchall-results').querySelectorAll('button')), [$('searchall-prev'), $('searchall-next'), $('home-button'), $('privacy-button')]).filter(function (element) { return !element.disabled; });
        var current = entries.indexOf(document.activeElement), move = direction === 'ArrowUp' || direction === 'ArrowLeft' ? -1 : 1;
        ctx.focus(entries[(Math.max(0, current) + move + entries.length) % entries.length]); return true;
      }
      return false;
    }
    function back() {
      if (!$('feature-dialog').hidden) {
        var refresh = feature && feature.refresh; closeFeature(); if (refresh && state.screen === 'browser') ctx.loadMode(state.mode); return true;
      }
      if (digitBuffer) { clearDigits(); return true; }
      if (state.screen === 'search') { ctx.showHome(); return true; }
      return false;
    }
    function action(name) {
      if (name === 'privacy') openPrivacy();
      else if (name === 'global-search') openSearch();
      else if (name === 'programme') openProgramme();
      else if (name === 'player-settings') openPlayerSettings();
      else if (name === 'category-settings') openCategories();
      else if (name === 'feature-back') back();
      else if (name === 'search-prev' || name === 'search-next') { resultPage += name === 'search-next' ? 1 : -1; renderResults(); ctx.focus($('searchall-results').querySelector('button')); }
      else return false;
      return true;
    }
    document.addEventListener('click', function (event) {
      var control = event.target.closest('[data-feature-op]'); if (!control || control.disabled) return;
      var op = control.dataset.featureOp, value = control.dataset.value;
      if (op === 'search-result') return openResult(Number(value));
      if (!feature) return;
      if (op === 'category-mode') loadCategorySettings(value);
      else if (op === 'category-page') renderCategories(feature.mode, feature.page + Number(value));
      else if (op === 'category-hide' || op === 'category-lock') applyCategoryPreference(op, value);
      else if (op === 'pin-create') protect(function () { createPin(function () { renderCategories(feature.mode, feature.page); }); });
      else if (op === 'pin-remove') protect(function () { prefs.pin = null; prefs.locked = []; grants.clear(); persist(); renderCategories(feature.mode, feature.page); });
      else if (op === 'audio' || op === 'subtitle') {
        var success = op === 'audio' ? player.selectAudioTrack(Number(value)) : player.selectSubtitleTrack(Number(value));
        if (!success) ctx.message('Bu seçenek şu an değiştirilemiyor; yayını devam ettirip tekrar deneyin.'); renderPlayer();
      } else if (op === 'aspect') { if (player.setAspectRatio(value)) { prefs.aspect = value; persist(); } else ctx.message('Görüntü oranı şu an değiştirilemiyor.'); renderPlayer(); }
      else if (op === 'seek-step') { prefs.seekStep = Number(value); persist(); renderPlayer(); }
      else if (op === 'epg-page') renderProgramme(feature.page + Number(value));
    });
    function resetSession() {
      ++searchJob; grants.clear(); results = []; resultPage = 0; clearDigits(); clearEPG();
      if (state.dialogType === 'pin') ctx.closeDialog(false);
      $('searchall-input').value = ''; $('searchall-results').textContent = '';
      $('feature-dialog').hidden = true; $('feature-content').textContent = ''; feature = null;
    }
    function suspend() {
      var restricted = state.screen === 'browser' && (state.categories[state.categoryIndex] && locked(state.mode, state.categories[state.categoryIndex].id) ||
        state.filtered.some(function (item) { return itemCategories(item).some(function (id) { return locked(modeOf(item), id); }); }));
      resetSession(); if (restricted) ctx.showHome();
    }
    return { action: action, back: back, handleKey: handleKey, navigate: navigate, protect: protect,
      categoryAllowed: categoryAllowed, itemAllowed: itemAllowed, unlockCategory: unlockCategory, unlockItem: unlockItem,
      rememberCategories: rememberCategories, visibleCategories: visibleCategories, clearEPG: clearEPG, selectItem: selectItem,
      confirmDialog: confirmDialog, dialogClosed: dialogClosed, resetSession: resetSession, suspend: suspend,
      runSearch: runSearch, clearDigits: clearDigits, openPlayerSettings: openPlayerSettings, seekStep: function () { return prefs.seekStep; },
      playing: function () { player.setAspectRatio(prefs.aspect); } };
  };
})(window);

```

## media/LICENSE

```text
MIT License

Copyright (c) 2026 IPTV Orbit Player contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

```
