/* AKIŞ playback engine: one decoder and one active playback generation at a time. */
(function (global) {
  'use strict';

  class TVPlayer {
    constructor(options) {
      this.options = options || {};
      this.video = this.options.video;
      this.shell = this.options.shell;
      this.avObject = document.getElementById('av-player');
      this.av = global.webapis && global.webapis.avplay;
      this.engine = '';
      this.live = false;
      this.paused = false;
      this.playing = false;
      this.fullscreen = false;
      this._generation = 0;
      this._avOwner = 0;
      this._hls = null;
      this._listeners = [];
      this._timers = new Set();
      this._request = null;
      this._attempt = null;
      this._failed = false;
      this._lastPosition = -1;
      this._lastProgress = 0;
      this._seekBusy = false;
      this._seekToken = 0;
      this._playbackInfo = null;
      this._rectPending = false;
      this.aspectRatio = 'fit';
      this._subtitleIndex = -1;
      this._subtitleTimer = null;
      this._trackCleanup = [];
      this._destroyed = false;
      if (!this.video || !this.shell) throw new Error('Video ve oynatıcı alanı gerekli.');
      this.video.controls = false;
      this.video.setAttribute('playsinline', '');
      this.video.preload = 'metadata';
    }

    _emit(name, ...args) {
      const handler = this.options[name];
      if (typeof handler === 'function') {
        try { handler(...args); } catch (_) { /* UI callbacks must not break decoder cleanup. */ }
      }
    }

    _status(status, message) { this._emit('onStatus', status, message || ''); }
    _valid(id) { return !this._destroyed && id === this._generation && !this._failed; }

    _after(fn, delay) {
      const timer = global.setTimeout(() => {
        this._timers.delete(timer);
        fn();
      }, delay);
      this._timers.add(timer);
      return timer;
    }

    _listen(event, handler) {
      this.video.addEventListener(event, handler);
      this._listeners.push([event, handler]);
    }

    _avState() {
      try { return this.av ? this.av.getState() : 'NONE'; } catch (_) { return 'NONE'; }
    }

    _closeAV() {
      if (!this.av || !this._avOwner) return;
      this._avOwner = 0;
      try {
        if (['READY', 'PLAYING', 'PAUSED'].indexOf(this._avState()) !== -1) this.av.stop();
      } catch (_) { /* close() still releases an interrupted preparation. */ }
      try { this.av.close(); } catch (_) { /* Already closed, including canceled prepareAsync. */ }
    }

    _dispose() {
      this._trackCleanup.forEach(function (cleanup) { cleanup(); }); this._trackCleanup = [];
      this._nativeBound = null;
      this._subtitleIndex = -1; this._subtitleTimer = null; this._emit('onSubtitle', '');
      this._timers.forEach(function (timer) { global.clearTimeout(timer); });
      this._timers = new Set();
      this._listeners.forEach((entry) => this.video.removeEventListener(entry[0], entry[1]));
      this._listeners = [];
      if (this._hls) {
        const previous = this._hls;
        this._hls = null;
        try { previous.destroy(); } catch (_) { /* Continue releasing the media element. */ }
      }
      try {
        this.video.pause();
        this.video.removeAttribute('src');
        this.video.load();
      } catch (_) { /* Device teardown can race with application suspension. */ }
      this._closeAV();
      this._seekBusy = false;
      ++this._seekToken;
      this._playbackInfo = null;
      this._rectPending = false;
      this.playing = false;
      this.paused = false;
    }

    _showEngine(name) {
      this.engine = name;
      const hardware = name === 'AVPlay';
      this.video.hidden = hardware;
      this.video.style.display = hardware ? 'none' : 'block';
      if (this.avObject) {
        this.avObject.hidden = !hardware;
        this.avObject.style.display = hardware ? 'block' : 'none';
      }
      this.shell.dataset.engine = name;
      this._emit('onEngine', name);
    }

    play(request) {
      if (this._destroyed) return;
      let parsed;
      try { parsed = new URL(request && request.url); } catch (_) {
        this.stop();
        this._status('error', 'Geçersiz yayın adresi.');
        this._emit('onError', 'Geçersiz yayın adresi.');
        return;
      }
      let packagedDemo = false;
      if (request && request.packagedDemo === true) {
        try { packagedDemo = parsed.protocol === 'file:' && parsed.href === new URL('media/orbit-review.mp4', document.baseURI).href; } catch (_) { /* Only the exact bundled demo file may bypass HTTP validation. */ }
      }
      if ((!/^https?:$/.test(parsed.protocol) && !packagedDemo) || parsed.username || parsed.password) {
        this.stop();
        this._status('error', 'Yayın adresi HTTP veya HTTPS olmalı.');
        this._emit('onError', 'Yayın adresi HTTP veya HTTPS olmalı.');
        return;
      }
      this._request = {
        url: parsed.href,
        live: Boolean(request.live),
        title: String(request.title || ''),
        startAt: Math.max(0, Number(request.startAt) || 0)
      };
      const sources = [parsed.href];
      if (request.live && Array.isArray(request.alternativeUrls)) request.alternativeUrls.slice(0, 2).forEach(function (value) {
        try { const u = new URL(value); if (/^https?:$/.test(u.protocol) && !u.username && !u.password && sources.indexOf(u.href) === -1) sources.push(u.href); } catch (_) { /* Ignore invalid alternatives. */ }
      });
      this.aspectRatio = 'fit';
      this._attempt = { browserOnly: false, restarts: 0, sources, avSourceIndex: 0, browserTried: new Set() };
      this._start();
    }

    _start() {
      const id = ++this._generation;
      this._dispose();
      this._failed = false;
      this.live = this._request.live;
      this._lastPosition = -1;
      this._lastProgress = Date.now();
      this._status('loading', 'Yayın açılıyor…');
      if (!this._valid(id)) return;
      this._emit('onSourceChanged', { url: this._request.url, index: this._attempt.sources.indexOf(this._request.url), alternative: this._request.url !== this._attempt.sources[0] });
      this._after(() => {
        if (this._valid(id) && !this.playing && !this.paused) {
          if (this.engine === 'AVPlay') this._fallback(id);
          else this._fail(id, 'Yayın 25 saniye içinde açılamadı. Sunucu, ağ ve yayın biçimini kontrol edin.');
        }
      }, 25000);
      if (this.av && this.avObject && !this._attempt.browserOnly) this._startAV(id);
      else {
        this._attempt.browserOnly = true; this._attempt.browserTried.add(this._request.url);
        this._startBrowser(id);
      }
    }

    _startAV(id) {
      this._showEngine('AVPlay');
      this._avOwner = id;
      try {
        this.av.open(this._request.url);
        if (!this._valid(id)) return;
        this.av.setListener({
          onbufferingstart: () => {
            if (this._valid(id)) this._status('buffering', 'Yayın arabelleğe alınıyor…');
          },
          onbufferingprogress: (percent) => {
            if (this._valid(id)) this._status('buffering', 'Arabellek %' + Math.round(Number(percent) || 0));
          },
          onbufferingcomplete: () => {
            if (this._valid(id) && this.playing && !this.paused) this._status('playing', '');
          },
          oncurrentplaytime: (milliseconds) => {
            if (this._valid(id)) {
              if (!this.paused) this._markPlaying(id);
              this._progress(Number(milliseconds) / 1000);
            }
          },
          onstreamcompleted: () => { if (this._valid(id)) this._ended(id); },
          onsubtitlechange: (duration, value) => { if (this._valid(id) && this._subtitleIndex >= 0) this._showSubtitle(value, duration, id); },
          onerror: () => { if (this._valid(id)) this._fallback(id); }
        });
        if (!this._valid(id)) return;
        this.refreshRect();
        this.setAspectRatio(this.aspectRatio);
        try { this.av.setSilentSubtitle(true); } catch (_) { /* Optional native subtitle control. */ }
        this.av.prepareAsync(() => {
          // A canceled preparation must never stop, close, or play a newer channel.
          if (!this._valid(id) || this._avOwner !== id) return;
          try {
            this.refreshRect();
            const start = this._request.startAt;
            if (!this.live && start > 0) {
              try { this.av.seekTo(Math.round(start * 1000)); } catch (_) { /* Resume is optional. */ }
            }
            this.av.play();
            this._markPlaying(id);
          } catch (_) { this._fallback(id); }
        }, () => { if (this._valid(id)) this._fallback(id); });
      } catch (_) { this._fallback(id); }
    }

    _fallback(id) {
      if (!this._valid(id)) return;
      if (!this.live && this._lastPosition > 0) this._request.startAt = this._lastPosition;
      if (this.live && this._attempt.avSourceIndex + 1 < this._attempt.sources.length) {
        this._request.url = this._attempt.sources[++this._attempt.avSourceIndex];
      } else {
        this._attempt.browserOnly = true;
        this._request.url = this._attempt.sources.find((url) => /\.m3u8$/i.test(new URL(url).pathname)) || this._request.url;
      }
      // Samsung may still own the native error callback stack here. Invalidate
      // immediately, but let that callback and decoder teardown settle before open().
      const recovery = ++this._generation, request = this._request, attempt = this._attempt;
      this._dispose();
      this._after(() => {
        if (this._valid(recovery) && this._request === request && this._attempt === attempt) this._start();
      }, 100);
    }

    _startBrowser(id) {
      const request = this._request;
      const pathname = new URL(request.url).pathname.toLowerCase();
      const hlsSource = /\.m3u8$/.test(pathname);
      const directTS = /\.ts$/.test(pathname);
      this._showEngine('HTML5');
      this.setAspectRatio(this.aspectRatio);
      this._bindNativeSubtitles(id);
      this._listen('playing', () => { if (this._valid(id)) this._markPlaying(id); });
      this._listen('timeupdate', () => {
        if (this._valid(id)) this._progress(this.video.currentTime);
      });
      this._listen('waiting', () => {
        if (this._valid(id)) this._status('buffering', 'Yayın arabelleğe alınıyor…');
      });
      this._listen('pause', () => {
        if (this._valid(id) && !this.video.ended && this.playing) {
          this.paused = true;
          this._status('paused', 'Duraklatıldı');
        }
      });
      this._listen('ended', () => { if (this._valid(id)) this._ended(id); });
      this._listen('error', () => {
        if (!this._valid(id) || this._hls) return;
        this._fail(id, 'Yayın açılamadı. Sunucu erişimini, CORS iznini ve desteklenen ses/video codec’lerini kontrol edin.');
      });
      this._listen('loadedmetadata', () => {
        if (!this._valid(id) || request.live || !request.startAt) return;
        try {
          const maximum = Number.isFinite(this.video.duration) ? Math.max(0, this.video.duration - 1) : request.startAt;
          this.video.currentTime = Math.min(request.startAt, maximum);
        } catch (_) { /* Seeking before the first seekable range is available is optional. */ }
      });
      if (hlsSource && global.Hls && global.Hls.isSupported()) {
        this._startHLS(id);
        return;
      }
      if (directTS && !this.video.canPlayType('video/mp2t')) {
        this._fail(id, 'Doğrudan .ts akışı bu tarayıcıda desteklenmiyor. Canlı yayın biçimini HLS (.m3u8) yapın veya TV’de AVPlay kullanın.');
        return;
      }
      if (hlsSource && !this.video.canPlayType('application/vnd.apple.mpegurl') && !this.video.canPlayType('application/x-mpegURL')) {
        this._fail(id, 'Bu cihazda HLS için MediaSource veya yerel HLS desteği bulunamadı.');
        return;
      }
      this.video.src = request.url;
      this.video.load();
      this._playVideo(id);
    }

    _startHLS(id) {
      this._showEngine('HLS.js');
      const Hls = global.Hls;
      let networkRecoveries = 0;
      let mediaRecoveries = 0;
      try {
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          maxBufferLength: 20,
          maxMaxBufferLength: 30,
          backBufferLength: this.live ? 10 : 20,
          maxBufferSize: 30 * 1000 * 1000,
          capLevelToPlayerSize: true,
          startLevel: -1,
          manifestLoadPolicy: { default: { maxTimeToFirstByteMs: 10000, maxLoadTimeMs: 15000, timeoutRetry: { maxNumRetry: 1, retryDelayMs: 1000, maxRetryDelayMs: 2000 }, errorRetry: { maxNumRetry: 1, retryDelayMs: 1000, maxRetryDelayMs: 2000 } } }
        });
        this._hls = hls;
        hls.subtitleDisplay = false;
        hls.on(Hls.Events.MEDIA_ATTACHED, () => { if (this._valid(id)) hls.loadSource(this._request.url); });
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (this._valid(id)) { if (this._subtitleIndex < 0) hls.subtitleTrack = -1; this._playVideo(id); }
        });
        hls.on(Hls.Events.ERROR, (_, data) => {
          if (!this._valid(id) || !data || !data.fatal) return;
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR && networkRecoveries++ < 2) {
            this._status('buffering', 'Ağ bağlantısı yeniden deneniyor…');
            this._after(() => {
              if (this._valid(id) && this._hls === hls) {
                try { hls.startLoad(); } catch (_) { this._fail(id, 'Yayın bağlantısı yeniden kurulamadı.'); }
              }
            }, 1000 * networkRecoveries);
          } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRecoveries++ < 1) {
            try { hls.recoverMediaError(); } catch (_) { this._fail(id, 'Ses veya video bu cihazda çözümlenemedi.'); }
          } else {
            this._fail(id, 'HLS yayını açılamadı. Ağ, CORS, HTTPS ve codec uyumunu kontrol edin.');
          }
        });
        hls.attachMedia(this.video);
      } catch (_) { this._fail(id, 'HLS oynatıcı başlatılamadı. Cihazın MediaSource desteğini kontrol edin.'); }
    }

    _playVideo(id) {
      if (!this._valid(id)) return;
      try {
        const started = this.video.play();
        if (started && typeof started.catch === 'function') {
          started.catch((error) => {
            if (!this._valid(id)) return;
            const denied = error && error.name === 'NotAllowedError';
            this._fail(id, denied ? 'Otomatik oynatma engellendi. Kumandada Yeniden dene veya Enter tuşuna basın.' : 'Video başlatılamadı. Yayın biçimini ve sunucu erişimini kontrol edin.');
          });
        }
      } catch (_) { this._fail(id, 'Video başlatılamadı.'); }
    }

    _markPlaying(id) {
      if (!this._valid(id)) return;
      const first = !this.playing;
      const resumed = this.paused;
      this.playing = true;
      this.paused = false;
      if (first || resumed) {
        this._lastProgress = Date.now();
        this._status('playing', '');
      }
      if (first) {
        this._emit('onPlaying');
        this._watch(id);
      }
    }

    _progress(position) {
      if (Number.isFinite(position) && Math.abs(position - this._lastPosition) > 0.05) {
        this._lastPosition = position;
        this._lastProgress = Date.now();
      }
    }

    _watch(id) {
      this._after(() => {
        if (!this._valid(id)) return;
        if (!this.paused && !document.hidden && Date.now() - this._lastProgress > 25000) {
          if (this._attempt.restarts < 1) {
            this._attempt.restarts += 1;
            if (!this.live && this._lastPosition > 0) this._request.startAt = this._lastPosition;
            this._start();
          } else {
            this._fail(id, 'Yayın ilerlemiyor. Otomatik kurtarma sınırına ulaşıldı; Yeniden dene ile tekrar açın.');
          }
          return;
        }
        if (this.paused || document.hidden) this._lastProgress = Date.now();
        this._watch(id);
      }, 5000);
    }

    _fail(id, message) {
      if (!this._valid(id)) return;
      if (this.live && this._attempt && this._attempt.browserOnly) {
        const next = this._attempt.sources.find((url) => !this._attempt.browserTried.has(url));
        if (next) { this._request.url = next; this._start(); return; }
      }
      ++this._generation;
      this._failed = true;
      this._dispose();
      this._status('error', message);
      this._emit('onError', message);
    }

    _ended(id) {
      if (!this._valid(id)) return;
      ++this._generation;
      this._dispose();
      this._status('ended', 'Yayın sona erdi.');
      this._emit('onEnded');
    }

    togglePause() {
      if (!this.playing || this._failed || this._destroyed) return false;
      if (this.engine === 'AVPlay' && this._seekBusy) return false;
      try {
        if (this.engine === 'AVPlay') {
          const state = this._avState();
          if (state === 'PLAYING') {
            this.av.pause();
            this.paused = true;
            this._status('paused', 'Duraklatıldı');
          } else if (state === 'PAUSED') {
            this.av.play();
            this.paused = false;
            this._lastProgress = Date.now();
            this._status('playing', '');
          } else return false;
        } else if (this.video.paused) {
          this.paused = false;
          this._lastProgress = Date.now();
          this._playVideo(this._generation);
        } else {
          this.video.pause();
        }
        return true;
      } catch (_) {
        this._status(this.paused ? 'paused' : 'playing', 'Bu yayın duraklatma/devam ettirme işlemini desteklemiyor.');
        return false;
      }
    }

    _plainText(value, limit) {
      return String(value == null ? '' : value).replace(/<br\s*\/?\s*>/gi, '\n').replace(/<[^>]*>/g, '')
        .replace(/&nbsp;/gi, ' ').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&amp;/gi, '&')
        .replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, '').slice(0, limit || 500);
    }

    _showSubtitle(value, duration, id) {
      if (this._subtitleTimer) { global.clearTimeout(this._subtitleTimer); this._timers.delete(this._subtitleTimer); this._subtitleTimer = null; }
      const text = this._plainText(value, 500); this._emit('onSubtitle', text);
      if (text) this._subtitleTimer = this._after(() => {
        this._subtitleTimer = null; if (this._valid(id)) this._emit('onSubtitle', '');
      }, Math.max(200, Math.min(20000, Number(duration) || 3000)));
    }

    _bindNativeSubtitles(id) {
      const list = this.video.textTracks;
      this._nativeBound = new Set();
      const sync = () => { if (this._valid(id)) this._syncNativeSubtitles(id); };
      if (list && typeof list.addEventListener === 'function') {
        list.addEventListener('addtrack', sync); list.addEventListener('change', sync);
        this._trackCleanup.push(() => { list.removeEventListener('addtrack', sync); list.removeEventListener('change', sync); });
      }
      sync();
    }

    _syncNativeSubtitles(id) {
      const list = this.video.textTracks, rows = [];
      if (!list) return;
      for (let i = 0; i < list.length; i++) if (list[i].kind === 'subtitles' || list[i].kind === 'captions') rows.push(list[i]);
      let chosen = this._subtitleIndex < 0 ? null : rows[this._subtitleIndex];
      const hlsTrack = this._hls && this._hls.subtitleTracks && this._hls.subtitleTracks[this._subtitleIndex];
      if (hlsTrack) chosen = rows.find((track) => track.language === hlsTrack.lang && (!hlsTrack.name || track.label === hlsTrack.name)) || chosen;
      rows.forEach((track) => {
        const mode = track === chosen ? 'hidden' : 'disabled';
        if (track.mode !== mode) track.mode = mode;
        if (this._nativeBound.has(track) || typeof track.addEventListener !== 'function') return;
        this._nativeBound.add(track);
        const changed = () => {
          if (!this._valid(id) || this._subtitleIndex < 0 || track.mode !== 'hidden') return;
          const cues = track.activeCues || [], text = [];
          for (let n = 0; n < cues.length; n++) text.push(cues[n].text || '');
          this._showSubtitle(text.join('\n'), 10000, id);
        };
        track.addEventListener('cuechange', changed);
        this._trackCleanup.push(() => { track.removeEventListener('cuechange', changed); try { track.mode = 'disabled'; } catch (_) { /* Removed track. */ } });
      });
    }

    _getTracks(type) {
      if (!this.playing || this._destroyed || this._failed || this.engine === 'AVPlay' && this._seekBusy) return [];
      try {
        if (this.engine === 'AVPlay') {
          if (['PLAYING', 'PAUSED'].indexOf(this._avState()) === -1) return [];
          const current = this.av.getCurrentStreamInfo() || [];
          return (this.av.getTotalTrackInfo() || []).filter((track) => track.type === type).slice(0, 100).map((track) => {
            let meta = {}; try { meta = JSON.parse(track.extra_info || '{}'); } catch (_) { /* Invalid optional metadata. */ }
            const language = this._plainText(meta.language || meta.track_lang || '', 24).replace(/\s+/g, ' ');
            return { index: Number(track.index), language, label: this._plainText(meta.label || meta.name || language || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (Number(track.index) + 1), 80).replace(/\s+/g, ' '),
              selected: type === 'TEXT' ? Number(track.index) === this._subtitleIndex : current.some((row) => row.type === type && Number(row.index) === Number(track.index)) };
          }).filter((track) => Number.isInteger(track.index) && track.index >= 0);
        }
        const hlsRows = this._hls && (type === 'AUDIO' ? this._hls.audioTracks : this._hls.subtitleTracks);
        if (hlsRows && hlsRows.length) return hlsRows.slice(0, 100).map((track, index) => ({ index,
          language: this._plainText(track.lang || '', 24), label: this._plainText(track.name || track.lang || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (index + 1), 80),
          selected: type === 'AUDIO' ? this._hls.audioTrack === index : this._subtitleIndex === index }));
        const list = type === 'AUDIO' ? this.video.audioTracks : this.video.textTracks, result = [];
        if (!list) return result;
        let subtitle = 0;
        for (let n = 0; n < list.length && n < 100; n++) {
          const track = list[n];
          if (type === 'TEXT' && track.kind !== 'subtitles' && track.kind !== 'captions') continue;
          const index = type === 'AUDIO' ? n : subtitle++;
          result.push({ index, language: this._plainText(track.language || '', 24), label: this._plainText(track.label || track.language || (type === 'AUDIO' ? 'Ses' : 'Altyazı') + ' ' + (index + 1), 80),
            selected: type === 'AUDIO' ? Boolean(track.enabled) : this._subtitleIndex === index });
        }
        return result;
      } catch (_) { return []; }
    }

    getAudioTracks() { return this._getTracks('AUDIO'); }
    getSubtitleTracks() { return this._getTracks('TEXT'); }

    selectAudioTrack(value) {
      const index = Number(value);
      if (!Number.isInteger(index) || !this.getAudioTracks().some((track) => track.index === index)) return false;
      try {
        if (this.engine === 'AVPlay') {
          if (this._seekBusy || this._avState() !== 'PLAYING') return false;
          this.av.setSelectTrack('AUDIO', index);
        } else if (this._hls && this._hls.audioTracks && this._hls.audioTracks.length) this._hls.audioTrack = index;
        else {
          const tracks = this.video.audioTracks;
          for (let n = 0; n < tracks.length; n++) tracks[n].enabled = n === index;
        }
        return true;
      } catch (_) { return false; }
    }

    selectSubtitleTrack(value) {
      const index = Number(value);
      if (!this.playing || !Number.isInteger(index) || index < -1 || this.engine === 'AVPlay' && this._seekBusy) return false;
      if (index !== -1 && !this.getSubtitleTracks().some((track) => track.index === index)) return false;
      try {
        if (this.engine === 'AVPlay') {
          if (['PLAYING', 'PAUSED'].indexOf(this._avState()) === -1) return false;
          if (index !== -1) this.av.setSelectTrack('TEXT', index);
          this.av.setSilentSubtitle(true);
        } else if (this._hls) { this._hls.subtitleDisplay = false; this._hls.subtitleTrack = index; }
        this._subtitleIndex = index; this._showSubtitle('', 0, this._generation);
        if (this.engine !== 'AVPlay') this._syncNativeSubtitles(this._generation);
        return true;
      } catch (_) { return false; }
    }

    setAspectRatio(mode) {
      const modes = { fit: 'PLAYER_DISPLAY_MODE_LETTER_BOX', fill: 'PLAYER_DISPLAY_MODE_AUTO_ASPECT_RATIO', stretch: 'PLAYER_DISPLAY_MODE_FULL_SCREEN' };
      if (!Object.prototype.hasOwnProperty.call(modes, mode)) return false;
      if (this.engine === 'AVPlay' && this._seekBusy) return false;
      try {
        if (this.engine === 'AVPlay' && this._avOwner) this.av.setDisplayMethod(modes[mode]);
        this.video.style.objectFit = { fit: 'contain', fill: 'cover', stretch: 'fill' }[mode];
        this.aspectRatio = mode;
        return true;
      } catch (_) { return false; }
    }

    getPlaybackInfo() {
      const active = Boolean(this._request && this.playing && !this._failed && !this._destroyed);
      // Samsung forbids other AVPlay calls until an asynchronous seek completes.
      if (this.engine === 'AVPlay' && this._seekBusy) {
        const cached = this._playbackInfo || { currentTime: 0, duration: 0, seekable: [], canSeek: false };
        return Object.assign({}, cached, { seekable: cached.seekable.map((range) => Object.assign({}, range)),
          paused: this.paused, playing: active, live: this.live, canSeek: active && cached.canSeek, seeking: true });
      }
      let currentTime = 0, duration = 0, seekable = [];
      if (active) {
        try {
          if (this.engine === 'AVPlay') {
            currentTime = Number(this.av.getCurrentTime()) / 1000;
            duration = Number(this.av.getDuration()) / 1000;
          } else {
            currentTime = Number(this.video.currentTime);
            duration = Number(this.video.duration);
          }
        } catch (_) { /* Metadata can be temporarily unavailable during a decoder transition. */ }
      }
      duration = Number.isFinite(duration) && duration > 0 ? duration : 0;
      currentTime = Number.isFinite(currentTime) && currentTime > 0 ? currentTime : 0;
      if (duration) currentTime = Math.min(currentTime, duration);
      if (active && !this.live && duration) {
        if (this.engine === 'AVPlay') {
          if (duration >= 2 && ['READY', 'PLAYING', 'PAUSED'].indexOf(this._avState()) !== -1) seekable = [{ start: 0.001, end: duration - 1 }];
        } else {
          const maximum = Math.max(0, duration - 0.2);
          const ranges = this.video.seekable;
          if (ranges) {
            try {
              for (let i = 0; i < ranges.length; i++) {
                const start = Math.max(0, Number(ranges.start(i)));
                const end = Math.min(maximum, Number(ranges.end(i)));
                if (Number.isFinite(start) && Number.isFinite(end) && end >= start) seekable.push({ start, end });
              }
            } catch (_) { seekable = []; }
          } else if (duration > 0.2) seekable = [{ start: 0, end: maximum }];
        }
      }
      const info = { currentTime, duration, seekable, paused: this.paused, playing: active,
        live: this.live, canSeek: seekable.length > 0, seeking: this._seekBusy };
      this._playbackInfo = info;
      return Object.assign({}, info, { seekable: seekable.map((range) => Object.assign({}, range)) });
    }

    seekTo(seconds) {
      const requested = Number(seconds), info = this.getPlaybackInfo();
      if (!Number.isFinite(requested) || !info.canSeek || this._seekBusy) return false;
      // Keep targets inside a real seekable range; choose its closest edge for gaps.
      let target = info.seekable[0].start, distance = Infinity;
      info.seekable.forEach(function (range) {
        const candidate = Math.max(range.start, Math.min(range.end, requested));
        const difference = Math.abs(candidate - requested);
        if (difference < distance) { distance = difference; target = candidate; }
      });
      try {
        if (this.engine === 'AVPlay') {
          const id = this._generation, seekToken = ++this._seekToken;
          this._seekBusy = true;
          const completed = (failed) => {
            if (!this._valid(id) || this._seekToken !== seekToken || !this._seekBusy) return;
            global.clearTimeout(timeout); this._timers.delete(timeout);
            this._seekBusy = false; this._lastProgress = Date.now();
            if (this._rectPending) { this._rectPending = false; this.refreshRect(); }
            if (failed) this._status(this.paused ? 'paused' : 'playing', 'Bu konuma atlanamadı; başka bir zaman deneyin.');
          };
          const timeout = this._after(() => completed(true), 5000);
          try { this.av.seekTo(Math.round(target * 1000), () => completed(false), () => completed(true)); }
          catch (_) { completed(true); return false; }
        } else {
          this.video.currentTime = target;
          this._lastProgress = Date.now();
        }
        return true;
      } catch (_) {
        this._status(this.paused ? 'paused' : 'playing', 'Bu yayında ileri/geri sarma kullanılamıyor.');
        return false;
      }
    }

    seekBy(seconds) {
      const delta = Number(seconds);
      if (!Number.isFinite(delta)) return false;
      return this.seekTo(this.getPlaybackInfo().currentTime + delta);
    }

    setFullscreen(enabled) {
      this.fullscreen = Boolean(enabled);
      this.refreshRect();
    }

    refreshRect() {
      if (this.engine !== 'AVPlay' || !this._avOwner) return;
      if (this._seekBusy) { this._rectPending = true; return; }
      const bounds = this.fullscreen ? { left: 0, top: 0, width: global.innerWidth, height: global.innerHeight } : this.shell.getBoundingClientRect();
      const viewportWidth = document.documentElement.clientWidth || global.innerWidth || 1920;
      const viewportHeight = document.documentElement.clientHeight || global.innerHeight || 1080;
      const x = Math.max(0, Math.min(1919, Math.round(bounds.left * 1920 / viewportWidth)));
      const y = Math.max(0, Math.min(1079, Math.round(bounds.top * 1080 / viewportHeight)));
      const width = Math.max(1, Math.min(1920 - x, Math.round(bounds.width * 1920 / viewportWidth)));
      const height = Math.max(1, Math.min(1080 - y, Math.round(bounds.height * 1080 / viewportHeight)));
      try { this.av.setDisplayRect(x, y, width, height); } catch (_) { /* Only valid after open() on the hardware decoder. */ }
    }

    stop() {
      ++this._generation;
      this._failed = false;
      this._dispose();
      this._request = null;
      this._attempt = null;
      this._status('stopped', '');
    }

    destroy() {
      if (this._destroyed) return;
      this.stop();
      this._destroyed = true;
      this.options = {};
    }
  }

  global.TVPlayer = TVPlayer;
})(window);

/* AKIŞ TV — MIT. This controller is bundled after TVPlayer in app.js. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var STORE = 'akis.credentials.v1';
  var PREFS = 'akis.preferences.v1';
  var MODES = { live: 'Canlı TV', vod: 'Filmler', series: 'Diziler' };
  var state = {
    screen: 'login', mode: 'live', credentials: null, account: null, demo: false,
    categories: [], items: [], filtered: [], categoryIndex: 0, selected: -1,
    episodes: null, playing: null, fullscreen: false, editing: null,
    token: 0, loginToken: 0, searchToken: 0, requests: new Set(), cache: new Map(),
    format: 'm3u8', busy: false, confirm: null, lastFocus: null, suspended: false,
    seekTarget: null, dialogType: '', seekRepeats: 0
  };
  var tuneTimer, filterTimer, toastTimer, overlayTimer, transportTimer, focusedNode, extras;

  function text(id, value) {
    var node = $(id), copy = value == null ? '' : String(value);
    if (node.textContent !== copy) node.textContent = copy;
  }
  function message(value) {
    text('toast', value); $('toast').hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { $('toast').hidden = true; }, 4500);
  }
  function busy(value) {
    state.busy = value; $('busy-indicator').hidden = !value;
    $('browser-screen').setAttribute('aria-busy', String(value));
    $('login-button').disabled = value && state.screen === 'login';
  }
  function safeStorage(method, key, value) {
    // Explicit preferences may persist; viewing and search activity never do.
    if (key !== STORE && key !== 'akis.format' && key !== PREFS) return null;
    try { return localStorage[method](key, value); }
    catch (error) { if (method === 'setItem') message('TV depolaması kullanılamıyor; bilgiler bu oturumda tutulacak.'); return null; }
  }
  function clearLegacyHistory() {
    // Remove this app's obsolete keys without touching another app's storage.
    try {
      for (var i = localStorage.length - 1; i >= 0; i--) {
        var key = localStorage.key(i);
        if (key && key.indexOf('akis.') === 0 && key !== STORE && key !== 'akis.format' && key !== PREFS) localStorage.removeItem(key);
      }
      for (var n = sessionStorage.length - 1; n >= 0; n--) {
        var transient = sessionStorage.key(n);
        if (transient && transient.indexOf('akis.') === 0) sessionStorage.removeItem(transient);
      }
    } catch (_) { /* Storage can be unavailable; playback never depends on it. */ }
  }
  function normalizeServer(value) {
    var parsed;
    try { parsed = new URL(String(value).trim()); } catch (error) { throw new Error('Sunucu adresini http:// veya https:// ile girin.'); }
    if (!/^https?:$/.test(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new Error('Sunucu alanına yalnızca HTTP/HTTPS adresi ve gerekiyorsa port / dizin girin.');
    }
    parsed.pathname = parsed.pathname.replace(/\/player_api\.php\/?$/i, '').replace(/\/+$/, '');
    return parsed.href.replace(/\/+$/, '');
  }
  function abortRequests() {
    state.requests.forEach(function (xhr) { xhr.abort(); }); state.requests.clear();
  }
  function api(action, params, credentials) {
    var auth = credentials || state.credentials;
    var url = auth.server + '/player_api.php?username=' + encodeURIComponent(auth.username) + '&password=' + encodeURIComponent(auth.password);
    if (action) url += '&action=' + encodeURIComponent(action);
    Object.keys(params || {}).forEach(function (key) { url += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(params[key]); });
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest(); state.requests.add(xhr);
      function done(error, data) { state.requests.delete(xhr); error ? reject(error) : resolve(data); }
      xhr.open('GET', url, true); xhr.timeout = 16000;
      xhr.onload = function () {
        if (xhr.status < 200 || xhr.status >= 300) return done(new Error('Sunucu HTTP ' + xhr.status + ' yanıtı verdi.'));
        if (xhr.responseText.length > 16 * 1024 * 1024) return done(new Error('Kategori yanıtı 16 MB sınırını aşıyor. Sağlayıcıdan daha küçük kategoriler isteyin.'));
        try { done(null, JSON.parse(xhr.responseText)); }
        catch (error) { done(new Error('Sunucu geçerli JSON göndermedi. URL ve Xtream Codes desteğini kontrol edin.')); }
      };
      xhr.onprogress = function (event) {
        if (event.loaded > 16 * 1024 * 1024) {
          xhr.onabort = function () { done(new Error('Yanıt 16 MB sınırını aştı; daha küçük bir kategori gerekli.')); }; xhr.abort();
        }
      };
      xhr.onerror = function () { done(new Error('Bağlantı kurulamadı. Ağ, CORS, HTTP/HTTPS ve sertifikayı kontrol edin.')); };
      xhr.ontimeout = function () { done(new Error('Sunucu 16 saniye içinde yanıt vermedi.')); };
      xhr.onabort = function () { var error = new Error('İstek iptal edildi.'); error.cancelled = true; done(error); };
      xhr.send();
    });
  }
  function short(value, max) { return String(value == null ? '' : value).slice(0, max || 300); }
  function imageURL(value) {
    try { var u = new URL(String(value)); return /^https?:$/.test(u.protocol) && !u.username && !u.password ? u.href : ''; }
    catch (error) { return ''; }
  }
  function normalizeItems(rows, kind, token) {
    if (!Array.isArray(rows)) return Promise.reject(new Error('Sağlayıcı beklenen liste biçimini göndermedi.'));
    return new Promise(function (resolve, reject) {
      var result = [], cursor = 0;
      function chunk() {
        if (token !== state.token) { var e = new Error('İstek iptal edildi.'); e.cancelled = true; return reject(e); }
        var end = Math.min(cursor + 300, rows.length);
        for (; cursor < end; cursor++) {
          var row = rows[cursor] || {};
          var id = kind === 'series' ? row.series_id : row.stream_id;
          if (id == null || !/^\d+$/.test(String(id))) continue;
          result.push({ id: String(id), kind: kind, name: short(row.name || 'İsimsiz yayın', 220),
            image: imageURL(row.stream_icon || row.cover), category: short(row.category_id || Array.isArray(row.category_ids) && row.category_ids[0] || '', 60),
            categories: (Array.isArray(row.category_ids) ? row.category_ids : [row.category_id]).filter(function (value) { return value != null; }).map(function (value) { return short(value, 60); }).slice(0, 30),
            extension: /^[a-z0-9]{2,5}$/i.test(row.container_extension || '') ? row.container_extension : 'mp4',
            description: short(row.plot || row.description || '', 800), rating: short(row.rating || '', 12) });
        }
        if (cursor < rows.length) setTimeout(chunk, 0); else resolve(result);
      }
      chunk();
    });
  }

  // Only visible rows exist in the DOM, even with thousands of channels.
  function VirtualList(kind, height, label) {
    this.kind = kind; this.height = height; this.label = label; this.rows = [];
    this.root = $(kind + '-list'); this.window = $(kind + '-window'); this.spacer = $(kind + '-spacer');
    this.start = -1; this.end = -1; this.frame = null; this.nodes = new Map();
    var self = this;
    this.root.addEventListener('scroll', function () {
      if (!self.frame) self.frame = requestAnimationFrame(function () { self.frame = null; self.render(); });
    });
  }
  VirtualList.prototype.set = function (rows) {
    if (this.frame) cancelAnimationFrame(this.frame);
    this.frame = null;
    this.nodes.clear();
    while (this.window.firstChild) this.window.removeChild(this.window.firstChild);
    this.rows = rows; this.root.scrollTop = 0; this.start = -1; this.end = -1;
    this.spacer.style.height = (rows.length * this.height) + 'px'; this.render(true);
  };
  VirtualList.prototype.render = function (force) {
    var start = Math.max(0, Math.floor(this.root.scrollTop / this.height) - 3);
    var end = Math.min(this.rows.length, start + Math.ceil((this.root.clientHeight || 600) / this.height) + 7);
    if (!force && start === this.start && end === this.end) return;
    var active = document.activeElement;
    var restore = !state.fullscreen && active && this.window.contains(active) ? Number(active.dataset.index) : -1;
    this.start = start; this.end = end;
    this.window.style.transform = 'translateY(' + start * this.height + 'px)';
    var self = this;
    this.nodes.forEach(function (node, index) {
      if (index < start || index >= end) { node.remove(); self.nodes.delete(index); }
    });
    var cursor = this.window.firstChild;
    for (var i = start; i < end; i++) {
      var row = this.rows[i], button = this.nodes.get(i);
      if (!button) {
        button = document.createElement('button');
        button.type = 'button'; button.className = 'list-row ' + this.kind + '-row';
        button.dataset.nav = ''; button.dataset.zone = this.kind; button.dataset.index = String(i);
        button.setAttribute('aria-label', this.label(row, i));
        if (this.kind !== 'category') {
          var number = document.createElement('span'); number.className = 'row-index'; number.textContent = String(i + 1).padStart(2, '0'); button.appendChild(number);
        }
        var copy = document.createElement('span'); copy.className = 'row-copy';
        var title = document.createElement('span'); title.className = 'row-label'; title.textContent = (row.locked ? '🔒 ' : '') + row.name; copy.appendChild(title);
        if (this.kind === 'stream') {
          var subtitle = document.createElement('span'); subtitle.className = 'row-subtitle';
          subtitle.textContent = row.kind === 'live' ? 'CANLI YAYIN' : row.kind === 'episode' ? 'BÖLÜM' : row.kind === 'series' ? 'DİZİ' : 'FİLM'; copy.appendChild(subtitle);
        }
        button.appendChild(copy); this.nodes.set(i, button);
      }
      if (this.kind === 'category') {
        var selected = i === state.categoryIndex;
        button.classList.toggle('is-selected', selected); button.setAttribute('aria-pressed', String(selected));
      } else {
        button.classList.toggle('is-selected', i === state.selected);
        button.classList.toggle('is-playing', !!state.playing && state.playing.id === row.id && state.playing.kind === row.kind);
      }
      if (button !== cursor) this.window.insertBefore(button, cursor);
      cursor = button.nextSibling;
    }
    if (restore >= start && restore < end) this.focus(restore, false);
  };
  VirtualList.prototype.focus = function (index, scroll) {
    if (!this.rows.length) return focusElement($('search-input'));
    index = Math.max(0, Math.min(index, this.rows.length - 1));
    if (scroll !== false) {
      var top = index * this.height, bottom = top + this.height;
      if (top < this.root.scrollTop) this.root.scrollTop = top;
      else if (bottom > this.root.scrollTop + this.root.clientHeight) this.root.scrollTop = bottom - this.root.clientHeight;
      this.render();
    }
    focusElement(this.window.querySelector('[data-index="' + index + '"]'));
  };
  var categories = new VirtualList('category', 68, function (row) { return row.name; });
  var streams = new VirtualList('stream', 82, function (row, i) { return (i + 1) + '. ' + row.name; });

  function visible(element) { return element && !element.disabled && element.getBoundingClientRect().width > 0 && !element.closest('[hidden]'); }
  function focusElement(element) {
    if (!visible(element)) return;
    if (!$('dialog').hidden && !$('dialog').contains(element)) return;
    if ($('dialog').hidden && !$('feature-dialog').hidden && !$('feature-dialog').contains(element)) return;
    try { element.focus({ preventScroll: true }); } catch (error) { element.focus(); }
    if (element.closest('#feature-content,.detail-info,#searchall-results')) {
      try { element.scrollIntoView({ block: 'nearest' }); } catch (_) { /* Optional on older TV engines. */ }
    }
  }
  function showScreen(screen) {
    state.screen = screen;
    ['login', 'home', 'browser', 'search'].forEach(function (name) { $(name + '-screen').hidden = name !== screen; });
    $('home-button').hidden = screen === 'login'; $('settings-button').hidden = screen === 'login';
    text('key-hints', screen === 'login' ? 'Yön tuşları: gezin  ·  OK: alanı düzenle / tamamla  ·  Geri: düzenlemeyi kapat' :
      'Yön tuşları: gezin  ·  OK: seç / tam ekran  ·  Geri: önceki ekran');
    requestAnimationFrame(function () { player.refreshRect(); });
  }
  function showLogin(note) {
    state.token++; state.loginToken++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    player.stop(); state.playing = null; state.cache.clear(); state.credentials = null;
    state.demo = false; showScreen('login'); setFullscreen(false); busy(false);
    if (extras) extras.resetSession();
    text('connection-status', 'HESAP BAĞLI DEĞİL'); text('login-message', note || 'Xtream Codes hesabınızla kütüphanenize bağlanın.');
    focusElement($('server-url'));
  }
  function updateAccount() {
    text('account-name', state.demo ? 'Yerel örnek · hesap gerekmez' : state.credentials.username);
    var expiry = state.account && state.account.exp_date;
    text('account-expiry', state.demo ? '120 saniyelik MIT video · çevrimdışı' :
      expiry && Number(expiry) > 0 ? 'Bitiş: ' + new Date(Number(expiry) * 1000).toLocaleDateString('tr-TR') : 'Hesap etkin');
    text('connection-status', state.demo ? 'YEREL ÖRNEK MODU' : 'XTREAM BAĞLI');
  }
  function showHome() {
    state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer); busy(false);
    player.stop(); state.playing = null; showScreen('home'); setFullscreen(false); updateAccount();
    if (extras) extras.resetSession();
    focusElement(document.querySelector('[data-mode="' + state.mode + '"]'));
  }
  async function login(credentials, automatic) {
    var token = ++state.loginToken; busy(true); text('login-message', automatic ? 'Kayıtlı hesabınıza bağlanılıyor…' : 'Hesap doğrulanıyor…');
    try {
      credentials.server = normalizeServer(credentials.server);
      if (!credentials.username || !credentials.password) throw new Error('Kullanıcı adı ve şifre gerekli.');
      if (location.protocol === 'https:' && credentials.server.indexOf('http:') === 0) throw new Error('HTTPS önizlemesi HTTP sunucuya erişemez. TV widget’ını veya sağlayıcının HTTPS adresini kullanın.');
      var response = await api('', {}, credentials);
      if (token !== state.loginToken) return;
      var account = response && response.user_info;
      if (!account || !(account.auth === true || Number(account.auth) === 1)) throw new Error('Giriş reddedildi. Kullanıcı adı ve şifreyi kontrol edin.');
      if (account.status && String(account.status).toLowerCase() !== 'active') throw new Error('Hesap etkin değil. Sağlayıcınızla görüşün.');
      state.credentials = credentials; state.account = account; state.demo = false;
      safeStorage('setItem', STORE, JSON.stringify(credentials)); busy(false); showHome();
    } catch (error) {
      if (token !== state.loginToken || error.cancelled) return;
      busy(false); text('login-message', error.message); focusElement($('login-button'));
    }
  }
  function demoItems(mode) {
    var label = mode === 'live' ? 'Örnek video · Liste satırı' : mode === 'vod' ? 'Örnek video · Film görünümü' : 'Örnek video · Dizi görünümü';
    var count = mode === 'live' ? 5000 : mode === 'vod' ? 120 : 24;
    return Array.from({ length: count }, function (_, i) {
      return { id: String(i + 1), kind: mode, name: label + ' ' + (i + 1),
        image: '', extension: 'mp4', description: 'Her demo satırı paketteki aynı 120 saniyelik özgün MIT örnek videoyu açar. Bu bir canlı TV yayını veya film/dizi kataloğu değildir. İki ses parçası yalnız sentetik test tonlarıdır; gömülü altyazı yoktur.', rating: '' };
    });
  }
  async function loadMode(mode, desiredCategory) {
    if (!MODES[mode]) return;
    if (extras) extras.clearDigits();
    state.mode = mode; state.episodes = null; state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    player.stop(); state.playing = null; state.selected = -1; state.categories = []; state.filtered = []; state.items = [];
    categories.set([]); streams.set([]); $('search-input').value = ''; showScreen('browser');
    text('browser-title', MODES[mode]); text('browser-subtitle', 'Kategoriler yükleniyor…'); resetDetails(); busy(true);
    focusElement($('home-button'));
    var token = state.token;
    try {
      var rows = state.demo ? [{ category_id: 'demo', category_name: 'Yerel örnek video' }, { category_id: 'sample', category_name: 'Liste gezinme testi' }] :
        await api(mode === 'live' ? 'get_live_categories' : mode === 'vod' ? 'get_vod_categories' : 'get_series_categories');
      if (token !== state.token) return;
      if (!Array.isArray(rows)) throw new Error('Kategori listesi alınamadı.');
      state.categories = rows.map(function (row) { return { id: short(row.category_id, 60), name: short(row.category_name || 'İsimsiz kategori', 120) }; });
      if (!state.categories.length) state.categories = [{ id: '', name: 'Tüm içerikler' }];
      if (extras) { extras.rememberCategories(mode, state.categories); state.categories = extras.visibleCategories(mode, state.categories); }
      state.categoryIndex = Math.max(0, state.categories.findIndex(function (row) { return row.id === desiredCategory; }));
      categories.set(state.categories);
      if (!state.categories.length) { busy(false); text('browser-subtitle', 'Tüm kategoriler gizli. Kategori ayarlarından tekrar gösterebilirsiniz.'); focusElement($('category-settings-button')); return; }
      categories.focus(state.categoryIndex);
      return await loadCategory(state.categoryIndex);
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); text('browser-subtitle', error.message); message(error.message); } }
  }
  async function loadCategory(index) {
    if (!state.categories[index]) return;
    if (extras) extras.clearDigits();
    if (extras && !extras.categoryAllowed(state.mode, state.categories[index].id)) {
      return extras.unlockCategory(state.mode, state.categories[index].id, function () { loadCategory(index); });
    }
    if (index === state.categoryIndex && state.items.length && !state.episodes && !state.busy && !$('search-input').value) return state.token;
    state.categoryIndex = index; state.episodes = null; state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer);
    var token = state.token, category = state.categories[index];
    var key = state.mode + ':' + category.id;
    state.items = []; state.filtered = []; state.selected = -1; streams.set([]); categories.render(true);
    player.stop(); state.playing = null; $('search-input').value = ''; resetDetails(); busy(true);
    text('browser-subtitle', category.name + ' · yükleniyor…');
    try {
      var items = state.cache.get(key);
      if (!items) {
        if (state.demo) items = demoItems(state.mode);
        else {
          var action = state.mode === 'live' ? 'get_live_streams' : state.mode === 'vod' ? 'get_vod_streams' : 'get_series';
          var rows = await api(action, category.id ? { category_id: category.id } : {});
          items = await normalizeItems(rows, state.mode, token);
        }
        if (token !== state.token) return;
        state.cache.set(key, items);
        while (state.cache.size > 3) state.cache.delete(state.cache.keys().next().value);
      }
      if (token !== state.token) return;
      items.forEach(function (item) { if (!item.category) item.category = category.id; });
      if (extras) items = items.filter(function (item) { return extras.itemAllowed(item); });
      state.items = items; state.filtered = items; streams.set(items); busy(false); updateCount();
      if (items.length) selectItem(0, false);
      return token;
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); text('browser-subtitle', error.message); message(error.message); } }
  }
  function updateCount() {
    var category = state.categories[state.categoryIndex];
    text('browser-subtitle', (state.episodes ? state.episodes.title + ' · Bölümler' : category ? category.name : MODES[state.mode]) +
      ' · ' + state.filtered.length.toLocaleString('tr-TR') + ' içerik' + (state.demo ? ' · DEMO' : ''));
  }
  function resetDetails() {
    if (extras) extras.clearEPG();
    text('detail-title', 'Bir içerik seçin'); text('detail-meta', 'Kütüphaneniz hazır');
    text('detail-description', 'Yön tuşlarıyla gezinin. Canlı kanallar kısa beklemenin ardından önizlemede açılır. OK ile tam ekrana geçin.');
    $('detail-image').hidden = true; $('detail-image').removeAttribute('src');
    $('watch-button').disabled = true; $('retry-button').disabled = true; $('pause-button').disabled = true;
    $('format-button').hidden = state.demo || state.mode !== 'live';
    $('player-placeholder').hidden = false; text('placeholder-label', 'Yayın önizlemesi');
    text('playback-status', 'Bir içerik seçin');
  }
  function selectItem(index, preview) {
    var item = state.filtered[index]; if (!item) return;
    state.selected = index; text('detail-title', item.name);
    text('detail-meta', (item.kind === 'episode' ? 'Dizi bölümü' : MODES[item.kind]) + (item.rating ? ' · ★ ' + item.rating : '') + (state.demo ? ' · YEREL ÖRNEK · 120 sn' : ''));
    text('detail-description', item.description || (item.kind === 'live' ? 'OK ile tam ekrana geçin. Tam ekranda ↑ / ↓ ile kanal değiştirin.' :
      item.kind === 'series' ? 'OK ile sezon ve bölüm listesini açın.' : 'OK ile oynatın. Tam ekranda ← / → ile 10 saniye sarın.'));
    var image = $('detail-image'); image.hidden = !item.image;
    if (item.image && image.getAttribute('src') !== item.image) image.src = item.image;
    if (!item.image) image.removeAttribute('src');
    $('watch-button').disabled = false; text('watch-button', item.kind === 'series' ? 'Bölümleri aç' : 'Tam ekran izle');
    $('format-button').hidden = state.demo || item.kind !== 'live';
    if (extras) extras.selectItem(item);
    streams.window.querySelectorAll('[data-index]').forEach(function (button) { button.classList.toggle('is-selected', Number(button.dataset.index) === index); });
    clearTimeout(tuneTimer);
    if (preview && item.kind === 'live' && (!state.playing || state.playing.id !== item.id)) {
      tuneTimer = setTimeout(function () { startPlayback(item, false); }, 450);
    }
  }
  async function openSeries(item) {
    if (extras && !extras.itemAllowed(item)) return extras.unlockItem(item, function () { openSeries(item); });
    state.token++; abortRequests(); clearTimeout(tuneTimer); var token = state.token; busy(true);
    try {
      var response = state.demo ? { episodes: { '1': Array.from({ length: 8 }, function (_, i) { return { id: String(i + 1), episode_num: i + 1, title: 'Yerel örnek bölüm ' + (i + 1) + ' · 120 sn', container_extension: 'mp4' }; }) } } : await api('get_series_info', { series_id: item.id });
      if (token !== state.token) return;
      var rows = response && response.episodes;
      if (!rows || typeof rows !== 'object') throw new Error('Dizinin bölüm bilgisi bulunamadı.');
      var episodes = [];
      Object.keys(rows).sort(function (a, b) { return Number(a) - Number(b); }).forEach(function (season) {
        if (!Array.isArray(rows[season])) return;
        rows[season].forEach(function (episode) {
          if (!episode || !/^\d+$/.test(String(episode.id))) return;
          episodes.push({ id: String(episode.id), kind: 'episode', name: 'S' + season + ' · B' + (episode.episode_num || episodes.length + 1) + ' — ' + short(episode.title || item.name, 160),
            image: imageURL(episode.info && episode.info.movie_image) || item.image, category: item.category, categories: item.categories,
            extension: /^[a-z0-9]{2,5}$/i.test(episode.container_extension || '') ? episode.container_extension : 'mp4',
            description: short(episode.info && episode.info.plot || item.description, 800), rating: '' });
        });
      });
      if (!episodes.length) throw new Error('Bu dizide oynatılabilir bölüm bulunamadı.');
      state.episodes = { items: state.items, filtered: state.filtered, query: $('search-input').value, selected: state.selected, title: item.name };
      state.items = episodes; state.filtered = episodes; state.searchToken++; $('search-input').value = '';
      streams.set(episodes); busy(false); updateCount(); streams.focus(0);
    } catch (error) { if (token === state.token && !error.cancelled) { busy(false); message(error.message); } }
  }
  function streamURL(item, liveFormat) {
    var c = state.credentials, segment = item.kind === 'live' ? 'live' : item.kind === 'vod' ? 'movie' : 'series';
    return c.server + '/' + segment + '/' + encodeURIComponent(c.username) + '/' + encodeURIComponent(c.password) + '/' + item.id + '.' + (item.kind === 'live' ? liveFormat || state.format : item.extension);
  }
  function timeLabel(seconds) {
    var total = Math.max(0, Math.floor(Number(seconds) || 0));
    return [Math.floor(total / 3600), Math.floor(total / 60) % 60, total % 60].map(function (n) { return String(n).padStart(2, '0'); }).join(':');
  }
  function updateSeekControls() {
    var enabled = state.fullscreen && state.playing && state.playing.kind !== 'live';
    $('seek-controls').hidden = !enabled;
    if (!enabled) return;
    var info = player.getPlaybackInfo(), position = state.seekTarget == null ? info.currentTime : state.seekTarget;
    var percentage = info.duration > 0 ? Math.max(0, Math.min(100, position / info.duration * 100)) : 0;
    text('seek-position', timeLabel(position)); text('seek-duration', timeLabel(info.duration));
    text('seek-help', !info.canSeek ? 'Bu içerikte zaman bilgisi / sarma desteği bekleniyor.' :
      state.seekTarget == null ? '← / → Konum seç  ·  OK Duraklat  ·  ↓ Zamana git' : '← / → Konum seç  ·  OK Buraya atla  ·  Geri Vazgeç');
    $('seek-controls').classList.toggle('is-seeking', state.seekTarget != null);
    $('seek-track').setAttribute('aria-valuemax', String(Math.floor(info.duration)));
    $('seek-track').setAttribute('aria-valuenow', String(Math.floor(position)));
    $('seek-track').setAttribute('aria-valuetext', timeLabel(position) + ' / ' + timeLabel(info.duration));
    $('seek-track').setAttribute('aria-disabled', String(!info.canSeek));
    $('seek-time-button').disabled = !info.canSeek;
    var width = percentage.toFixed(2) + '%';
    if ($('seek-fill').style.width !== width) { $('seek-fill').style.width = width; $('seek-thumb').style.left = width; }
  }
  function scheduleTransport() {
    clearTimeout(transportTimer);
    if (!state.fullscreen || !state.playing || state.playing.kind === 'live' || document.hidden || $('player-overlay').hidden) return;
    updateSeekControls();
    if (!player.playing) return;
    transportTimer = setTimeout(scheduleTransport, 500);
  }
  function previewSeek(direction, repeated) {
    var info = player.getPlaybackInfo();
    if (!info.canSeek) { message('Bu içerikte sarma henüz kullanılamıyor.'); return; }
    state.seekRepeats = repeated ? state.seekRepeats + 1 : 0;
    var base = extras ? extras.seekStep() : 10;
    var step = state.seekRepeats > 14 ? Math.max(120, base * 4) : state.seekRepeats > 5 ? Math.max(60, base * 2) : base;
    var origin = state.seekTarget == null ? info.currentTime : state.seekTarget;
    state.seekTarget = Math.max(0, Math.min(Math.max(0, info.duration - 1), origin + direction * step));
    showOverlay(); focusElement($('seek-track'));
  }
  function commitSeek() {
    if (state.seekTarget == null) return;
    if (!player.seekTo(state.seekTarget)) { message('Sarma tamamlanana kadar kısa süre bekleyin veya başka bir konum seçin.'); return; }
    state.seekTarget = null; state.seekRepeats = 0; showOverlay();
  }
  function openSeekDialog() {
    var info = player.getPlaybackInfo();
    if (!info.canSeek) return message('Bu içerikte sarma desteklenmiyor veya süre henüz alınamadı.');
    ask('Zamana git', 'Saat:dakika:saniye yazın. Örnek: 01:20:00 veya 012000. Toplam: ' + timeLabel(info.duration), null);
    state.dialogType = 'seek'; $('seek-time-field').hidden = false;
    $('seek-time-input').value = timeLabel(state.seekTarget == null ? info.currentTime : state.seekTarget);
    text('seek-time-error', ''); focusElement($('seek-time-input'));
  }
  function parseSeekTime(value) {
    var copy = String(value).trim(), match = /^(\d{1,2}):([0-5]\d):([0-5]\d)$/.exec(copy) || /^(\d{2})([0-5]\d)([0-5]\d)$/.exec(copy);
    return match ? Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]) : NaN;
  }
  var player = new window.TVPlayer({
    video: $('video'), shell: $('player-shell'),
    onStatus: function (status, detail) {
      var label = detail || ({ playing: 'Oynatılıyor', stopped: 'Durduruldu', ended: 'Yayın sona erdi.' })[status] || '';
      text('playback-status', label); text('overlay-state', label);
      if (status === 'stopped' || status === 'error' || status === 'ended') {
        state.seekTarget = null; clearTimeout(transportTimer);
        document.body.classList.remove('avplay-active'); $('pause-button').disabled = true;
        $('player-placeholder').hidden = false;
      }
    },
    onError: function (detail) { $('player-placeholder').hidden = false; text('placeholder-label', detail); $('retry-button').disabled = !state.playing; showOverlay(); },
    onPlaying: function () { $('player-placeholder').hidden = true; $('pause-button').disabled = false; text('pause-button', 'Duraklat / devam'); if (extras) extras.playing(); showOverlay(); },
    onSubtitle: function (value) { text('subtitle-display', value); $('subtitle-display').hidden = !value; },
    onSourceChanged: function (source) { var extension = /\.ts(?:\?|$)/i.test(source.url) ? 'TS' : 'HLS'; text('format-button', state.demo ? 'Biçim: MP4 · Yerel örnek' : 'Biçim: ' + extension + (source.alternative ? ' · Otomatik' : '')); },
    onEngine: function (engine) {
      $('player-shell').dataset.engine = engine; document.body.classList.toggle('avplay-active', engine === 'AVPlay');
    },
    onEnded: function () { message('İçerik sona erdi.'); setFullscreen(false); }
  });
  function startPlayback(item, fullscreen) {
    if (!item) return;
    if (extras && !extras.itemAllowed(item)) return extras.unlockItem(item, function () { startPlayback(item, fullscreen); });
    if (item.kind === 'series') return openSeries(item);
    clearTimeout(tuneTimer); clearTimeout(transportTimer); state.seekTarget = null; state.seekRepeats = 0;
    state.playing = item; $('retry-button').disabled = false; $('pause-button').disabled = true;
    $('player-placeholder').hidden = false; text('placeholder-label', 'Yayın açılıyor…'); text('overlay-title', item.name);
    if (fullscreen) setFullscreen(true);
    player.play(state.demo ? { url: new URL('media/orbit-review.mp4', document.baseURI).href, packagedDemo: true, live: false, title: item.name + ' · 120 saniyelik yerel örnek' } :
      { url: streamURL(item), alternativeUrls: item.kind === 'live' ? [streamURL(item, state.format === 'ts' ? 'm3u8' : 'ts')] : [], live: item.kind === 'live', title: item.name });
    streams.render(true);
  }
  function activateSelected() {
    var item = state.filtered[state.selected]; if (!item) return;
    if (item.kind === 'series') return openSeries(item);
    if (state.playing && state.playing.id === item.id && state.playing.kind === item.kind && player.playing) setFullscreen(true);
    else startPlayback(item, true);
  }
  function showOverlay() {
    clearTimeout(overlayTimer); $('player-overlay').hidden = !state.fullscreen;
    if (!state.fullscreen) return;
    scheduleTransport();
    overlayTimer = setTimeout(function () {
      if (state.fullscreen && player.playing && !player.paused && state.seekTarget == null && $('dialog').hidden && $('feature-dialog').hidden) {
        $('player-overlay').hidden = true; clearTimeout(transportTimer);
      }
    }, 4000);
  }
  function setFullscreen(value) {
    var previous = state.fullscreen;
    state.fullscreen = value; state.seekTarget = null; clearTimeout(transportTimer); $('player-shell').classList.toggle('is-fullscreen', value);
    document.body.classList.toggle('player-fullscreen', value); $('privacy-button').hidden = value; player.setFullscreen(value);
    text('overlay-hint', state.mode === 'live' ? '↑ / ↓ Kanal  ·  0–9 Numara  ·  → Oynatıcı ayarları  ·  ← Yayın akışı' : '← / → Konum seç  ·  OK Atla / duraklat  ·  ↓ Kontroller  ·  Geri Küçült');
    updateSeekControls();
    showOverlay();
    if (previous && !value && state.screen === 'browser' && state.selected >= 0) streams.focus(state.selected);
  }
  function changeChannel(delta) {
    if (state.mode !== 'live' || !state.filtered.length) return;
    var next = (state.selected + delta + state.filtered.length) % state.filtered.length;
    selectItem(next, false); text('overlay-title', state.filtered[next].name); showOverlay();
    clearTimeout(tuneTimer); tuneTimer = setTimeout(function () { startPlayback(state.filtered[state.selected], true); }, 220);
  }
  function search() {
    clearTimeout(filterTimer); clearTimeout(tuneTimer); var token = ++state.searchToken;
    filterTimer = setTimeout(function () {
      var query = $('search-input').value.trim().toLocaleLowerCase('tr-TR'), source = state.items, result = [], i = 0;
      function chunk() {
        if (token !== state.searchToken || state.screen !== 'browser') return;
        var end = Math.min(i + 400, source.length);
        for (; i < end; i++) if (!query || source[i].name.toLocaleLowerCase('tr-TR').indexOf(query) !== -1) result.push(source[i]);
        if (i < source.length) return setTimeout(chunk, 0);
        player.stop(); state.playing = null;
        state.filtered = result; state.selected = -1; streams.set(result); updateCount();
        if (result.length) selectItem(0, false); else resetDetails();
      }
      chunk();
    }, 180);
  }

  function startEdit(input) {
    state.editing = input; input.readOnly = false; input.classList.add('is-editing');
    input.blur(); input.focus();
  }
  function endEdit(next) {
    var input = state.editing; if (!input) return;
    state.editing = null; input.readOnly = true; input.classList.remove('is-editing'); input.blur(); focusElement(input);
    if (input.id === 'seek-time-input') { if (next) focusElement($('dialog-confirm')); return; }
    if (input.id === 'pin-input') { if (next) focusElement($('dialog-confirm')); return; }
    if (input.id === 'searchall-input') { if (next && extras) extras.runSearch(); return; }
    if (next && input.id !== 'search-input') {
      var ids = ['server-url', 'username', 'password', 'login-button']; focusElement($(ids[ids.indexOf(input.id) + 1]));
    }
  }
  function ask(title, detail, callback) {
    clearTimeout(tuneTimer); state.lastFocus = document.activeElement; state.confirm = callback;
    state.dialogType = 'confirm'; $('seek-time-field').hidden = true; text('seek-time-error', '');
    $('pin-field').hidden = true; $('pin-input').value = ''; text('pin-error', '');
    text('dialog-title', title); text('dialog-message', detail); $('dialog').hidden = false; focusElement($('dialog-cancel'));
  }
  function closeDialog(confirmed) {
    if (confirmed && extras && extras.confirmDialog()) return;
    if (confirmed && state.dialogType === 'seek') {
      var target = parseSeekTime($('seek-time-input').value), info = player.getPlaybackInfo();
      if (!Number.isFinite(target) || target >= info.duration) {
        text('seek-time-error', '00:00:00 veya 000000 biçiminde, videonun süresinden kısa bir zaman girin.');
        focusElement($('seek-time-input')); return;
      }
      if (!player.seekTo(target)) { text('seek-time-error', 'Bu konuma henüz atlanamıyor; kısa süre bekleyip tekrar deneyin.'); return; }
      state.seekTarget = null;
    }
    var callback = state.confirm; state.confirm = null; $('dialog').hidden = true;
    state.dialogType = ''; $('seek-time-field').hidden = true;
    $('pin-field').hidden = true; $('pin-input').value = ''; if (extras) extras.dialogClosed();
    if (confirmed && callback) callback(); else focusElement(state.lastFocus);
    if (state.fullscreen) showOverlay();
  }
  function back() {
    if (state.editing) return endEdit(false);
    if (!$('dialog').hidden) return closeDialog(false);
    if (extras && extras.back()) return;
    if (state.fullscreen && state.seekTarget != null) { state.seekTarget = null; showOverlay(); return; }
    if (state.fullscreen) return setFullscreen(false);
    if (state.screen === 'browser' && state.episodes) {
      state.token++; state.searchToken++; abortRequests(); clearTimeout(tuneTimer); busy(false); player.stop(); state.playing = null;
      var context = state.episodes; state.episodes = null; state.items = context.items; state.filtered = context.filtered;
      $('search-input').value = context.query; streams.set(state.filtered); updateCount(); streams.focus(context.selected); return;
    }
    if (state.screen === 'browser') return showHome();
    ask('Uygulamadan çıkılsın mı?', 'IPTV Orbit Player kapatılacak. Giriş bilgileriniz TV’de kayıtlı kalır.', function () {
      try { var application = window.tizen.application.getCurrentApplication(); player.destroy(); application.exit(); }
      catch (error) { message('Tarayıcı önizlemesinden çıkmak için sekmeyi kapatın.'); }
    });
  }
  function action(name) {
    if (extras && extras.action(name)) return;
    if (name === 'confirm') return closeDialog(true);
    if (name === 'cancel') return closeDialog(false);
    if (name === 'home') return showHome();
    if (name === 'settings') return (extras ? extras.protect : function (callback) { callback(); })(function () { ask('Hesabı değiştir / sıfırla', 'TV’de kayıtlı sunucu, kullanıcı adı ve şifre silinecek. Yeniden giriş yapabilirsiniz.', function () {
      safeStorage('removeItem', STORE); $('password').value = ''; $('username').value = ''; $('server-url').value = ''; showLogin('Kayıtlı giriş bilgileri silindi.');
    }); });
    if (name === 'demo') { state.loginToken++; abortRequests(); state.demo = true; state.account = null; state.credentials = null; state.cache.clear(); busy(false); return showHome(); }
    if (name === 'watch') return activateSelected();
    if (name === 'seek') return commitSeek();
    if (name === 'seek-time') return openSeekDialog();
    if (name === 'retry' && state.playing) return startPlayback(state.playing, state.fullscreen);
    if (name === 'format') {
      if (state.demo) return message('Yerel örnek sabit bir MP4 dosyasıdır; canlı yayın biçimi kullanılmaz.');
      state.format = state.format === 'm3u8' ? 'ts' : 'm3u8'; text('format-button', 'Biçim: ' + state.format.toUpperCase());
      safeStorage('setItem', 'akis.format', state.format);
      if (state.playing && state.playing.kind === 'live') startPlayback(state.playing, state.fullscreen);
      return;
    }
    if (name === 'pause') { player.togglePause(); showOverlay(); }
  }
  function navigate(direction) {
    var element = document.activeElement, zone = element && element.dataset.zone, index = element && Number(element.dataset.index);
    if (!$('dialog').hidden) {
      var field = state.dialogType === 'pin' ? $('pin-input') : $('seek-time-input');
      if ((state.dialogType === 'seek' || state.dialogType === 'pin') && (element === field || direction === 'ArrowUp')) return focusElement(element === field ? $('dialog-confirm') : field);
      return focusElement(element === $('dialog-confirm') ? $('dialog-cancel') : $('dialog-confirm'));
    }
    if (extras && extras.navigate(direction)) return;
    if (zone === 'stream') {
      if (direction === 'ArrowLeft') return categories.focus(state.categoryIndex);
      if (direction === 'ArrowRight') return focusElement($('watch-button'));
      if (direction === 'ArrowUp' && index === 0) return focusElement($('search-input'));
      return streams.focus(index + (direction === 'ArrowUp' ? -1 : 1));
    }
    if (zone === 'category') {
      if (direction === 'ArrowRight') return streams.focus(Math.max(state.selected, 0));
      if (direction === 'ArrowLeft' || direction === 'ArrowUp' && index === 0) return focusElement($('home-button'));
      return categories.focus(index + (direction === 'ArrowUp' ? -1 : 1));
    }
    if (element === $('search-input') && direction === 'ArrowDown') return streams.focus(0);
    if (element === $('search-input') && direction === 'ArrowLeft') return categories.focus(state.categoryIndex);
    if (element && element.closest('.player-actions') && direction === 'ArrowLeft') return streams.focus(Math.max(state.selected, 0));
    // Geometry handles login, dashboard, header and player action buttons.
    var origin = visible(element) ? element.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
    var ox = origin.left + origin.width / 2, oy = origin.top + origin.height / 2, candidate = null, best = Infinity;
    document.querySelectorAll('[data-nav]').forEach(function (node) {
      if (node === element || !visible(node)) return;
      var rect = node.getBoundingClientRect(), dx = rect.left + rect.width / 2 - ox, dy = rect.top + rect.height / 2 - oy;
      var primary = direction === 'ArrowLeft' ? -dx : direction === 'ArrowRight' ? dx : direction === 'ArrowUp' ? -dy : dy;
      var cross = direction === 'ArrowLeft' || direction === 'ArrowRight' ? Math.abs(dy) : Math.abs(dx);
      if (primary <= 4) return;
      var score = primary + cross * 2.5;
      if (score < best) { best = score; candidate = node; }
    });
    focusElement(candidate);
  }
  document.addEventListener('focusin', function (event) {
    if (focusedNode && focusedNode !== event.target) focusedNode.classList.remove('is-focused');
    var element = event.target; if (element.hasAttribute('data-nav')) element.classList.add('is-focused');
    focusedNode = element;
    if (state.editing && state.editing !== element) { state.editing.readOnly = true; state.editing.classList.remove('is-editing'); state.editing = null; }
    if (element.dataset.zone === 'stream') selectItem(Number(element.dataset.index), true);
    else if (!state.fullscreen) clearTimeout(tuneTimer);
  });
  document.addEventListener('click', function (event) {
    var element = event.target.closest('[data-nav]'); if (!element || element.disabled) return;
    if (element.tagName === 'INPUT') return startEdit(element);
    if (element.id === 'seek-track' && event.detail > 0) {
      var info = player.getPlaybackInfo(), rect = element.getBoundingClientRect();
      if (info.canSeek && rect.width) { state.seekTarget = Math.max(0, Math.min(info.duration - 1, (event.clientX - rect.left) / rect.width * info.duration)); commitSeek(); }
      return;
    }
    if (element.dataset.zone === 'category') return loadCategory(Number(element.dataset.index));
    if (element.dataset.zone === 'stream') { selectItem(Number(element.dataset.index), false); return activateSelected(); }
    if (element.dataset.mode) return loadMode(element.dataset.mode);
    if (element.dataset.action) action(element.dataset.action);
  });
  document.addEventListener('keydown', function (event) {
    var names = { 37: 'ArrowLeft', 38: 'ArrowUp', 39: 'ArrowRight', 40: 'ArrowDown', 13: 'Enter', 10009: 'Back', 27: 'Back', 65376: 'Done', 65385: 'Back' };
    var key = names[event.keyCode] || event.key || '';
    if (event.repeat && (key === 'Enter' || key === 'Done')) { event.preventDefault(); return; }
    if (state.editing) {
      if (key === 'Back' || key === 'Enter' || key === 'Done') { event.preventDefault(); endEdit(key !== 'Back'); }
      return;
    }
    if (key === 'Back' || key === 'Escape' || key === 'Backspace' && event.target.tagName !== 'INPUT') { event.preventDefault(); back(); return; }
    if (!$('dialog').hidden) {
      if (key.indexOf('Arrow') === 0) { event.preventDefault(); navigate(key); }
      else if ((key === 'Enter' || key === 'Done') && !event.repeat) {
        event.preventDefault(); var active = document.activeElement;
        if (active.tagName === 'INPUT') startEdit(active); else active.click();
      }
      return;
    }
    if (extras && extras.handleKey(key, event)) { event.preventDefault(); return; }
    var media = event.keyCode;
    if (media === 10252 || media === 415 || media === 19) {
      event.preventDefault();
      if (media === 10252 || media === 415 && player.paused || media === 19 && !player.paused) player.togglePause();
      showOverlay(); return;
    }
    if (media === 413) { event.preventDefault(); player.stop(); setFullscreen(false); return; }
    if (media === 427 || media === 428) { event.preventDefault(); if (state.fullscreen) changeChannel(media === 427 ? 1 : -1); return; }
    if (media === 412 || media === 417) { event.preventDefault(); player.seekBy(media === 412 ? -10 : 10); return; }
    if (state.fullscreen) {
      if (key.indexOf('Arrow') === 0 || key === 'Enter') {
        event.preventDefault();
        if (key === 'Enter' && document.activeElement === $('player-settings-button') && !$('player-overlay').hidden && extras) extras.openPlayerSettings();
        else if (state.mode !== 'live' && key === 'Enter' && document.activeElement === $('seek-time-button') && !$('player-overlay').hidden) openSeekDialog();
        else if (state.mode !== 'live' && key === 'Enter' && state.seekTarget != null) commitSeek();
        else if (key === 'Enter') {
          if (!player.playing && state.playing) startPlayback(state.playing, true);
          else player.togglePause();
        }
        else if (state.mode === 'live' && (key === 'ArrowUp' || key === 'ArrowDown')) changeChannel(key === 'ArrowUp' ? 1 : -1);
        else if (state.mode !== 'live' && (key === 'ArrowLeft' || key === 'ArrowRight')) previewSeek(key === 'ArrowLeft' ? -1 : 1, event.repeat);
        else if (state.mode !== 'live' && key === 'ArrowDown') { showOverlay(); focusElement(document.activeElement === $('seek-time-button') ? $('player-settings-button') : $('seek-time-button')); }
        else if (state.mode !== 'live' && key === 'ArrowUp') { showOverlay(); focusElement($('seek-track')); }
        showOverlay();
      }
      return;
    }
    if (key.indexOf('Arrow') === 0) { event.preventDefault(); navigate(key); }
    else if (key === 'Enter' || key === 'Done') {
      event.preventDefault(); if (event.repeat) return;
      var element = document.activeElement;
      if (element && element.tagName === 'INPUT') startEdit(element);
      else if (element && typeof element.click === 'function') element.click();
    }
  });
  $('login-form').addEventListener('submit', function (event) {
    event.preventDefault(); if (state.busy) return;
    login({ server: $('server-url').value, username: $('username').value.trim(), password: $('password').value }, false);
  });
  ['server-url', 'username', 'password', 'search-input', 'seek-time-input', 'pin-input', 'searchall-input'].forEach(function (id) { $(id).readOnly = true; });
  $('search-input').addEventListener('input', search);
  $('detail-image').addEventListener('error', function () { this.hidden = true; });
  window.addEventListener('resize', function () { categories.render(true); streams.render(true); player.refreshRect(); });
  window.addEventListener('offline', function () { message('Ağ bağlantısı kesildi. Bağlantıdan sonra Yeniden dene seçeneğini kullanın.'); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { clearTimeout(tuneTimer); clearTimeout(transportTimer); state.seekTarget = null; state.suspended = !!state.playing; player.stop(); if (extras) extras.suspend(); }
    else if (state.suspended) { state.suspended = false; message('Uygulama geri açıldı. Yayına dönmek için OK / Yeniden dene seçin.'); }
  });
  window.addEventListener('pagehide', function () { abortRequests(); clearTimeout(tuneTimer); clearTimeout(transportTimer); if (extras) extras.resetSession(); player.destroy(); });
  try {
    if (window.tizen && tizen.tvinputdevice) ['MediaPlayPause', 'MediaPlay', 'MediaPause', 'MediaStop', 'MediaRewind', 'MediaFastForward', 'ChannelUp', 'ChannelDown', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].forEach(function (name) {
      try { tizen.tvinputdevice.registerKey(name); } catch (error) { /* Optional keys differ by remote. Mandatory arrows/Back are automatic. */ }
    });
  } catch (error) { /* Browser preview has no Tizen API. */ }
  function updateClock() { text('clock', new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })); }
  updateClock(); setInterval(updateClock, 30000);
  clearLegacyHistory();
  extras = window.AkisExperience({ state: state, player: player, api: api, normalizeItems: normalizeItems, demoItems: demoItems,
    storage: safeStorage, message: message, text: text, focus: focusElement, showHome: showHome, showScreen: showScreen,
    setFullscreen: setFullscreen, loadMode: loadMode, loadCategory: loadCategory, selectItem: selectItem, startPlayback: startPlayback,
    ask: ask, closeDialog: closeDialog, showOverlay: showOverlay, categories: categories, streams: streams, abortRequests: abortRequests,
    cancelPreview: function () { clearTimeout(tuneTimer); } });
  state.format = safeStorage('getItem', 'akis.format') === 'ts' ? 'ts' : 'm3u8'; text('format-button', 'Biçim: ' + state.format.toUpperCase());
  showScreen('login'); focusElement($('server-url'));
  try {
    var saved = JSON.parse(safeStorage('getItem', STORE) || 'null');
    if (saved && typeof saved.server === 'string' && typeof saved.username === 'string' && typeof saved.password === 'string') {
      $('server-url').value = saved.server; $('username').value = saved.username; $('password').value = saved.password; login(saved, true);
    }
  } catch (error) { safeStorage('removeItem', STORE); }
}());
