# IPTV Orbit Player

Free, open-source, remote-controlled Xtream-compatible media player for Samsung Tizen TV. Vanilla HTML/CSS/JavaScript, Samsung AVPlay with HTML5 video/HLS.js fallback, and a 1920×1080 TV interface. The interface is currently Turkish.

The application does not supply provider channels, paid content catalogues, subscriptions or IPTV accounts. Connect only to services you are authorized to use. An optional, clearly labelled **120-second original MIT demo video** is bundled for offline playback without an account.

## Run locally

Use Node.js 20.19+, 22.12+ or 24+:

```sh
npm ci
npm test
npm run dev
```

Open [the local preview](http://127.0.0.1:4173). The server binds only to the local computer and does not expose a provider account on the Internet. Choose **Hesapsız yerel örneği izle** to try the packaged demo without entering credentials. Every Live, Movie and Episode demo row opens the **same finite MP4**, with two synthetic AAC tone tracks and no embedded subtitles. The large sample lists and demo programme information are navigation examples, not real broadcasts. Use the Movie/episode view to try VOD seeking.

For the separate synthetic Xtream API fixture, run `node tests/fixture-server.mjs` in another terminal. Its deliberately public test-only login is server `http://127.0.0.1:4174`, username `test`, password `test-pass`. These are local fixture values, not a provider account. The fixture media is a different 20-second synthetic sample. A TV's own loopback address does not refer to the computer.

## Features and remote controls

- Live, movie and series browsing with bounded virtual lists and mini/full-screen playback.
- Bounded HLS/TS alternative-source attempts; no codec transcoding.
- Provider EPG, unified search, stream audio/subtitle selection and fit/fill/stretch.
- VOD timeline, go-to-time and 10/30/60-second seek steps.
- Numeric channel selection, category hiding and a user-created 4–8-digit PIN.

Arrows move focus and OK selects. Return moves back. In full-screen live TV, up/down switch channels, right opens player settings and left opens the programme guide. Digits choose the visible list's 1-based channel number; OK confirms or the last digit commits after 1.6 seconds.

In full-screen VOD, left/right preview a seek position and OK commits it. Holding an arrow accelerates the selection. Down switches between **Zamana git** and **Oynatıcı ayarları**. Go-to-time accepts `HH:MM:SS` or `HHMMSS`. Seeking depends on the source/decoder and is not frame-accurate. The application does not implement live time-shifting, recording or resume playback.

## Privacy

The application does not persist viewing/search history, recently watched titles or resume positions and has no publisher analytics/ad endpoint. Requests to your chosen provider and its media/image hosts can still be logged by those services.

For auto-login, **server address, username and password are saved in plaintext localStorage**. They are not an encrypted vault. Only explicit format, category/PIN, picture and seek preferences also persist. PIN verification uses a random salt and PBKDF2-SHA256; unlock grants remain in memory. **Hesap → Hesabı değiştir / sıfırla** removes the saved login, not all independent preferences. Do not put personal credentials in a public demo or GitHub issue.

Open **Bilgi ve gizlilik** from the login screen or browsing/home header to read local privacy/support information without a PIN or network access. Up/down navigate its sections; Return closes it. The header control is hidden during full-screen playback; first Return to the browsing view.

The static TR/EN/Korean policy pages and TR/EN support pages are in `docs/`. Support/privacy: **aksay84@gmail.com**, **+90 505 014 95 55**, or [GitHub Issues](https://github.com/muhammetaksay/iptv-orbit-player/issues), which is public. The publisher authorized these public contact details. Never send passwords, PINs, provider/media URLs or unredacted network logs. The root project's website is hosted on GitHub Pages; the latest source update and a newly added language page should be checked after each deployment.

## Prepare for Samsung TV

```sh
npm run stage
```

This creates `build/stage` using an explicit runtime allowlist, including the demo and license notices. Sign/package that directory using Samsung's official TV tools and your own valid author/distributor certificate profile. Follow [Samsung's TV SDK guide](https://developer.samsung.com/smarttv/develop/getting-started/setting-up-sdk.html). Certificates, private keys, per-device distributor data and signed development widgets are deliberately absent from this source release.

The manifest declares Tizen 5.0+ and a TV profile. This is a software minimum, not proof of testing on all model groups. The internal app ID `AkisTV2026.AkisTV`, package ID `AkisTV2026` and existing `akis.*` storage schemas stay stable for update compatibility despite the public name change.

For an already signed compatible widget and a TV in developer mode, `npm run deploy:tv -- --help` explains the direct SDB update helper. Configure `AKIS_SDB` if SDB is outside the normal SDK/PATH locations. `npm run deploy:tv -- --ip TV_IPV4 --package PATH_TO_SIGNED_WIDGET.wgt` stops, pushes, installs and launches; it does not create certificates or call uninstall. Back up your signing material privately and keep the same author certificate for updates. SDK installation behavior and TV storage retention should be checked on the target device.

Samsung store review, seller status and distribution are separate from local developer-mode installation. No Samsung certification or universal installability is claimed by this source release.

## Verification and limits

The latest developer test run for 1.2.3 passed **65 tests** (24 player, 16 controller, 17 experience, 7 utilities, 1 bundled-media/range-serving). Tests include mocked platform APIs and privacy-overlay navigation/data-preservation checks. Earlier physical development checks on Samsung AU7000 covered basic provider TS playback, automatic login, navigation and synthetic-media feature flows; they do not certify all models, codecs or prolonged playback. Repeat device/provider checks for your own deployment.

EPG and tracks require provider support. Network errors, CORS, HTTP/TLS, connection limits and codecs can prevent playback. `<access>` grants widget network access; it does not alter provider CORS headers. HTTPS is recommended; explicit HTTP is unencrypted. No automatic HTTP downgrade is performed. Zero freezes cannot be guaranteed.

## Source layout and licenses

`index.html`, `style.css`, `app.js`, `features.js`, `experience.js` and `config.xml` form the application; `vendor/` contains HLS.js, `media/` the optional original demo, `scripts/` local development helpers, `tests/` synthetic tests and `docs/` the static public site. `npm run sources` generates a full text source export.

Application: **MIT**, retaining the original `2026 AKIŞ TV contributors` copyright notice. HLS.js 1.7.3: **Apache-2.0**, notices retained in `vendor/`. Original demonstration video: **MIT**, see `media/LICENSE`. Test fixtures: project MIT license, see `tests/fixtures/README.md`. Samsung platform APIs/tools retain their owners' terms. Software licenses grant no rights to third-party broadcasts or media.
