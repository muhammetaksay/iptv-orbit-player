import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';
import { webcrypto, pbkdf2Sync } from 'node:crypto';

const index = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const source = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
const featureSource = readFileSync(new URL('../features.js', import.meta.url), 'utf8');
const experienceSource = readFileSync(new URL('../experience.js', import.meta.url), 'utf8');
const marker = '/* AKIŞ TV — MIT. This controller is bundled after TVPlayer in app.js. */';
assert.ok(source.includes(marker));
const controller = source.slice(source.indexOf(marker));
const STORE = 'akis.credentials.v1';
const DEFER = Symbol('defer');
const account = { user_info: { auth: 1, status: 'Active', exp_date: '2000000000' } };
const credentials = { server: 'https://provider.invalid', username: 'a+b &ç', password: 'p/&?#+' };
const defaultCategories = [{ category_id: '11', category_name: 'Haber' }, { category_id: '22', category_name: 'Kültür' }];
const liveRows = (count, prefix = 'Kanal') => Array.from({ length: count }, (_, i) => ({ stream_id: i + 1, name: `${prefix} ${i + 1}`, category_id: '11' }));

function fixture({ saved, route, storage = {} } = {}) {
  const dom = new JSDOM(index, { url: 'http://localhost:4173/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  const { document } = window;
  Object.defineProperty(window.crypto, 'subtle', { value: webcrypto.subtle });
  window.TextDecoder = TextDecoder; window.TextEncoder = TextEncoder;
  const requests = [];
  const timers = new Map();
  const players = [];
  let clock = 0;
  let id = 0;
  window.setTimeout = (fn, delay = 0) => { const key = ++id; timers.set(key, { fn, at: clock + Number(delay), interval: 0 }); return key; };
  window.clearTimeout = (key) => timers.delete(key);
  window.setInterval = (fn, delay) => { const key = ++id; timers.set(key, { fn, at: clock + delay, interval: delay }); return key; };
  window.clearInterval = window.clearTimeout;
  window.requestAnimationFrame = (fn) => window.setTimeout(() => fn(clock), 16);
  window.cancelAnimationFrame = window.clearTimeout;
  window.HTMLElement.prototype.getBoundingClientRect = function () {
    const field = ['server-url', 'username', 'password', 'login-button'].indexOf(this.id);
    const index = Number(this.dataset.index || 0);
    const left = this.dataset.zone === 'category' ? 80 : this.dataset.zone === 'stream' ? 500 : field >= 0 ? 1100 : this.id === 'home-button' ? 1400 : 50;
    const top = field >= 0 ? 300 + field * 90 : this.dataset.zone ? 270 + index * 82 : 60;
    return { left, top, right: left + 300, bottom: top + 60, width: 300, height: 60, x: left, y: top, toJSON() {} };
  };
  ['category-list', 'stream-list'].forEach((name) => Object.defineProperty(document.getElementById(name), 'clientHeight', { value: 600 }));
  class Player {
    constructor(options) { this.options = options; this.plays = []; this.seeks = []; this.stops = 0; this.playing = false; this.paused = false; this.position = 0; this.duration = 7200; players.push(this); }
    stop() { this.stops += 1; this.playing = false; this.paused = false; this.options.onStatus('stopped', ''); }
    play(request) { this.plays.push(request); this.position = 0; this.live = request.live; this.playing = true; this.options.onEngine('HTML5'); this.options.onStatus('playing', ''); this.options.onPlaying(); }
    setFullscreen(value) { this.fullscreen = value; }
    refreshRect() {}
    togglePause() { this.paused = !this.paused; }
    seekBy() {}
    seekTo(seconds) { if (!this.playing || this.live) return false; this.seeks.push(seconds); this.position = seconds; return true; }
    getPlaybackInfo() { return { currentTime: this.position, duration: this.live ? 0 : this.duration, playing: this.playing, paused: this.paused, live: this.live, seeking: false, canSeek: this.playing && !this.live, seekable: [] }; }
    getAudioTracks() { return [{ index: 0, label: 'Türkçe', language: 'tr', selected: true }, { index: 1, label: 'English', language: 'en', selected: false }]; }
    getSubtitleTracks() { return [{ index: 2, label: 'Türkçe altyazı', language: 'tr', selected: false }]; }
    selectAudioTrack(index) { this.audio = index; return true; }
    selectSubtitleTrack(index) { this.subtitle = index; return true; }
    setAspectRatio(value) { this.aspect = value; return true; }
    destroy() { this.stop(); }
  }
  window.TVPlayer = Player;
  class XHR {
    open(method, url) { this.method = method; this.url = url; }
    abort() { this.aborted = true; if (this.onabort) this.onabort(); }
    respond(data, status = 200) { this.status = status; this.responseText = JSON.stringify(data); if (this.onload) this.onload(); }
    send() {
      requests.push(this);
      const parsed = new URL(this.url);
      const action = parsed.searchParams.get('action') || '';
      let data = route ? route(action, parsed, this) : undefined;
      if (data === undefined) {
        if (!action) data = account;
        else if (action.endsWith('_categories')) data = defaultCategories;
        else if (action === 'get_live_streams') data = liveRows(3);
        else if (action === 'get_vod_streams') data = [{ stream_id: 71, name: 'Film', container_extension: 'mp4' }];
        else if (action === 'get_series') data = [{ series_id: 81, name: 'Dizi' }];
        else if (action === 'get_series_info') data = { episodes: { '1': [{ id: '901', title: 'Başlangıç', episode_num: 1, container_extension: 'mkv' }, { id: '902', title: 'Devam', episode_num: 2, container_extension: 'mp4' }] } };
        else if (action === 'get_short_epg' || action === 'get_simple_data_table') data = { epg_listings: [] };
      }
      if (data !== DEFER) queueMicrotask(() => this.respond(data));
    }
  }
  window.XMLHttpRequest = XHR;
  if (saved) window.localStorage.setItem(STORE, JSON.stringify(saved));
  Object.entries(storage).forEach(([key, value]) => window.localStorage.setItem(key, value));
  window.eval(featureSource); window.eval(experienceSource); window.eval(controller);

  function tick(milliseconds) {
    const target = clock + milliseconds;
    let loops = 0;
    while (true) {
      const next = [...timers.entries()].filter(([, task]) => task.at <= target).sort((a, b) => a[1].at - b[1].at || a[0] - b[0])[0];
      if (!next) break;
      assert.ok(++loops < 10000, 'controller timer scheduling must remain bounded');
      clock = next[1].at;
      timers.delete(next[0]);
      next[1].fn();
      if (next[1].interval) timers.set(next[0], { ...next[1], at: clock + next[1].interval });
    }
    clock = target;
  }
  async function flush() {
    // API continuations and chunked normalization each enqueue further microtasks/timers.
    for (let n = 0; n < 24; n += 1) { await Promise.resolve(); tick(0); }
  }
  const $ = (name) => document.getElementById(name);
  function key(value, keyCode, repeat = false) { document.activeElement.dispatchEvent(new window.KeyboardEvent('keydown', { key: value, keyCode: keyCode || 0, repeat, bubbles: true, cancelable: true })); }
  async function login(values = credentials) {
    $('server-url').value = values.server; $('username').value = values.username; $('password').value = values.password;
    $('login-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    await flush();
  }
  async function mode(name) { document.querySelector(`[data-mode="${name}"]`).click(); await flush(); }
  function stream(index = 0) { return document.querySelector(`#stream-window [data-index="${index}"]`); }
  function category(index = 0) { return document.querySelector(`#category-window [data-index="${index}"]`); }
  async function advance(milliseconds) { tick(milliseconds); await flush(); }
  return { dom, window, document, $, key, flush, login, mode, stream, category, requests, player: players[0], advance, close() { dom.window.close(); } };
}


const PREFS = 'akis.preferences.v1';
function categoryKey(mode, id) {
  const input = `${credentials.server}\n${credentials.username}`;
  let hash = 2166136261;
  for (let i = 0; i < input.length; i += 1) { hash ^= input.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return `${(hash >>> 0).toString(16)}:${JSON.stringify([mode, String(id)])}`;
}
function pinRecord(pin) {
  const salt = Buffer.alloc(16, 23);
  return { v: 1, algorithm: 'PBKDF2-SHA256', iterations: 100000, salt: salt.toString('base64'), hash: pbkdf2Sync(pin, salt, 100000, 32, 'sha256').toString('base64') };
}
function preferences(changes = {}) { return JSON.stringify({ v: 1, hidden: [], locked: [], pin: null, aspect: 'fit', seekStep: 10, ...changes }); }
function operation(f, name, value) { return f.document.querySelector(`[data-feature-op="${name}"]${value === undefined ? '' : `[data-value="${value}"]`}`); }
async function waitUntil(f, predicate) {
  for (let n = 0; n < 200; n += 1) {
    await f.flush();
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  assert.ok(predicate(), 'asynchronous UI operation must settle');
}
async function globalSearch(f, query) {
  f.document.querySelector('[data-action="global-search"]').click();
  f.$('searchall-input').focus(); f.key('Enter', 13);
  f.$('searchall-input').value = query; f.key('Done', 65376); await f.flush();
}

// This independent integration fixture intentionally exercises delivered UI events.
test('global search spans all media, filters locked/hidden results and stores no query or viewed-title history', async (t) => {
  const prefs = preferences({ locked: [categoryKey('live', '22')], hidden: [categoryKey('vod', '22')], pin: pinRecord('1234') });
  const f = fixture({ storage: { [PREFS]: prefs }, route(action) {
    if (action === 'get_live_streams') return [{ stream_id: 10, name: 'Örnek Haber', category_id: '11' }, { stream_id: 11, name: 'Örnek Kilitli', category_id: '22' }];
    if (action === 'get_vod_streams') return [{ stream_id: 20, name: 'Ornek Film', category_id: '11' }, { stream_id: 21, name: 'Örnek Gizli', category_id: '22' }];
    if (action === 'get_series') return [{ series_id: 30, name: 'ÖRNEK Dizi', category_id: '11' }];
  } }); t.after(() => f.close());
  await f.login(); await globalSearch(f, 'ornek');
  assert.match(f.$('searchall-status').textContent, /^3 sonuç/);
  assert.equal(f.document.querySelectorAll('#searchall-results button').length, 3);
  assert.match(f.$('searchall-results').textContent, /Örnek Haber/);
  assert.doesNotMatch(f.$('searchall-results').textContent, /Kilitli|Gizli/);
  const actions = f.requests.map((xhr) => new URL(xhr.url).searchParams.get('action'));
  assert.ok(['get_live_streams', 'get_vod_streams', 'get_series'].every((action) => actions.includes(action)));
  assert.equal(f.player.plays.length, 0);
  assert.equal(f.window.localStorage.length, 2);
  assert.equal(f.window.sessionStorage.length, 0);
  assert.doesNotMatch(f.window.localStorage.getItem(PREFS), /ornek|Haber|Film|Dizi/i);
  f.$('home-button').click();
  assert.equal(f.$('searchall-input').value, '');
  assert.equal(f.$('searchall-results').textContent, '');
});

test('EPG requests debounce to the selected channel and safely display decoded programme text', async (t) => {
  const start = Math.floor(Date.now() / 1000) - 60;
  const title = '<img src=x onerror=alert(1)> Haber Bülteni';
  const epg = { epg_listings: [{ title: Buffer.from(title).toString('base64'), description: Buffer.from('Türkçe açıklama').toString('base64'), start_timestamp: start, stop_timestamp: start + 3600 }, { title: Buffer.from('Sonraki Program').toString('base64'), start_timestamp: start + 3600, stop_timestamp: start + 7200 }] };
  const f = fixture({ route(action) { if (action === 'get_short_epg' || action === 'get_simple_data_table') return epg; } }); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.stream(0).focus(); f.stream(1).focus(); await f.advance(350);
  const short = f.requests.filter((xhr) => new URL(xhr.url).searchParams.get('action') === 'get_short_epg');
  assert.equal(short.length, 1);
  assert.equal(new URL(short[0].url).searchParams.get('stream_id'), '2');
  assert.equal(f.$('epg-now-title').textContent, title);
  assert.equal(f.$('epg-next-title').textContent, 'Sonraki Program');
  assert.equal(f.$('epg-summary').querySelector('img'), null);
  f.$('epg-button').click(); await f.flush();
  assert.equal(f.$('feature-dialog').hidden, false);
  assert.equal(f.document.querySelectorAll('.programme-row').length, 2);
  assert.equal(f.$('feature-content').querySelector('img'), null);
});

test('numeric channel input commits with OK and its timer cannot tune behind a newly opened modal', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.key('2', 50); f.key('Enter', 13);
  assert.match(f.player.plays.at(-1).url, /\/2\.m3u8$/);
  assert.equal(f.$('digit-channel-overlay').hidden, true);
  const plays = f.player.plays.length;
  f.key('1', 49);
  f.document.querySelector('[data-action="player-settings"]').click();
  await f.advance(1800);
  assert.equal(f.player.plays.length, plays, 'opening settings must cancel a pending numeric tune');
  assert.equal(f.$('feature-dialog').hidden, false);
});

test('player settings route tracks and aspect preferences and update the configured seek step', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('vod'); f.stream(0).focus(); f.key('Enter', 13);
  f.document.querySelector('[data-action="player-settings"]').click();
  operation(f, 'audio', 1).click(); assert.equal(f.player.audio, 1);
  operation(f, 'subtitle', 2).click(); assert.equal(f.player.subtitle, 2);
  operation(f, 'subtitle', -1).click(); assert.equal(f.player.subtitle, -1);
  operation(f, 'aspect', 'fill').click(); assert.equal(f.player.aspect, 'fill');
  operation(f, 'seek-step', 30).click();
  const prefs = JSON.parse(f.window.localStorage.getItem(PREFS));
  assert.equal(prefs.aspect, 'fill'); assert.equal(prefs.seekStep, 30);
  assert.deepEqual(Object.keys(prefs).sort(), ['aspect', 'hidden', 'locked', 'pin', 'seekStep', 'v']);
  f.key('Back', 10009); f.key('ArrowRight', 39); f.key('Enter', 13);
  assert.equal(f.player.seeks.at(-1), 30);
  assert.equal(f.window.sessionStorage.length, 0);
});

test('locked categories reject an incorrect PIN, unlock for this session, and relock after Home', async (t) => {
  const f = fixture({ storage: { [PREFS]: preferences({ pin: pinRecord('1234'), locked: [categoryKey('live', '22')] }) }, route(action, parsed) {
    if (action === 'get_live_streams') return [{ stream_id: parsed.searchParams.get('category_id') === '22' ? 22 : 11, name: 'Kanal', category_id: parsed.searchParams.get('category_id') }];
  } }); t.after(() => f.close());
  await f.login(); await f.mode('live'); f.category(1).click();
  assert.equal(f.$('dialog').hidden, false);
  assert.equal(f.document.activeElement.id, 'pin-input');
  f.$('pin-input').value = '0000'; f.$('dialog-confirm').click();
  await waitUntil(f, () => f.$('pin-error').textContent === 'PIN yanlış.');
  assert.equal(f.$('dialog').hidden, false);
  assert.equal(f.player.plays.length, 0);
  f.$('pin-input').value = '1234'; f.$('dialog-confirm').click();
  await waitUntil(f, () => f.$('dialog').hidden);
  await f.flush();
  assert.equal(f.$('pin-input').value, '', 'raw PIN must clear when dialog closes');
  assert.match(f.$('browser-subtitle').textContent, /Kültür/);
  f.$('home-button').click(); await f.mode('live'); f.category(1).click();
  assert.equal(f.$('dialog').hidden, false, 'Home revokes all temporary grants');
  assert.equal(f.$('pin-input').value, '');
  assert.doesNotMatch(f.window.localStorage.getItem(PREFS), /1234/);
});

test('category hide applies immediately and no-category API providers still display their uncategorized items', async (t) => {
  const f = fixture(); t.after(() => f.close());
  await f.login(); await f.mode('live'); f.stream(0).focus(); f.key('Enter', 13); f.key('Back', 10009);
  f.$('category-settings-button').click(); await f.flush();
  operation(f, 'category-hide', '11').click();
  assert.equal(f.player.playing, false);
  const prefs = JSON.parse(f.window.localStorage.getItem(PREFS));
  assert.ok(prefs.hidden.includes(categoryKey('live', '11')));
  f.key('Back', 10009); await f.flush();
  assert.equal(f.document.querySelectorAll('#category-window button').length, 1);
  assert.equal(f.category(0).textContent.includes('Kültür'), true);
  const noCategories = fixture({ route(action) {
    if (action.endsWith('_categories')) return [];
    if (action === 'get_live_streams') return [{ stream_id: 55, name: 'Kategorisiz Kanal' }];
  } }); t.after(() => noCategories.close());
  await noCategories.login(); await noCategories.mode('live');
  assert.equal(noCategories.stream(0)?.textContent.includes('Kategorisiz Kanal'), true);
  assert.equal(noCategories.$('busy-indicator').hidden, true);
});

for (const change of ['category-hide', 'category-lock']) {
  test(`multi-category item A+B stops immediately when ${change} protects B while browsing A`, async (t) => {
    const f = fixture({ storage: { [PREFS]: preferences(change === 'category-lock' ? { pin: pinRecord('1234') } : {}) }, route(action) {
      if (action === 'get_live_streams') return [{ stream_id: 77, name: 'Ortak Kanal', category_id: '11', category_ids: ['11', '22'] }];
    } }); t.after(() => f.close());
    await f.login(); await f.mode('live'); f.stream(0).focus(); f.key('Enter', 13); f.key('Back', 10009);
    assert.equal(f.player.playing, true);
    f.$('category-settings-button').click();
    if (change === 'category-lock') {
      f.$('pin-input').value = '1234'; f.$('dialog-confirm').click();
      await waitUntil(f, () => !f.$('feature-dialog').hidden);
    }
    await f.flush();
    operation(f, change, '22').click();
    assert.equal(f.player.playing, false, 'newly restricted membership must stop the current decoder before leaving settings');
    assert.equal(f.document.querySelectorAll('#stream-window button').length, 0);
    assert.equal(f.$('feature-dialog').hidden, false);
    assert.equal(f.$('epg-summary').hidden, true);
  });
}

test('late category-mode responses preserve the latest mode and cannot overwrite a newer player modal', async (t) => {
  const pending = new Map();
  const f = fixture({ route(action, parsed, xhr) {
    if (action === 'get_vod_categories' || action === 'get_series_categories') { pending.set(action, xhr); return DEFER; }
  } }); t.after(() => f.close());
  await f.login(); await f.mode('live'); f.$('category-settings-button').click(); await f.flush();
  operation(f, 'category-mode', 'vod').click(); operation(f, 'category-mode', 'series').click();
  pending.get('get_series_categories').respond([{ category_id: '32', category_name: 'Yeni Dizi Kategorisi' }]); await f.flush();
  assert.match(operation(f, 'category-mode', 'series').textContent, /^✓/);
  pending.get('get_vod_categories').respond([{ category_id: '31', category_name: 'Eski Film Kategorisi' }]); await f.flush();
  assert.match(operation(f, 'category-mode', 'series').textContent, /^✓/);
  assert.match(f.$('feature-content').textContent, /Yeni Dizi Kategorisi/);
  assert.doesNotMatch(f.$('feature-content').textContent, /Eski Film Kategorisi/);

  let late;
  const replacement = fixture({ route(action, parsed, xhr) { if (action === 'get_vod_categories') { late = xhr; return DEFER; } } }); t.after(() => replacement.close());
  await replacement.login(); await replacement.mode('live'); replacement.$('category-settings-button').click(); await replacement.flush();
  operation(replacement, 'category-mode', 'vod').click(); replacement.key('Back', 10009);
  replacement.document.querySelector('[data-action="player-settings"]').click();
  late.respond([{ category_id: '99', category_name: 'Geç Kategori' }]); await replacement.flush();
  assert.equal(replacement.$('feature-title').textContent, 'Oynatıcı ayarları');
  assert.equal(operation(replacement, 'category-mode', 'vod'), null);
  assert.doesNotMatch(replacement.$('feature-content').textContent, /Geç Kategori/);
});

test('a pending global-search result category load cannot autoplay after Home cancels it', async (t) => {
  let categoryCalls = 0, pending;
  const f = fixture({ route(action, parsed, xhr) {
    if (action === 'get_live_categories' && ++categoryCalls === 2) { pending = xhr; return DEFER; }
    if (action === 'get_live_streams') return [{ stream_id: 61, name: 'Örnek Kanal', category_id: '11' }];
    if (action === 'get_vod_streams' || action === 'get_series') return [];
  } }); t.after(() => f.close());
  await f.login(); await globalSearch(f, 'ornek');
  f.document.querySelector('#searchall-results button').click(); await f.flush();
  assert.ok(pending, 'result navigation must still be waiting for categories');
  f.$('home-button').click();
  pending.respond(defaultCategories); await f.flush(); await f.advance(2000);
  assert.equal(f.$('home-screen').hidden, false);
  assert.equal(f.player.plays.length, 0);
  assert.equal(f.player.playing, false);
  assert.equal(f.player.fullscreen, false);
});

test('pending numeric channel input is invalidated by both category changes and list filtering', async (t) => {
  const f = fixture({ route(action, parsed) {
    if (action === 'get_live_streams') return [{ stream_id: parsed.searchParams.get('category_id') === '22' ? 22 : 11, name: 'Konuk Kanal', category_id: parsed.searchParams.get('category_id') }];
  } }); t.after(() => f.close());
  await f.login(); await f.mode('live');
  f.key('1', 49); f.category(1).click(); await f.flush(); await f.advance(1800);
  assert.equal(f.player.plays.length, 0, 'old list number cannot tune a channel in the new category');
  assert.equal(f.$('digit-channel-overlay').hidden, true);
  f.key('1', 49); f.$('search-input').value = 'Konuk';
  f.$('search-input').dispatchEvent(new f.window.Event('input', { bubbles: true }));
  await f.advance(180); await f.advance(1800);
  assert.equal(f.player.plays.length, 0, 'filtering changes the list identity and invalidates pending number selection');
  assert.equal(f.$('digit-channel-overlay').hidden, true);
});

test('global search accepts category_ids-only rows and can open their matching content', async (t) => {
  const f = fixture({ route(action) {
    if (action === 'get_live_streams') return [{ stream_id: 61, name: 'Ornek Kanal', category_ids: ['11', '22'] }];
    if (action === 'get_vod_streams') return [{ stream_id: 62, name: 'Ornek Film', category_ids: ['11'] }];
    if (action === 'get_series') return [{ series_id: 63, name: 'Ornek Dizi', category_ids: ['11'] }];
  } }); t.after(() => f.close());
  await f.login(); await globalSearch(f, 'ornek');
  assert.match(f.$('searchall-status').textContent, /^3 sonuç/);
  assert.equal(f.document.querySelectorAll('#searchall-results button').length, 3);
  f.document.querySelector('#searchall-results button').click(); await f.flush();
  assert.equal(f.$('browser-screen').hidden, false);
  assert.equal(f.player.playing, true);
  assert.match(f.player.plays.at(-1).url, /\/61\.m3u8$/);
});

test('explicit offline demo plays the same finite sample through Live, VOD and episode flows without provider requests or history', async (t) => {
  const f = fixture(); t.after(() => f.close());
  f.document.querySelector('[data-action="demo"]').click();
  assert.equal(f.requests.length, 0);
  assert.match(f.$('account-expiry').textContent, /120 saniyelik MIT video/);
  await f.mode('live');
  assert.equal(f.$('stream-spacer').style.height, `${5000 * 82}px`);
  assert.match(f.stream(0).textContent, /Örnek video/);
  f.stream(0).focus(); f.key('Enter', 13);
  const sample = 'http://localhost:4173/media/orbit-review.mp4';
  assert.equal(f.player.plays.at(-1).url, sample);
  assert.equal(f.player.plays.at(-1).packagedDemo, true);
  assert.equal(f.player.plays.at(-1).live, false, 'finite sample must never advertise a 24/7 live stream');
  assert.match(f.$('detail-description').textContent, /aynı 120 saniyelik/);
  assert.equal(f.$('format-button').hidden, true);
  f.$('home-button').click(); await f.mode('vod');
  f.player.duration = 120;
  f.stream(0).focus(); f.key('Enter', 13); f.key('ArrowRight', 39); f.key('Enter', 13);
  assert.equal(f.player.plays.at(-1).url, sample);
  assert.equal(f.player.seeks.at(-1), 10);
  f.$('home-button').click(); await f.mode('series');
  f.stream(0).focus(); f.key('Enter', 13); await f.flush();
  assert.match(f.stream(0).textContent, /Yerel örnek bölüm/);
  f.key('Enter', 13); f.key('ArrowRight', 39); f.key('Enter', 13);
  assert.equal(f.player.plays.at(-1).url, sample);
  assert.equal(f.player.seeks.at(-1), 10);
  assert.equal(f.requests.length, 0);
  assert.equal(f.window.localStorage.length, 0);
  assert.equal(f.window.sessionStorage.length, 0);
});

test('choosing demo cancels pending auto-login without replacing saved credentials or the manual format preference', async (t) => {
  const f = fixture({ saved: credentials, storage: { 'akis.format': 'ts' }, route(action) { if (!action) return DEFER; } }); t.after(() => f.close());
  const original = f.window.localStorage.getItem(STORE);
  assert.equal(f.requests.length, 1);
  f.document.querySelector('[data-action="demo"]').click(); await f.mode('vod');
  f.stream(0).focus(); f.key('Enter', 13);
  assert.equal(f.requests[0].aborted, true);
  assert.equal(f.window.localStorage.getItem(STORE), original);
  assert.equal(f.window.localStorage.getItem('akis.format'), 'ts');
  f.$('format-button').click();
  assert.equal(f.window.localStorage.getItem('akis.format'), 'ts');
  assert.equal(f.window.localStorage.length, 2);
  assert.equal(f.requests.length, 1, 'demo itself makes no authenticated provider requests');
  const relaunched = fixture({ saved: JSON.parse(original), storage: { 'akis.format': 'ts' } }); t.after(() => relaunched.close());
  await relaunched.flush();
  assert.equal(relaunched.$('home-screen').hidden, false);
  assert.equal(relaunched.$('account-name').textContent, credentials.username);
  assert.equal(relaunched.requests.length, 1);
  assert.equal(relaunched.window.localStorage.getItem(STORE), original);
});
