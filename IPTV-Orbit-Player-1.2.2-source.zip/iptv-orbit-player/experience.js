/* AKIŞ TV — MIT. Explicit settings only; no viewing or search history. */
(function (global) {
  'use strict';
  global.AkisExperience = function (ctx) {
    var F = global.AkisFeatures, state = ctx.state, player = ctx.player;
    var $ = function (id) { return document.getElementById(id); };
    var KEY = 'akis.preferences.v1', labels = { live: 'Canlı TV', vod: 'Film', series: 'Dizi' };
    var prefs = { v: 1, hidden: [], locked: [], pin: null, aspect: 'fit', seekStep: 10 };
    try {
      var stored = JSON.parse(ctx.storage('getItem', KEY) || 'null');
      if (stored && stored.v === 1) {
        ['hidden', 'locked'].forEach(function (key) { prefs[key] = Array.isArray(stored[key]) ? stored[key].filter(function (v) { return typeof v === 'string' && v.length < 240; }).slice(0, 3000) : []; });
        prefs.pin = stored.pin && typeof stored.pin === 'object' ? stored.pin : null;
        if (['fit', 'fill', 'stretch'].indexOf(stored.aspect) !== -1) prefs.aspect = stored.aspect;
        if ([10, 30, 60].indexOf(stored.seekStep) !== -1) prefs.seekStep = stored.seekStep;
      }
    } catch (_) { /* Corrupt nonsecurity preferences use defaults. */ }
    var grants = new Set(), catalogCategories = {}, catalogScope = '', feature = null, featureFocus = null;
    var epgItem = null, epgRows = [], epgTimer, epgJob = 0, epgLoadedAt = 0;
    var searchJob = 0, results = [], resultPage = 0, digitBuffer = '', digitTimer, digitContext;
    var pinPrompt = null, pinToken = 0, pinBusy = false, failures = 0, lockedUntil = 0;

    function persist() { ctx.storage('setItem', KEY, JSON.stringify(prefs)); }
    function modeOf(item) { return item.kind === 'episode' ? 'series' : item.kind; }
    function scope() {
      // A compact account scope, never a password or a watched-title identifier.
      var value = state.credentials ? state.credentials.server + '\n' + state.credentials.username : 'demo';
      var hash = 2166136261;
      for (var i = 0; i < value.length; i++) { hash ^= value.charCodeAt(i); hash = Math.imul(hash, 16777619); }
      return (hash >>> 0).toString(16) + ':';
    }
    function categoryKey(mode, id) { return scope() + (id === '' ? JSON.stringify([mode, '']) : F.makeCategoryKey(mode, id)); }
    function hidden(mode, id) { return prefs.hidden.indexOf(categoryKey(mode, id)) !== -1; }
    function locked(mode, id) { return prefs.locked.indexOf(categoryKey(mode, id)) !== -1; }
    function categoryAllowed(mode, id) { return !hidden(mode, id) && (!locked(mode, id) || grants.has(categoryKey(mode, id))); }
    function itemCategories(item) {
      var values = (item.categories || []).slice();
      if (item.category != null && item.category !== '' && values.indexOf(item.category) === -1) values.push(item.category);
      if (!values.length) values.push('');
      return values;
    }
    function itemAllowed(item) { return itemCategories(item).every(function (id) { return categoryAllowed(modeOf(item), id); }); }
    function visibleCategories(mode, rows) {
      return rows.filter(function (row) { return !hidden(mode, row.id); }).map(function (row) { return Object.assign({}, row, { locked: locked(mode, row.id) }); });
    }
    function rememberCategories(mode, rows) {
      if (catalogScope !== scope()) { catalogCategories = {}; catalogScope = scope(); }
      catalogCategories[mode] = rows.map(function (row) { return { id: row.id, name: row.name }; });
    }
    function toggle(list, key) { var index = list.indexOf(key); if (index < 0) list.push(key); else list.splice(index, 1); }

    function node(tag, className, text) {
      var element = document.createElement(tag);
      if (className) element.className = className;
      if (text != null) element.textContent = String(text);
      return element;
    }
    function button(title, operation, value, disabled) {
      var element = node('button', 'button button-secondary feature-row', title);
      element.type = 'button'; element.dataset.nav = ''; element.dataset.featureOp = operation;
      if (value != null) element.dataset.value = String(value);
      element.disabled = !!disabled; return element;
    }
    function section(title) { $('feature-content').appendChild(node('h3', 'feature-section', title)); }
    function note(title) { $('feature-content').appendChild(node('p', 'feature-caption', title)); }
    function openFeature(type, title, description) {
      clearDigits(); ctx.cancelPreview();
      if ($('feature-dialog').hidden) featureFocus = document.activeElement;
      feature = { type: type }; $('feature-content').textContent = '';
      ctx.text('feature-title', title); ctx.text('feature-description', description || ''); $('feature-dialog').hidden = false;
      ctx.showOverlay();
    }
    function focusFirst() { ctx.focus($('feature-content').querySelector('button:not(:disabled)') || $('feature-back')); }
    function closeFeature() {
      $('feature-dialog').hidden = true; $('feature-content').textContent = ''; feature = null;
      ctx.focus(featureFocus); if (state.fullscreen) ctx.showOverlay();
    }

    function promptPin(title, callback) {
      clearDigits();
      if (Date.now() < lockedUntil) return ctx.message('Çok fazla yanlış PIN. 30 saniye bekleyin.');
      ctx.ask(title, 'Kumandada OK ile alanı açın. 4–8 rakam girin, Bitti ve Onayla seçin.', null);
      state.dialogType = 'pin'; $('pin-field').hidden = false; $('pin-input').value = '';
      pinPrompt = { callback: callback, token: ++pinToken }; pinBusy = false;
      ctx.focus($('pin-input'));
    }
    function pinError(error) {
      return error && error.code === 'PIN_CRYPTO_UNAVAILABLE' ? 'Bu TV güvenli PIN işlemini desteklemiyor; kategori kilidi açılamadı.' : 'PIN doğrulanamadı. Ayar kaydını ve güvenli şifreleme desteğini kontrol edin.';
    }
    function protect(callback) {
      if (!prefs.pin) return callback();
      promptPin('PIN gerekli', async function (pin) {
        if (!await F.verifyPin(pin, prefs.pin)) {
          failures++; if (failures >= 5) { lockedUntil = Date.now() + 30000; failures = 0; }
          throw new Error('PIN yanlış.');
        }
        failures = 0; return callback;
      });
    }
    function createPin(callback) {
      var first = '';
      promptPin('Yeni PIN oluştur', async function (pin) {
        first = pin;
        return function () {
          promptPin('PIN’i tekrar girin', async function (again) {
            if (first !== again) throw new Error('PIN’ler aynı değil.');
            var record = await F.createPin(again); first = '';
            return function () { prefs.pin = record; persist(); if (callback) callback(); };
          });
        };
      });
    }
    function confirmDialog() {
      if (state.dialogType !== 'pin') return false;
      if (!pinPrompt || pinBusy) return true;
      if (Date.now() < lockedUntil) { ctx.text('pin-error', '30 saniye bekleyip tekrar deneyin.'); return true; }
      var pin = $('pin-input').value;
      if (!/^\d{4,8}$/.test(pin)) { ctx.text('pin-error', 'PIN 4–8 rakam olmalı.'); return true; }
      var prompt = pinPrompt; pinBusy = true; $('dialog-confirm').disabled = true; ctx.text('pin-error', 'Kontrol ediliyor…');
      Promise.resolve().then(function () { return prompt.callback(pin); }).then(function (next) {
        if (!pinPrompt || prompt.token !== pinToken) return;
        pinPrompt = null; pinBusy = false; $('dialog-confirm').disabled = false;
        ctx.closeDialog(false); if (typeof next === 'function') next();
      }).catch(function (error) {
        if (!pinPrompt || prompt.token !== pinToken) return;
        pinBusy = false; $('dialog-confirm').disabled = false;
        ctx.text('pin-error', error && /^(PIN yanlış\.|PIN’ler aynı değil\.)$/.test(error.message) ? error.message : pinError(error));
      });
      return true;
    }
    function dialogClosed() { ++pinToken; pinPrompt = null; pinBusy = false; $('dialog-confirm').disabled = false; }
    function unlockCategory(mode, id, callback) {
      if (hidden(mode, id)) return ctx.message('Bu kategori gizli. Kategori ayarlarından tekrar gösterebilirsiniz.');
      if (!locked(mode, id)) return callback();
      if (!prefs.pin) return ctx.message('Bu kilit için geçerli PIN kaydı gerekli. Kategori ayarlarını kontrol edin.');
      protect(function () { grants.add(categoryKey(mode, id)); callback(); });
    }
    function unlockItem(item, callback) {
      var mode = modeOf(item), ids = itemCategories(item);
      if (ids.some(function (id) { return hidden(mode, id); })) return ctx.message('Bu içerik gizlenen bir kategoride.');
      var lockedIds = ids.filter(function (id) { return !categoryAllowed(mode, id); });
      if (!lockedIds.length) return callback();
      if (!prefs.pin) return ctx.message('Bu kilit için geçerli PIN kaydı gerekli.');
      protect(function () { lockedIds.forEach(function (id) { grants.add(categoryKey(mode, id)); }); callback(); });
    }

    async function getCategories(mode) {
      if (catalogScope !== scope()) { catalogCategories = {}; catalogScope = scope(); }
      if (catalogCategories[mode]) return catalogCategories[mode];
      var rows = state.demo ? [{ category_id: 'demo', category_name: 'Yerel örnek video' }, { category_id: 'sample', category_name: 'Liste gezinme testi' }] :
        await ctx.api(mode === 'live' ? 'get_live_categories' : mode === 'vod' ? 'get_vod_categories' : 'get_series_categories');
      if (!Array.isArray(rows)) throw new Error('Kategori bilgisi alınamadı.');
      var normalized = rows.map(function (row) { return { id: String(row.category_id || '').slice(0, 60), name: String(row.category_name || 'İsimsiz kategori').slice(0, 120) }; });
      if (!normalized.length) normalized = [{ id: '', name: 'Tüm içerikler' }];
      rememberCategories(mode, normalized); return normalized;
    }
    function renderCategories(mode, page) {
      if (!feature || feature.type !== 'categories') return;
      feature.mode = mode; feature.page = Math.max(0, page || 0); $('feature-content').textContent = '';
      ['live', 'vod', 'series'].forEach(function (kind) { $('feature-content').appendChild(button((mode === kind ? '✓ ' : '') + labels[kind], 'category-mode', kind)); });
      section('Gizleme ve PIN kilidi');
      var rows = catalogCategories[mode] || [], start = feature.page * 8;
      rows.slice(start, start + 8).forEach(function (row) {
        section(row.name);
        $('feature-content').appendChild(button(hidden(mode, row.id) ? 'Tekrar göster' : 'Kategoriyi gizle', 'category-hide', row.id));
        $('feature-content').appendChild(button(locked(mode, row.id) ? 'PIN kilidini kaldır' : 'PIN ile kilitle', 'category-lock', row.id));
      });
      $('feature-content').appendChild(button('Önceki kategoriler', 'category-page', -1, start === 0));
      $('feature-content').appendChild(button('Sonraki kategoriler', 'category-page', 1, start + 8 >= rows.length));
      section('PIN yönetimi');
      $('feature-content').appendChild(button(prefs.pin ? 'PIN’i değiştir' : 'PIN oluştur', 'pin-create'));
      if (prefs.pin) $('feature-content').appendChild(button('PIN’i ve kategori kilitlerini kaldır', 'pin-remove'));
      note('Yalnız tercihler kaydedilir. Kilidi açılan kategori uygulamadan ayrılınca veya ana ekrana dönünce tekrar kilitlenir.'); focusFirst();
    }
    function openCategories() {
      protect(function () {
        openFeature('categories', 'Kategoriler ve PIN', 'Gizlenen kategoriler aramada da gösterilmez.');
        var mode = state.mode; loadCategorySettings(mode);
      });
    }
    function loadCategorySettings(mode) {
      var current = feature; if (!current || current.type !== 'categories') return;
      current.request = (current.request || 0) + 1; var request = current.request;
      getCategories(mode).then(function () {
        if (feature === current && current.request === request) renderCategories(mode, 0);
      }).catch(function () {
        if (feature === current && current.request === request) { note('Kategoriler yüklenemedi.'); focusFirst(); }
      });
    }
    function applyCategoryPreference(operation, id) {
      if (!feature || feature.type !== 'categories') return;
      var mode = feature.mode, page = feature.page;
      function apply() {
        toggle(operation === 'category-hide' ? prefs.hidden : prefs.locked, categoryKey(mode, id));
        grants.delete(categoryKey(mode, id)); persist();
        // Stop currently exposed content immediately when changing its protection.
        if (state.mode === mode && (state.categories[state.categoryIndex] && state.categories[state.categoryIndex].id === id ||
            state.playing && !itemAllowed(state.playing) || state.filtered.some(function (item) { return !itemAllowed(item); }))) {
          clearDigits(); player.stop(); state.playing = null; state.selected = -1; state.items = []; state.filtered = []; ctx.streams.set([]); clearEPG();
        }
        renderCategories(mode, page);
        // Refresh the visible category list on exit, without restarting hidden media.
        feature.refresh = true;
      }
      if (operation === 'category-lock' && !prefs.pin) createPin(apply); else apply();
    }

    function openPlayerSettings() {
      openFeature('player', 'Oynatıcı ayarları', 'Ses ve altyazı seçenekleri yayının içeriğine göre değişir.');
      renderPlayer();
    }
    function renderPlayer() {
      if (!feature || feature.type !== 'player') return;
      $('feature-content').textContent = '';
      section('Ses dili');
      var audio = player.getAudioTracks();
      if (!audio.length) note('Yayın ses parçası bilgisi göndermedi veya oynatıcı henüz hazır değil.');
      audio.forEach(function (track) { $('feature-content').appendChild(button((track.selected ? '✓ ' : '') + track.label, 'audio', track.index)); });
      section('Altyazı');
      var subtitles = player.getSubtitleTracks();
      $('feature-content').appendChild(button('Altyazıyı kapat', 'subtitle', -1));
      subtitles.forEach(function (track) { $('feature-content').appendChild(button((track.selected ? '✓ ' : '') + track.label, 'subtitle', track.index)); });
      if (!subtitles.length) note('Bu yayında seçilebilir altyazı bulunamadı.');
      section('Görüntü oranı');
      [['fit', 'Ekrana sığdır'], ['fill', 'Ekranı doldur'], ['stretch', 'Ekrana uzat']].forEach(function (option) {
        $('feature-content').appendChild(button((prefs.aspect === option[0] ? '✓ ' : '') + option[1], 'aspect', option[0]));
      });
      section('Sarma adımı');
      [10, 30, 60].forEach(function (seconds) { $('feature-content').appendChild(button((prefs.seekStep === seconds ? '✓ ' : '') + seconds + ' saniye', 'seek-step', seconds)); });
      note('Ses dili değiştirmek için bazı Samsung yayınlarını önce devam ettirmek gerekir.'); focusFirst();
    }

    function clearEPG() {
      clearTimeout(epgTimer); ++epgJob; epgItem = null; epgRows = []; epgLoadedAt = 0;
      $('epg-summary').hidden = true; $('epg-button').hidden = true;
    }
    function programmeTime(row) {
      function label(ms, value) { return ms != null ? new Date(ms).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : String(value || '').slice(-8, -3) || '—'; }
      return label(row.startMs, row.startText) + ' – ' + label(row.endMs, row.endText);
    }
    function renderEPGSummary() {
      if (!epgItem || epgItem.kind !== 'live') return;
      var now = Date.now(), index = epgRows.findIndex(function (row) { return row.startMs != null && row.endMs != null && row.startMs <= now && row.endMs > now; });
      if (index < 0) index = Math.max(0, epgRows.findIndex(function (row) { return row.endMs == null || row.endMs > now; }));
      var current = epgRows[index], next = epgRows[index + 1];
      ctx.text('epg-now-title', current ? current.title : 'Sağlayıcı program bilgisi göndermedi.');
      ctx.text('epg-now-time', current ? programmeTime(current) : '');
      ctx.text('epg-next-title', next ? next.title : 'Sıradaki program bilgisi yok.');
      ctx.text('epg-next-time', next ? programmeTime(next) : '');
    }
    async function fetchEPG(item, full) {
      var job = ++epgJob;
      try {
        var data;
        if (state.demo) {
          data = { epg_listings: [{ title: 'Yerel örnek video · 120 saniye', description: 'Aynı paket dosyasını oynatan demo liste satırı. Bu bir canlı yayın veya gerçek program akışı değildir.' }] };
        } else {
          data = await ctx.api(full ? 'get_simple_data_table' : 'get_short_epg', { stream_id: item.id, limit: full ? 100 : 6 });
        }
        if (job !== epgJob || !epgItem || epgItem.id !== item.id) return;
        epgRows = F.normalizeEPG(data && data.epg_listings || []); epgLoadedAt = Date.now(); renderEPGSummary();
      } catch (error) {
        if (job !== epgJob || error.cancelled) return;
        epgRows = []; ctx.text('epg-now-title', 'Yayın akışı alınamadı.'); ctx.text('epg-next-title', 'Sağlayıcı bu özelliği desteklemiyor olabilir.');
      }
      if (feature && feature.type === 'epg') renderProgramme(feature.page || 0);
    }
    function selectItem(item) {
      if (item.kind !== 'live') return clearEPG();
      if (epgItem && epgItem.id === item.id && Date.now() - epgLoadedAt < 60000) return;
      clearEPG(); epgItem = item; $('epg-summary').hidden = false; $('epg-button').hidden = false;
      ctx.text('epg-now-title', 'Program bilgisi yükleniyor…'); ctx.text('epg-now-time', ''); ctx.text('epg-next-title', ''); ctx.text('epg-next-time', '');
      epgTimer = setTimeout(function () { fetchEPG(item, false); }, 350);
    }
    function renderProgramme(page) {
      if (!feature || feature.type !== 'epg') return;
      feature.page = Math.max(0, page); $('feature-content').textContent = '';
      if (!epgRows.length) note('Bu kanal için yayın akışı bulunamadı.');
      epgRows.slice(feature.page * 20, feature.page * 20 + 20).forEach(function (row) {
        var entry = node('button', 'programme-row feature-row'); entry.type = 'button'; entry.dataset.nav = ''; entry.appendChild(node('p', 'programme-time', programmeTime(row)));
        entry.appendChild(node('h3', '', row.title)); if (row.description) entry.appendChild(node('p', '', row.description)); $('feature-content').appendChild(entry);
      });
      $('feature-content').appendChild(button('Önceki programlar', 'epg-page', -1, feature.page === 0));
      $('feature-content').appendChild(button('Sonraki programlar', 'epg-page', 1, (feature.page + 1) * 20 >= epgRows.length)); focusFirst();
    }
    function openProgramme() {
      if (!epgItem) return ctx.message('Önce canlı kanal seçin.');
      var item = epgItem; clearTimeout(epgTimer); openFeature('epg', 'Yayın akışı', item.name); feature.page = 0;
      renderProgramme(0); fetchEPG(item, true);
    }

    function renderResults() {
      var container = $('searchall-results'); container.textContent = '';
      results.slice(resultPage * 30, resultPage * 30 + 30).forEach(function (item, index) {
        var row = button(item.name, 'search-result', resultPage * 30 + index);
        row.className = 'search-result-row';
        row.appendChild(node('span', 'row-subtitle', labels[item.kind])); container.appendChild(row);
      });
      $('searchall-prev').disabled = resultPage === 0;
      $('searchall-next').disabled = (resultPage + 1) * 30 >= results.length;
    }
    function openSearch() {
      clearDigits(); ++state.token; ++state.searchToken; ++searchJob; ctx.abortRequests(); ctx.cancelPreview();
      player.stop(); state.playing = null; ctx.setFullscreen(false); clearEPG(); grants.clear();
      results = []; resultPage = 0; $('searchall-input').value = ''; renderResults();
      ctx.text('searchall-status', 'Kanal, film veya dizi adı yazın. Bitti ile aramayı başlatın.'); ctx.showScreen('search'); ctx.focus($('searchall-input'));
    }
    async function runSearch() {
      var query = F.normalizeSearch($('searchall-input').value.trim());
      if (query.length < 2) { ctx.text('searchall-status', 'En az 2 karakter yazın.'); return; }
      var job = ++searchJob, token = ++state.token; ctx.abortRequests(); results = []; resultPage = 0; renderResults();
      var errors = [], limited = false, seen = new Set();
      for (var mode of ['live', 'vod', 'series']) {
        if (job !== searchJob || state.screen !== 'search') return;
        ctx.text('searchall-status', labels[mode] + ' aranıyor… ' + results.length + ' sonuç');
        try {
          var categories = await getCategories(mode), restrictions = categories.some(function (row) { return !categoryAllowed(mode, row.id); });
          var batches = restrictions ? categories.filter(function (row) { return categoryAllowed(mode, row.id); }) : [null], modeMatches = 0;
          for (var category of batches) {
            if (job !== searchJob || state.screen !== 'search') return;
            var rows = state.demo ? ctx.demoItems(mode).map(function (item) { return Object.assign({}, item, { stream_id: item.id, series_id: item.id, category_id: category ? category.id : 'demo', container_extension: item.extension }); }) :
              await ctx.api(mode === 'live' ? 'get_live_streams' : mode === 'vod' ? 'get_vod_streams' : 'get_series', category && category.id ? { category_id: category.id } : {});
            var items = await ctx.normalizeItems(rows, mode, token);
            if (job !== searchJob || state.screen !== 'search') return;
            for (var item of items) {
              if (!item.category && category) item.category = category.id;
              if (!itemAllowed(item) || F.normalizeSearch(item.name).indexOf(query) === -1) continue;
              var resultKey = JSON.stringify([item.kind, item.id]); if (seen.has(resultKey)) continue;
              if (modeMatches++ < 100) { results.push(item); seen.add(resultKey); } else limited = true;
            }
            renderResults();
          }
        } catch (error) { if (job !== searchJob || error.cancelled) return; errors.push(labels[mode]); }
      }
      if (job !== searchJob) return;
      ctx.text('searchall-status', results.length + ' sonuç' + (limited ? ' · Her türün ilk 100 sonucu; aramayı daraltabilirsiniz.' : '') + (errors.length ? ' · Alınamayan katalog: ' + errors.join(', ') : ''));
      if (document.activeElement === $('searchall-input')) ctx.focus($('searchall-results').querySelector('button') || $('searchall-input'));
    }
    async function openResult(index) {
      var item = results[index]; if (!item) return;
      if (!itemAllowed(item)) return unlockItem(item, function () { openResult(index); });
      var job = ++searchJob, loadedToken = await ctx.loadMode(item.kind, item.category);
      if (job !== searchJob || loadedToken !== state.token || state.screen !== 'browser' || state.mode !== item.kind) return;
      var selected = state.filtered.findIndex(function (row) { return row.id === item.id && row.kind === item.kind; });
      if (selected < 0) return ctx.message('Bu sonuç kategori listesinde bulunamadı; sağlayıcı verisi değişmiş olabilir.');
      ctx.selectItem(selected, false); ctx.streams.focus(selected); ctx.startPlayback(state.filtered[selected], true);
    }

    function clearDigits() { digitBuffer = ''; digitContext = null; clearTimeout(digitTimer); $('digit-channel-overlay').hidden = true; }
    function commitDigits() {
      var index = Number(digitBuffer) - 1, current = digitContext; clearDigits();
      if (!current || current.token !== state.token || current.items !== state.filtered || state.screen !== 'browser' || state.mode !== 'live' || !$('feature-dialog').hidden || !$('dialog').hidden) return;
      if (index < 0 || index >= state.filtered.length) return ctx.message('Bu listede o numarada kanal yok.');
      ctx.selectItem(index, false); ctx.startPlayback(state.filtered[index], true);
    }
    function handleKey(key, event) {
      if (!$('feature-dialog').hidden) {
        if (key.indexOf('Arrow') === 0) { navigate(key); return true; }
        if (key === 'Enter') { document.activeElement.click(); return true; }
        return /^\d$/.test(key) || event.keyCode >= 48 && event.keyCode <= 57;
      }
      var digit = /^\d$/.test(key) ? key : event.keyCode >= 48 && event.keyCode <= 57 ? String(event.keyCode - 48) : event.keyCode >= 96 && event.keyCode <= 105 ? String(event.keyCode - 96) : '';
      if (state.screen === 'browser' && state.mode === 'live' && digit !== '') {
        if (digitContext && (digitContext.token !== state.token || digitContext.items !== state.filtered)) clearDigits();
        digitContext = { token: state.token, items: state.filtered };
        if (digitBuffer.length >= 5) { clearDigits(); digitContext = { token: state.token, items: state.filtered }; } digitBuffer += digit; clearTimeout(digitTimer);
        $('digit-channel-overlay').hidden = false; ctx.text('digit-channel-number', digitBuffer);
        var item = state.filtered[Number(digitBuffer) - 1]; ctx.text('digit-channel-label', item ? item.name + ' · OK ile aç' : 'Bu listede kanal yok');
        digitTimer = setTimeout(commitDigits, 1600); return true;
      }
      if (digitBuffer && key === 'Enter') { commitDigits(); return true; }
      if (digitBuffer && key.indexOf('Arrow') === 0) clearDigits();
      if (state.fullscreen && state.mode === 'live' && key === 'ArrowRight') { openPlayerSettings(); return true; }
      if (state.fullscreen && state.mode === 'live' && key === 'ArrowLeft') { openProgramme(); return true; }
      return false;
    }
    function navigate(direction) {
      if (!$('feature-dialog').hidden) {
        var nodes = Array.from($('feature-dialog').querySelectorAll('[data-nav]:not(:disabled)')).filter(function (element) { return !element.closest('[hidden]'); });
        var index = nodes.indexOf(document.activeElement), delta = direction === 'ArrowUp' || direction === 'ArrowLeft' ? -1 : 1;
        ctx.focus(nodes[(Math.max(0, index) + delta + nodes.length) % nodes.length]); return true;
      }
      if (state.screen === 'search') {
        var entries = [$('searchall-input')].concat(Array.from($('searchall-results').querySelectorAll('button')), [$('searchall-prev'), $('searchall-next'), $('home-button')]).filter(function (element) { return !element.disabled; });
        var current = entries.indexOf(document.activeElement), move = direction === 'ArrowUp' || direction === 'ArrowLeft' ? -1 : 1;
        ctx.focus(entries[(Math.max(0, current) + move + entries.length) % entries.length]); return true;
      }
      return false;
    }
    function back() {
      if (!$('feature-dialog').hidden) {
        var refresh = feature && feature.refresh; closeFeature(); if (refresh && state.screen === 'browser') ctx.loadMode(state.mode); return true;
      }
      if (digitBuffer) { clearDigits(); return true; }
      if (state.screen === 'search') { ctx.showHome(); return true; }
      return false;
    }
    function action(name) {
      if (name === 'global-search') openSearch();
      else if (name === 'programme') openProgramme();
      else if (name === 'player-settings') openPlayerSettings();
      else if (name === 'category-settings') openCategories();
      else if (name === 'feature-back') back();
      else if (name === 'search-prev' || name === 'search-next') { resultPage += name === 'search-next' ? 1 : -1; renderResults(); ctx.focus($('searchall-results').querySelector('button')); }
      else return false;
      return true;
    }
    document.addEventListener('click', function (event) {
      var control = event.target.closest('[data-feature-op]'); if (!control || control.disabled) return;
      var op = control.dataset.featureOp, value = control.dataset.value;
      if (op === 'search-result') return openResult(Number(value));
      if (!feature) return;
      if (op === 'category-mode') loadCategorySettings(value);
      else if (op === 'category-page') renderCategories(feature.mode, feature.page + Number(value));
      else if (op === 'category-hide' || op === 'category-lock') applyCategoryPreference(op, value);
      else if (op === 'pin-create') protect(function () { createPin(function () { renderCategories(feature.mode, feature.page); }); });
      else if (op === 'pin-remove') protect(function () { prefs.pin = null; prefs.locked = []; grants.clear(); persist(); renderCategories(feature.mode, feature.page); });
      else if (op === 'audio' || op === 'subtitle') {
        var success = op === 'audio' ? player.selectAudioTrack(Number(value)) : player.selectSubtitleTrack(Number(value));
        if (!success) ctx.message('Bu seçenek şu an değiştirilemiyor; yayını devam ettirip tekrar deneyin.'); renderPlayer();
      } else if (op === 'aspect') { if (player.setAspectRatio(value)) { prefs.aspect = value; persist(); } else ctx.message('Görüntü oranı şu an değiştirilemiyor.'); renderPlayer(); }
      else if (op === 'seek-step') { prefs.seekStep = Number(value); persist(); renderPlayer(); }
      else if (op === 'epg-page') renderProgramme(feature.page + Number(value));
    });
    function resetSession() {
      ++searchJob; grants.clear(); results = []; resultPage = 0; clearDigits(); clearEPG();
      if (state.dialogType === 'pin') ctx.closeDialog(false);
      $('searchall-input').value = ''; $('searchall-results').textContent = '';
      $('feature-dialog').hidden = true; $('feature-content').textContent = ''; feature = null;
    }
    function suspend() {
      var restricted = state.screen === 'browser' && (state.categories[state.categoryIndex] && locked(state.mode, state.categories[state.categoryIndex].id) ||
        state.filtered.some(function (item) { return itemCategories(item).some(function (id) { return locked(modeOf(item), id); }); }));
      resetSession(); if (restricted) ctx.showHome();
    }
    return { action: action, back: back, handleKey: handleKey, navigate: navigate, protect: protect,
      categoryAllowed: categoryAllowed, itemAllowed: itemAllowed, unlockCategory: unlockCategory, unlockItem: unlockItem,
      rememberCategories: rememberCategories, visibleCategories: visibleCategories, clearEPG: clearEPG, selectItem: selectItem,
      confirmDialog: confirmDialog, dialogClosed: dialogClosed, resetSession: resetSession, suspend: suspend,
      runSearch: runSearch, clearDigits: clearDigits, openPlayerSettings: openPlayerSettings, seekStep: function () { return prefs.seekStep; },
      playing: function () { player.setAspectRatio(prefs.aspect); } };
  };
})(window);
